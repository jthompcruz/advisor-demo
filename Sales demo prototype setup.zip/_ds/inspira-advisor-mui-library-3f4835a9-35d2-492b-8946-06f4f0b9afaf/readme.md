# Inspira Advisor MUI Library — design system

The design system extracted from **Advisor MUI library.fig**, the Figma library behind Inspira Financial's
advisor-facing product surfaces.

## What this is

The source file is a **component library**, not a product file. It is a Material UI (MUI + MUI-X) kit
re-themed for Inspira — 21 Figma pages, 169 component families, ~1,800 tokens, and two coexisting
component vocabularies:

1. **The MUI layer** (`[Mc…]` prefixed families: `[McButton] <Button>`, `[McDataGridTable] <DataGridTable>`, …).
   Standard MUI components with the Inspira theme applied — indigo primary, gold secondary, a warm-grey
   neutral ramp, and a **12px corner radius replacing MUI's 4px**. This is most of the file.
2. **The H-B product layer** (`Button`, `Icon Buttons`, `Filter Chips`, `Standalone link`, `Primary input (Vert)`,
   `Loading`, `Tooltip Bubble`, `_input box`). Inspira's own product components, predating the MUI
   adoption — SemiBold labels, 8px input radius, 16px filter chips, translucent hover overlays. Named
   here with an `Inspira` prefix where the name would otherwise collide.

Both are built. Pick one per screen and don't mix them — see `ui_kits/*/README.md`.

## Sources

- **Figma file:** `Advisor MUI library.fig`, attached to this project as a read-only virtual filesystem.
  Pages: Theme, Typography, Autocomplete, Buttons, Checkbox, Button-Group, Text-fields, Select,
  Data-Display, Chips, Alerts, Icons, List, Table, MUI-X, Data-grid, Data-Grid-exploration, H-B-Components,
  SANDBOX, Page-1. The theme section is named **"Theme E / Inspira"**.
- Token values came from the file's Figma Variables (`Ungrouped`, 839 vars; `Collection 1`, 1 var), dumped
  verbatim to `tokens/fig-tokens.css` across 43 modes (Inspira-Colors, Theme A–D, PayFlex Theme, light/dark,
  cozy/compact, Phone/Tablet, …).
- No codebase, GitHub repository, deck or written brand guide was provided. Content-tone guidance below is
  inferred from the literal strings in the file and is flagged as such.

## Index

| Path | What's there |
| --- | --- |
| `styles.css` | The one file consumers link. `@import` list only. |
| `tokens/` | `fonts.css`, `colors.css`, `typography.css`, `shape.css`, `spacing.css`, `base.css`, plus the generated `fig-tokens.css` / `fig-typography.css`. |
| `components/core/` | Typography, Paper, Divider, Stack, Spacing, NativeBrowserScroll |
| `components/inputs/` | Button, LoadingButton, IconButton, ButtonGroup, TextField, TextFieldMultiline, Select, Autocomplete, Checkbox, Switch, Rating, Star, FormLabel, FormHelperText, FormControlLabel, FormGroup, EyeIconToggle, LockIconToggle, HelpersButtonIconContainer, HelpersField, HelpersText |
| `components/data-display/` | Avatar, AvatarGroup, Badge, Chip, Link, List, ListItem, ListSubheader, ListItemSubItem |
| `components/surfaces/` | Card, CardHeader, CardMedia, CardContent, CardActions, CardElements |
| `components/tables/` | Table, TableHead, TableHeadRow, TableCell, TableCellRow, TableFooter, CustomTableToolbar, HelpersTableTitle, HelpersTableActions, HelpersTableCellContent, CustomTableCustomCell, HelpersTableCells, TableColumns |
| `components/data-grid/` | DataGridTable, DataGridHeader, DataGridHeaderRow, DataGridCell, DataGridCellRow, DataGridGroupingCell, DataGridColumnGroupHeader, DataGridColumnGroupRow, GridToolbarQuickFilter, GridToolbarMenu, DetailPanelContent |
| `components/feedback/` | Alert, Progress, TooltipBubble, Loading |
| `components/navigation/` | Menu, MenuItem, MenuList |
| `components/inspira/` | InspiraButton, IconButtons, ActionButtonsOnWhite, FilterChips, StandaloneLink, TextAction, PrimaryInputVert, InputBox, ErrorMessage, LabelAndTooltipTrigger, VerticalTrigger, HideTextOverflow |
| `components/library/` | LibraryComponentHeading, LibraryComponentInformation, LibraryComponentProperties, LibraryInstanceSlot, LibraryPlaceholderImage, UsabilityIconContainer, Hidden — the Figma file's own documentation scaffolding |
| `assets/icons/` | `Icon` + `icon-data.js` — 98 glyphs extracted from the library. `Icon.d.ts` is the name index. |
| `components/inspira-legacy/` | `Components.bundle.js` — the raw Figma extraction of the H-B families, kept as a fidelity reference. `BUNDLE-API.txt` documents it. Not part of the public API. |
| `guidelines/` | 19 foundation specimen cards (colour, type, spacing, shape, brand). |
| `ui_kits/advisor-console/` | 3-screen click-through: account grid, account detail, household search. |
| `ui_kits/participant-forms/` | 3-step click-through on the H-B product components. |
| `templates/advisor-console/` | Starting template — full advisor console page (side nav, header, filter chips, data grid). |
| `templates/participant-form/` | Starting template — H-B product form page (header, step indicator, `PrimaryInputVert` stack). |
| `thumbnail.html` | Homepage tile. |
| `SKILL.md` | Agent Skills front-matter so this folder works as a Claude Code skill. |

Every component directory carries `<Name>.jsx`, `<Name>.d.ts`, `<Name>.prompt.md`, and one
`@dsCard`-tagged specimen HTML.

---

## VISUAL FOUNDATIONS

### Colour

**Indigo is the brand.** `--primary-main` is `#4553A9` (indigo 700) and `--primary-dark` is `#1B216B`
(indigo 900). Hover on a contained button goes to indigo 900 — the library darkens rather than lightens.
The full ramp runs `#F4F6FF → #1B216B` in ten steps.

**Gold is the accent, used sparingly.** `--secondary-main` is `#FFD008`. Its contrast text is
`rgba(0,0,0,0.87)`, not white. Gold appears on dark grounds (dark-mode links are gold, not indigo), on the
loading spinner over indigo, and on rating stars — almost never as a page-level fill.

**Neutrals are warm, not grey.** The neutral ramp is a warm grey (`#F7F6F5 → #292521`) and the divider is
`rgba(41,37,33,0.12)` — a warm hairline. The page background is `#F7F6F5`; cards are pure white. That
contrast between warm page and white card is the system's main depth cue.

**Teal carries growth/positive meaning** (`#23C482`, `#02C78A`) and appears in the H-B success icon button
and status dots — distinct from the MUI `success` green (`#2E7D32`).

**Semantic colours are MUI stock** (`#D32F2F` / `#EF6C00` / `#0288D1` / `#2E7D32`) but their **subtle pairs
are custom and warm**: error `#FDE5E5` on `#591212`, warning `#FFF5E6` on `#682400`, success `#DFF7EA` on
`#005C57`. Alerts use those pairs, so a standard alert reads as a tinted plate, never as a saturated bar.
The H-B layer has its own alert red, `--alerts-alert` `#E40901`, brighter than the MUI red — used for the
`ErrorMessage` line only.

Text is **opacity-based**: `rgba(0,0,0,0.87)` / `0.68` / `0.38`. Note the secondary step is **0.68**, not
MUI's 0.6 — a deliberate darkening for financial data density.

### Type

Two families, and the split is strict:

- **PP Formula Condensed** (weight 400 only) for **h1–h4** — 96 / 60 / 48 / 34px. A condensed industrial
  grotesque; it appears eight times in the whole file, so it's a display voice for page titles and hero
  numbers, not a headline default.
- **Inter** for everything else — h5 (Bold 24), h6 (Medium 20), subtitles, body, caption, overline, all
  control labels. Inter Medium at 12–15px is by far the most-used style in the file (1,211 instances).

Letter-spacing is always positive and always small: 0.15px on body1/subtitle1/h6, 0.17px on body2, 0.1px
on subtitle2, 0.25px on h4, 0.4px on caption, **1px on overline** (uppercase). Button labels carry
0.46 / 0.40 / 0.46px at large / medium / small. Copy these exactly — they're what makes dense tables legible.

A 13th variant, `custom` (Inter Medium 14/24px, 0.17px), is the workhorse for dense labels and table cells.

### Spacing & density

8px base unit (`semantic/spacing/1 = 8`; the compact mode drops it to **6**). The scale in use is
0 / 4 / 8 / 16 / 24 / 32 / 40 / 48, with 128 for page-section gaps.

Component heights are fixed and worth memorising: buttons 30 / 36 / 42; fields 40 / 56 (48 for the
standard variant); list items 40 / 48; table head 56, table row 52 (36 small); grid rows 36 / 52 / 60 for
compact / standard / comfortable. Table cells pad 16px all round; grid cells pad only 10px horizontally.

### Shape

**12px is the house radius.** Buttons, fields, cards, alerts, menus, the data grid shell — all 12px. This
is the single biggest visual departure from stock MUI (4px). Exceptions, all deliberate:
8px for the H-B `InputBox` and the small radius token; **16px** for H-B filter chips; **100px** (pill) for
chips, avatars, switches, and the round hit areas behind checkboxes and icon buttons; 0px only where a
surface is explicitly `square`.

### Borders, rings and elevation

Borders are drawn as **inset box-shadows**, not CSS borders, and they are **2px** on interactive inputs:
`inset 0 0 0 2px rgba(0,0,0,0.23)` for an enabled outlined field, the same 2px at 50% opacity for an
outlined button, 2px solid `--primary-main` on focus. Dividers are 1px `rgba(41,37,33,0.12)`. The H-B
layer uses 1px rings instead (1.5px on a selected filter chip).

Elevation is the MUI ladder. In practice: **cards sit at 1**, elevated H-B icon buttons at 2, menus and
open selects at 8. **Contained buttons carry no shadow at all** — they're flat indigo. Pinned data-grid
columns use the file's own `0px 3px 4px -2px rgba(0,0,0,0.21)`; selected H-B filter chips use a warm
`rgba(61,61,58,…)` pair. Cards are **shadow + radius, never a border** — an outlined card is a distinct
variant, not the default.

### Interaction states

One overlay system, five opacities:

| State | Neutral | Primary-tinted |
| --- | --- | --- |
| hover | `rgba(0,0,0,0.04)` | `rgba(69,83,169,0.04)` |
| selected | `rgba(0,0,0,0.08)` | `rgba(69,83,169,0.08)` |
| focus ring | `rgba(0,0,0,0.12)` | `rgba(69,83,169,0.3)` |
| disabled fill | `rgba(0,0,0,0.12)` | — |
| disabled text | `rgba(0,0,0,0.38)` | — |

Hover **never** changes size and rarely changes the fill: it washes. The exception is the contained
button, which darkens to `--primary-dark`. Press is not a shrink — the H-B layer renders it as a white
12% (hover) / 20% (pressed) overlay *inside* the button, leaving the indigo untouched. Focus is a ring,
never a glow. Disabled reduces contrast; it never adds hatching or a lock icon by itself.

### Motion

Two durations, one curve: **150ms** `cubic-bezier(0.4,0,0.2,1)` for hover/press/background, **250ms** for
expand, menu open and drawer. Colour and opacity animate; geometry generally does not. Rotation is
reserved for carets (180° on open, 90° on group expand) and the circular spinner (1.4s linear). No bounce,
no spring, no scale-in. There are no keyframe animations in the source beyond the spinner.

### Transparency & blur

Transparency is used only for the overlay system above and for the `--surface-subtle` washes. Blur appears
once — the `transparent` mode of the loading overlay puts a 2px backdrop blur over the page. There are no
frosted panels, no glassmorphism, no protection gradients: the library separates layers with the
warm-page/white-card contrast and elevation instead.

### Imagery & backgrounds

Backgrounds are flat colour. **There are no gradients, textures, patterns or illustrations anywhere in the
file.** Only three bitmaps exist (two ~22KB PNGs and one 311KB JPEG) and they are placeholder photos in
the Avatar/CardMedia specimens — not brand imagery. `CardMedia` and `LibraryPlaceholderImage` render a neutral
`#F1F0EE` plate where a real photograph belongs. If a design needs a photo, ask for the file — do not
generate or draw one.

### Layout rules

Nothing in the library positions itself. There are no fixed headers, no sticky footers, no drawers, no
app-bar component — `ListSubheader` is the only sticky element (`position:sticky; top:0`). Page chrome is
the consuming application's job, which is why the UI kits label their nav and header as compositions.
The data grid is the only component that owns horizontal scrolling.

---

## CONTENT FUNDAMENTALS

Inferred from the literal strings in the source file — mostly the H-B `Loading` and `Error Message`
components, which are the only real product copy present. Treat these as observations, not a ratified
voice guide.

**Tone: warm, plain, and slightly informal — unusually so for a financial product.** The loading
component's own copy is *"Sit tight! We're verifying your identity."* followed by *"This may take a few
minutes to complete."* That's the register: a friendly opener with an exclamation mark, then a concrete,
unhedged expectation. Not "Please wait while your request is processed."

**"We" for the company, "you/your" for the user.** *We're verifying your identity.* Never "the system",
never the passive voice, never third-person ("the member").

**Sentence case everywhere.** Labels (*Gutter Bottom* aside — that's a Figma property name), buttons
(*Continue*, *Back*, *Close*), menu items, table headers. The only uppercase in the system is the
`overline` type variant, and it is uppercase by CSS, not by written copy.

**Labels are nouns, actions are verbs.** Field labels: *Label*, *Amount*, *Tax year*. Buttons and links:
*Continue*, *Add action*, *PDF download*, *Standalone Enabled*, *Close*. Buttons never say "Click here"
or "Submit form".

**Errors say what to do.** The `ErrorMessage` component pairs an alert glyph with a single line —
write *"Enter a 9-digit routing number"*, not *"Invalid input"*. One line, no apology, no error code
unless the user needs to quote it.

**Punctuation:** periods on full sentences (helper text, alert descriptions), none on labels, buttons or
menu items. Contractions are fine and preferred (*we're*, *you've*, *don't*).

**No emoji.** Not one appears in the source, and none should be added. Status is carried by the icon set,
by `Chip` colour, and by the `ListItemSubItem` status dot.

**Numbers:** money always with the currency symbol and two decimals (*$184,220.14*); percentages with one
decimal and an explicit sign (*+6.2%*, *−0.6%* with a real minus sign); dates written out
(*March 14, 2026*) in prose, abbreviated (*Mar 14*) in dense rows. Account numbers are masked with a
two-bullet prefix (*••4821*).

**Density over decoration.** Advisor screens carry a lot of data; copy earns its place by being shorter.
Alert titles are one clause. Helper text is one line. If a tooltip is needed, the label probably isn't
clear enough — the `LabelAndTooltipTrigger` (?) is for genuinely regulatory or unintuitive terms, not for
every field.

---

## ICONOGRAPHY

**One system: MUI's Material Symbols, filled by default, at 20px.** The library wraps them as
`[McIcon] <Usability Icon>` and names each glyph with an explicit style suffix — `SearchFilled`,
`InfoOutlined`, `WarningAmberOutlined`, `ErrorOutline`. Filled is the norm; outlined is used for
informational and warning glyphs specifically.

**98 glyphs are extracted into this project** as real path data at `assets/icons/icon-data.js`, rendered
by `assets/icons/Icon.jsx`. `Icon.d.ts` lists every valid name — read it rather than guessing. Nothing was
redrawn: the geometry is the file's own. **If a glyph you need isn't in `Icon.d.ts`, say so and ask —
do not hand-draw an SVG or reach for a different icon set.**

- **No icon font.** No ligature-based system, no sprite sheet. Icons are inline SVG paths that paint with
  `currentColor`, so setting `color` on any ancestor recolours them.
- **Sizes are 16 / 20 / 24 / 32 / 40** (the container's xs–xl). The library's default `Size=Small` is
  **20px**; `Size=Medium` is 24px. Icon buttons pair a 24px glyph with a 40px box at medium.
  Alerts use a 22px glyph.
- `UsabilityIconContainer` gives an icon a fixed frame (and 4px of padding when `padded`) so glyphs of
  different sizes stay on the same baseline grid.
- **No emoji, ever.** No Unicode characters used as icons either, with two exceptions the source itself
  uses: the bullet `•` for masked account digits and the middle dot `·` as a metadata separator.
- The file also contains a family literally named **"OLD DO NOT USE icons"** (51 names × 5 sizes). It is
  deliberately not built here — see *Intentionally not built* below.
- Beyond the usability set, the file references three specialised icon families — `[McIcon] <Brand Icon>`,
  `[McIcon] <Illustrations>`, `[McIcon] <Pictograms>` — each with size variants. Their placed instances
  in the file are single unnamed vectors, so no glyph inventory could be recovered. `LibraryPlaceholderImage`
  stands in for them. **Ask for these assets** if a design needs a pictogram or illustration.

## Brand assets

**There is no logo in the source, and none was created here.** The Theme page contains a 400×400 rounded
rectangle filled `#1B216B` where a mark would go — a placeholder, not a logo. The only real logo asset in
the file is **MUI's own** (`_Library / MUI Logos`, `#007FFF`), which belongs to MUI and is not Inspira's;
it has not been copied in.

Wherever a mark is needed, the wordmark **"Inspira"** is set in the display face (PP Formula Condensed,
weight 400) — see `guidelines/brand-wordmark.html` and the UI-kit headers. **Please supply the real logo
files** and they'll be wired into `assets/` and the thumbnail.

## Fonts — substitutions to resolve

| Source family | Status | Fallback in use |
| --- | --- | --- |
| **Inter** | ✅ exact, from Google Fonts | — |
| **PP Formula Condensed** | ⚠️ commercial (Pangram Pangram); no binary in the `.fig` | Archivo Narrow |
| **CircularXX** | ⚠️ commercial; used by the H-B filter-chip label | Figtree |
| **Roboto** | one instance in the source (MUI's stock default) | Google Fonts |

`--font-display` and `--font-brand` still name `PP Formula` and `CircularXX` first, so the moment the real
files are added the whole system picks them up. **Please upload both font families** — the display face in
particular changes the character of every page title.

## Intentionally not built

Three of the source's 169 families were skipped on purpose:

- **`_Library / MUI Logos`** (×2) — MUI's trademark, not Inspira's brand.
- **`OLD DO NOT USE icons`** — the file's own name marks it as deprecated; its 51 glyphs are superseded by
  the usability icon set in `assets/icons/`.
- **`_hidden`** placed variants — represented by `Hidden`, which renders nothing by design.

### Why 93 components cover 169 families

The rest of the gap is **duplication in the source**, and it comes in two shapes:

1. **The same family placed on several Figma pages.** `[McButton] <Button>` appears three times, `?Link?`
   five, `?ListItem?` four, `?Typography?` six, `?IconButton?` three, `?Icon?` three, `?Select?` /
   `?TextField?` / `?Table?` / `?TableCell?` / `?TableCellRow?` / `?TableHead?` / `?TableHeadRow?` /
   `?Chip?` / `?Checkbox?` / `?Alert?` / `?Avatar?` / `?Badge?` / `?Spacing?` / `usability icon container` /
   `_Native Browser Scroll` twice each.
2. **The `[Mc…]`-prefixed twin.** Almost every family exists both as `[McAlert] ?Alert?` (the themed
   wrapper the library ships) *and* as bare `?Alert?` (the upstream MUI component it wraps). They are the
   same component; the prefix is a Figma-side bookkeeping convention.

**Every one of those pairs is built once, under the unprefixed name** — `Alert`, `Button`, `Chip`,
`Select`, `TextField`, `Typography`, and so on. Reading `[McAlert] ?Alert?` and `?Alert?` as two
components to build would ship two identical `Alert`s, which is worse for consumers than one.

## Intentional additions

**All 17 components the checker flags as "named after nothing in the kit" are confirmed here.** Four are
genuine additions; thirteen are direct builds of a source family whose Figma label is a bracketed string
(`[Mc…] ?…?`) that cannot be a JavaScript identifier. None is a guess, and none should be renamed — the
mechanical name (`McDataGridTableDataGridTable`) would be worse for every consumer who writes
`window.InspiraAdvisorMUILibrary_3f4835.DataGridTable`.

### Genuine additions (4)

- **`Icon`** — a React wrapper over the extracted glyph data. The source has icon *components*; this is
  the code shape that makes 98 of them addressable by name.
- **`GridToolbarMenu`** — one component covering the four standalone toolbar menus the file defines
  separately (`_?GridToolbarQuickFilter? / Columns Menu`, `… / Density Menu`, `… / Export Menu`,
  `… / Filters Menu`).
- **`DataGridColumnGroupRow`** — the row wrapper around `DataGridColumnGroupHeader`, matching
  `[McDataGrid | Header Rows | Column Group]`.
- **`InspiraButton`** — the H-B family is called plain `Button`, which collides with the MUI `Button`.
  Prefixed rather than renamed so the collision is visible at the call site.

### Bracketed-label builds (13)

| Component | Source family |
| --- | --- |
| `DataGridTable` | `[McDataGridTable] ?DataGridTable?` |
| `DataGridCell` | `[McDataGrid \| Cell] ?DataGrid? \| Cell` |
| `DataGridCellRow` | `[McDataGrid \| Cell Rows] ?DataGrid? \| Cell Rows` |
| `DataGridHeader` | `[McDataGrid \| Header] ?DataGrid? \| Header` |
| `DataGridHeaderRow` | `[McDataGrid \| Header Rows] ?DataGrid? \| Header Rows` |
| `DataGridGroupingCell` | `[McDataGrid \| Grouping Cell] ?DataGrid? \| Grouping Cell` |
| `DataGridColumnGroupHeader` | `[McDataGrid \| Header \| Column Group]` |
| `GridToolbarQuickFilter` | `[MCGridToolbarQuickFilter] ?GridToolbarQuickFilter?` |
| `DetailPanelContent` | `_Custom / My Detail Panel Content` |
| `Progress` | `[McProgress] ?Progress? \| Circular` |
| `CardElements` | `[MCCard Elements] Card Elements` |
| `Spacing` | `[MCSpacing] Spacing \| Horizontal` |
| `TableColumns` | `🚧 Table Columns (detachable)` |

## Naming map

Where a Figma family name couldn't be a JS identifier, this is the mapping:

| Figma family | Component |
| --- | --- |
| `[McButton] <Button>` | `Button` |
| `Button` (H-B) | `InspiraButton` |
| `Icon Buttons` (H-B) | `IconButtons` |
| `Action Buttons (On White)` | `ActionButtonsOnWhite` |
| `Filter Chips` | `FilterChips` |
| `Primary input (Vert)` | `PrimaryInputVert` |
| `_input box` | `InputBox` |
| `Loading` | `Loading` |
| `[McProgress] <Progress> \| Circular` | `Progress` |
| `.Helpers / Field` | `HelpersField` |
| `.Helpers / Text` | `HelpersText` |
| `.Helpers/button-icon-container` | `HelpersButtonIconContainer` |
| `.Helpers/Table Cells` | `HelpersTableCells` |
| `.Helpers/Table cell content` | `HelpersTableCellContent` |
| `.Helpers/Table Actions` | `HelpersTableActions` |
| `.Helpers/Table Title` | `HelpersTableTitle` |
| `_Custom / Table / Toolbar` | `CustomTableToolbar` |
| `_Custom / Table / Custom Cell` | `CustomTableCustomCell` |
| `🚧 Table Columns (detachable)` | `TableColumns` |
| `_Custom / My Detail Panel Content` | `DetailPanelContent` |
| `_Native Browser Scroll` | `NativeBrowserScroll` |
| `_Library / Component Heading` | `LibraryComponentHeading` |
| `_Library / Instance Slot` | `LibraryInstanceSlot` |
| `usability icon container` | `UsabilityIconContainer` |
| `_Eye Icon Toggle` / `_Lock Icon Toggle` | `EyeIconToggle` / `LockIconToggle` |
| `Standalone link` / `Text Action` | `StandaloneLink` / `TextAction` |
| `Hide Text Overflow` | `HideTextOverflow` |
| `Label and Tooltip Trigger` | `LabelAndTooltipTrigger` |
| `Vertical Trigger` | `VerticalTrigger` |
| `Tooltip Bubble` | `TooltipBubble` |
| `Error Message` | `ErrorMessage` |
| `[MCCard Elements]` | `CardElements` |
| `[MCListItemSubItem]` | `ListItemSubItem` |
| `[McTypography Plus]` | folded into `Typography` (its `custom` variant + icon slots) |

## Using it

```html
<link rel="stylesheet" href="styles.css">
<script src="_ds_bundle.js"></script>
<script type="text/babel">
  const { Button, DataGridTable, Alert } = window.InspiraAdvisorMUILibrary_3f4835;
</script>
```

Style with the tokens, never with raw hex: `var(--primary-main)`, `var(--surface-card)`,
`var(--radius-md)`, `var(--shadow-1)`, `var(--text-secondary)`.
