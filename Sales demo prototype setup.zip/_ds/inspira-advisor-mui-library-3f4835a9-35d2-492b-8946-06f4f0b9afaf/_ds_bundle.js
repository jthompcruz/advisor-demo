/* @ds-bundle: {"format":4,"namespace":"InspiraAdvisorMUILibrary_3f4835","components":[{"name":"Icon","sourcePath":"assets/icons/Icon.jsx"},{"name":"Divider","sourcePath":"components/core/Divider.jsx"},{"name":"NativeBrowserScroll","sourcePath":"components/core/NativeBrowserScroll.jsx"},{"name":"Paper","sourcePath":"components/core/Paper.jsx"},{"name":"Spacing","sourcePath":"components/core/Spacing.jsx"},{"name":"Stack","sourcePath":"components/core/Stack.jsx"},{"name":"Typography","sourcePath":"components/core/Typography.jsx"},{"name":"Avatar","sourcePath":"components/data-display/Avatar.jsx"},{"name":"AvatarGroup","sourcePath":"components/data-display/AvatarGroup.jsx"},{"name":"Badge","sourcePath":"components/data-display/Badge.jsx"},{"name":"Chip","sourcePath":"components/data-display/Chip.jsx"},{"name":"Link","sourcePath":"components/data-display/Link.jsx"},{"name":"List","sourcePath":"components/data-display/List.jsx"},{"name":"ListItem","sourcePath":"components/data-display/ListItem.jsx"},{"name":"ListItemSubItem","sourcePath":"components/data-display/ListItemSubItem.jsx"},{"name":"ListSubheader","sourcePath":"components/data-display/ListSubheader.jsx"},{"name":"DataGridCell","sourcePath":"components/data-grid/DataGridCell.jsx"},{"name":"DataGridCellRow","sourcePath":"components/data-grid/DataGridCellRow.jsx"},{"name":"DataGridColumnGroupHeader","sourcePath":"components/data-grid/DataGridColumnGroupHeader.jsx"},{"name":"DataGridColumnGroupRow","sourcePath":"components/data-grid/DataGridColumnGroupRow.jsx"},{"name":"DataGridGroupingCell","sourcePath":"components/data-grid/DataGridGroupingCell.jsx"},{"name":"DataGridHeader","sourcePath":"components/data-grid/DataGridHeader.jsx"},{"name":"DataGridHeaderRow","sourcePath":"components/data-grid/DataGridHeaderRow.jsx"},{"name":"DataGridTable","sourcePath":"components/data-grid/DataGridTable.jsx"},{"name":"DetailPanelContent","sourcePath":"components/data-grid/DetailPanelContent.jsx"},{"name":"GridToolbarMenu","sourcePath":"components/data-grid/GridToolbarMenu.jsx"},{"name":"GridToolbarQuickFilter","sourcePath":"components/data-grid/GridToolbarQuickFilter.jsx"},{"name":"Alert","sourcePath":"components/feedback/Alert.jsx"},{"name":"Loading","sourcePath":"components/feedback/Loading.jsx"},{"name":"Progress","sourcePath":"components/feedback/Progress.jsx"},{"name":"TooltipBubble","sourcePath":"components/feedback/TooltipBubble.jsx"},{"name":"Autocomplete","sourcePath":"components/inputs/Autocomplete.jsx"},{"name":"Button","sourcePath":"components/inputs/Button.jsx"},{"name":"ButtonGroup","sourcePath":"components/inputs/ButtonGroup.jsx"},{"name":"Checkbox","sourcePath":"components/inputs/Checkbox.jsx"},{"name":"EyeIconToggle","sourcePath":"components/inputs/EyeIconToggle.jsx"},{"name":"FormControlLabel","sourcePath":"components/inputs/FormControlLabel.jsx"},{"name":"FormGroup","sourcePath":"components/inputs/FormGroup.jsx"},{"name":"FormHelperText","sourcePath":"components/inputs/FormHelperText.jsx"},{"name":"FormLabel","sourcePath":"components/inputs/FormLabel.jsx"},{"name":"HelpersButtonIconContainer","sourcePath":"components/inputs/HelpersButtonIconContainer.jsx"},{"name":"HelpersField","sourcePath":"components/inputs/HelpersField.jsx"},{"name":"HelpersText","sourcePath":"components/inputs/HelpersText.jsx"},{"name":"IconButton","sourcePath":"components/inputs/IconButton.jsx"},{"name":"LoadingButton","sourcePath":"components/inputs/LoadingButton.jsx"},{"name":"LockIconToggle","sourcePath":"components/inputs/LockIconToggle.jsx"},{"name":"Rating","sourcePath":"components/inputs/Rating.jsx"},{"name":"Select","sourcePath":"components/inputs/Select.jsx"},{"name":"Star","sourcePath":"components/inputs/Star.jsx"},{"name":"Switch","sourcePath":"components/inputs/Switch.jsx"},{"name":"TextField","sourcePath":"components/inputs/TextField.jsx"},{"name":"TextFieldMultiline","sourcePath":"components/inputs/TextFieldMultiline.jsx"},{"name":"ActionButtonsOnWhite","sourcePath":"components/inspira/ActionButtonsOnWhite.jsx"},{"name":"ErrorMessage","sourcePath":"components/inspira/ErrorMessage.jsx"},{"name":"FilterChips","sourcePath":"components/inspira/FilterChips.jsx"},{"name":"HideTextOverflow","sourcePath":"components/inspira/HideTextOverflow.jsx"},{"name":"IconButtons","sourcePath":"components/inspira/IconButtons.jsx"},{"name":"InputBox","sourcePath":"components/inspira/InputBox.jsx"},{"name":"InspiraButton","sourcePath":"components/inspira/InspiraButton.jsx"},{"name":"LabelAndTooltipTrigger","sourcePath":"components/inspira/LabelAndTooltipTrigger.jsx"},{"name":"PrimaryInputVert","sourcePath":"components/inspira/PrimaryInputVert.jsx"},{"name":"StandaloneLink","sourcePath":"components/inspira/StandaloneLink.jsx"},{"name":"TextAction","sourcePath":"components/inspira/TextAction.jsx"},{"name":"VerticalTrigger","sourcePath":"components/inspira/VerticalTrigger.jsx"},{"name":"Hidden","sourcePath":"components/library/Hidden.jsx"},{"name":"LibraryComponentHeading","sourcePath":"components/library/LibraryComponentHeading.jsx"},{"name":"LibraryComponentInformation","sourcePath":"components/library/LibraryComponentInformation.jsx"},{"name":"LibraryComponentProperties","sourcePath":"components/library/LibraryComponentProperties.jsx"},{"name":"LibraryInstanceSlot","sourcePath":"components/library/LibraryInstanceSlot.jsx"},{"name":"LibraryPlaceholderImage","sourcePath":"components/library/LibraryPlaceholderImage.jsx"},{"name":"UsabilityIconContainer","sourcePath":"components/library/UsabilityIconContainer.jsx"},{"name":"Menu","sourcePath":"components/navigation/Menu.jsx"},{"name":"MenuItem","sourcePath":"components/navigation/MenuItem.jsx"},{"name":"MenuList","sourcePath":"components/navigation/MenuList.jsx"},{"name":"Card","sourcePath":"components/surfaces/Card.jsx"},{"name":"CardActions","sourcePath":"components/surfaces/CardActions.jsx"},{"name":"CardContent","sourcePath":"components/surfaces/CardContent.jsx"},{"name":"CardElements","sourcePath":"components/surfaces/CardElements.jsx"},{"name":"CardHeader","sourcePath":"components/surfaces/CardHeader.jsx"},{"name":"CardMedia","sourcePath":"components/surfaces/CardMedia.jsx"},{"name":"CustomTableCustomCell","sourcePath":"components/tables/CustomTableCustomCell.jsx"},{"name":"CustomTableToolbar","sourcePath":"components/tables/CustomTableToolbar.jsx"},{"name":"HelpersTableActions","sourcePath":"components/tables/HelpersTableActions.jsx"},{"name":"HelpersTableCellContent","sourcePath":"components/tables/HelpersTableCellContent.jsx"},{"name":"HelpersTableCells","sourcePath":"components/tables/HelpersTableCells.jsx"},{"name":"HelpersTableTitle","sourcePath":"components/tables/HelpersTableTitle.jsx"},{"name":"Table","sourcePath":"components/tables/Table.jsx"},{"name":"TableCell","sourcePath":"components/tables/TableCell.jsx"},{"name":"TableCellRow","sourcePath":"components/tables/TableCellRow.jsx"},{"name":"TableColumns","sourcePath":"components/tables/TableColumns.jsx"},{"name":"TableFooter","sourcePath":"components/tables/TableFooter.jsx"},{"name":"TableHead","sourcePath":"components/tables/TableHead.jsx"},{"name":"TableHeadRow","sourcePath":"components/tables/TableHeadRow.jsx"}],"sourceHashes":{"assets/icons/Icon.jsx":"b98aa4f15e2b","assets/icons/icon-data.js":"9631264465f2","components/core/Divider.jsx":"17949c8f7b37","components/core/NativeBrowserScroll.jsx":"500e4cc71e0b","components/core/Paper.jsx":"c92f305ef116","components/core/Spacing.jsx":"9aed9c48ed17","components/core/Stack.jsx":"ae9884f0ee69","components/core/Typography.jsx":"35bb94712046","components/data-display/Avatar.jsx":"c7bd568d5cd2","components/data-display/AvatarGroup.jsx":"ce481f99736a","components/data-display/Badge.jsx":"cdecb394c5bb","components/data-display/Chip.jsx":"59503696ee39","components/data-display/Link.jsx":"0b0ff7832281","components/data-display/List.jsx":"e505b591c04c","components/data-display/ListItem.jsx":"d611aef0542c","components/data-display/ListItemSubItem.jsx":"30ebc8df335b","components/data-display/ListSubheader.jsx":"a8a456e5e9ae","components/data-grid/DataGridCell.jsx":"0d38447377f5","components/data-grid/DataGridCellRow.jsx":"fe0dcce9b0e6","components/data-grid/DataGridColumnGroupHeader.jsx":"c11421454f7f","components/data-grid/DataGridColumnGroupRow.jsx":"9df7cf404c7c","components/data-grid/DataGridGroupingCell.jsx":"a4e7c989014e","components/data-grid/DataGridHeader.jsx":"461ad2e40647","components/data-grid/DataGridHeaderRow.jsx":"387d00f58250","components/data-grid/DataGridTable.jsx":"d266750db490","components/data-grid/DetailPanelContent.jsx":"18591728a67f","components/data-grid/GridToolbarMenu.jsx":"5cc851e1d92f","components/data-grid/GridToolbarQuickFilter.jsx":"bb8e8c271be0","components/feedback/Alert.jsx":"f158aa01687d","components/feedback/Loading.jsx":"fb4b993264b4","components/feedback/Progress.jsx":"3308bceb5da2","components/feedback/TooltipBubble.jsx":"c53b2967c727","components/inputs/Autocomplete.jsx":"f80656db6dc6","components/inputs/Button.jsx":"259d2a9e5e29","components/inputs/ButtonGroup.jsx":"5609db7a6a90","components/inputs/Checkbox.jsx":"e6a91094475f","components/inputs/EyeIconToggle.jsx":"7b3a8d225986","components/inputs/FormControlLabel.jsx":"4da2cacbf1e3","components/inputs/FormGroup.jsx":"9e94e82fc089","components/inputs/FormHelperText.jsx":"a41f5a4c102c","components/inputs/FormLabel.jsx":"ec2f87d04d0a","components/inputs/HelpersButtonIconContainer.jsx":"7571b4fd64ba","components/inputs/HelpersField.jsx":"5acb6de36985","components/inputs/HelpersText.jsx":"4bea6a638ede","components/inputs/IconButton.jsx":"e9bff78d55ae","components/inputs/LoadingButton.jsx":"eb931a97bc46","components/inputs/LockIconToggle.jsx":"0cb61acf0777","components/inputs/Rating.jsx":"af34bb0fc14f","components/inputs/Select.jsx":"e2aa510161aa","components/inputs/Star.jsx":"f13e7b7e4f89","components/inputs/Switch.jsx":"9e77c802411a","components/inputs/TextField.jsx":"2cffe13802c3","components/inputs/TextFieldMultiline.jsx":"c47077c54aec","components/inspira/ActionButtonsOnWhite.jsx":"9f7b737632de","components/inspira/ErrorMessage.jsx":"1b41f47a0a1f","components/inspira/FilterChips.jsx":"a4dcb7d6cbfe","components/inspira/HideTextOverflow.jsx":"2ddca34522c2","components/inspira/IconButtons.jsx":"636bbe121efb","components/inspira/InputBox.jsx":"f271d06b8b13","components/inspira/InspiraButton.jsx":"1ecf8cd9607c","components/inspira/LabelAndTooltipTrigger.jsx":"e623d240515b","components/inspira/PrimaryInputVert.jsx":"83a13819878d","components/inspira/StandaloneLink.jsx":"425c5730d797","components/inspira/TextAction.jsx":"6a97723cd51c","components/inspira/VerticalTrigger.jsx":"c154039cbfae","components/library/Hidden.jsx":"6e7352690990","components/library/LibraryComponentHeading.jsx":"2f9691f10fb8","components/library/LibraryComponentInformation.jsx":"0869be6ba5e1","components/library/LibraryComponentProperties.jsx":"abc9586e0a2d","components/library/LibraryInstanceSlot.jsx":"a364b3fa28fa","components/library/LibraryPlaceholderImage.jsx":"231aa4a29a48","components/library/UsabilityIconContainer.jsx":"75c68bdb7b01","components/navigation/Menu.jsx":"5912dd7203b7","components/navigation/MenuItem.jsx":"1a9a97c2e096","components/navigation/MenuList.jsx":"7283d79b6f07","components/surfaces/Card.jsx":"07f50dc27b09","components/surfaces/CardActions.jsx":"ae35db9bf2d2","components/surfaces/CardContent.jsx":"dc2b7a509e30","components/surfaces/CardElements.jsx":"8b41338f90a1","components/surfaces/CardHeader.jsx":"cd71185083dd","components/surfaces/CardMedia.jsx":"1deafa7b881e","components/tables/CustomTableCustomCell.jsx":"3739b8fd9570","components/tables/CustomTableToolbar.jsx":"ad181cc0cbb0","components/tables/HelpersTableActions.jsx":"ab8d95c69f78","components/tables/HelpersTableCellContent.jsx":"962c13496e7e","components/tables/HelpersTableCells.jsx":"f005227e0512","components/tables/HelpersTableTitle.jsx":"696b30f7cfdd","components/tables/Table.jsx":"0cb71b359de0","components/tables/TableCell.jsx":"4a4da292cec7","components/tables/TableCellRow.jsx":"58a1fafede68","components/tables/TableColumns.jsx":"4a93046d7212","components/tables/TableFooter.jsx":"e66ec23e32b1","components/tables/TableHead.jsx":"1d28ad915771","components/tables/TableHeadRow.jsx":"6b4113cccda0","ui_kits/advisor-console/AccountDetailScreen.jsx":"541e7ad6e17d","ui_kits/advisor-console/AccountsScreen.jsx":"9c642230c997","ui_kits/advisor-console/HouseholdsScreen.jsx":"daeee5c1451e","ui_kits/advisor-console/Shell.jsx":"02ae2053abaf","ui_kits/participant-forms/ConfirmStep.jsx":"bba47118c23b","ui_kits/participant-forms/ContributeStep.jsx":"9f86274d7101","ui_kits/participant-forms/VerifyStep.jsx":"dcd939e24c0a"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.InspiraAdvisorMUILibrary_3f4835 = window.InspiraAdvisorMUILibrary_3f4835 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// assets/icons/icon-data.js
try { (() => {
// Generated by fig_materialize (moduleFormat: 'icon-data') — 98 icon(s)
// as { viewBox, body } SVG-markup entries. Render via the sibling Icon.jsx
// (<Icon name="AccessTimeFilled" />), or consume the path data directly.
let __ds_default_assets_icons_icon_data_imae2q;
try {
  __ds_default_assets_icons_icon_data_imae2q = {
    "AccessTimeFilled": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 9.99 0 C 15.52 0 20 4.48 20 10 C 20 15.52 15.52 20 9.99 20 C 4.47 20 0 15.52 0 10 C 0 4.48 4.47 0 9.99 0 Z M 10 2 C 5.58 2 2 5.58 2 10 C 2 14.42 5.58 18 10 18 C 14.42 18 18 14.42 18 10 C 18 5.58 14.42 2 10 2 Z M 10.5 5 L 10.5 10.25 L 15 12.92 L 14.25 14.15 L 9 11 L 9 5 L 10.5 5 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2 2)\"/>"
    },
    "AccountCircleFilled": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 10 0 C 4.48 0 0 4.48 0 10 C 0 15.52 4.48 20 10 20 C 15.52 20 20 15.52 20 10 C 20 4.48 15.52 0 10 0 Z M 10 3 C 11.66 3 13 4.34 13 6 C 13 7.66 11.66 9 10 9 C 8.34 9 7 7.66 7 6 C 7 4.34 8.34 3 10 3 Z M 10 17.2 C 7.5 17.2 5.29 15.92 4 13.98 C 4.03 11.99 8 10.9 10 10.9 C 11.99 10.9 15.97 11.99 16 13.98 C 14.71 15.92 12.5 17.2 10 17.2 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2 2)\"/>"
    },
    "AddFilled": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 14 8 L 8 8 L 8 14 L 6 14 L 6 8 L 0 8 L 0 6 L 6 6 L 6 0 L 8 0 L 8 6 L 14 6 L 14 8 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 5 5)\"/>"
    },
    "ApartmentFilled": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 14 8 L 14 0 L 4 0 L 4 4 L 0 4 L 0 18 L 8 18 L 8 14 L 10 14 L 10 18 L 18 18 L 18 8 L 14 8 Z M 4 16 L 2 16 L 2 14 L 4 14 L 4 16 Z M 4 12 L 2 12 L 2 10 L 4 10 L 4 12 Z M 4 8 L 2 8 L 2 6 L 4 6 L 4 8 Z M 8 12 L 6 12 L 6 10 L 8 10 L 8 12 Z M 8 8 L 6 8 L 6 6 L 8 6 L 8 8 Z M 8 4 L 6 4 L 6 2 L 8 2 L 8 4 Z M 12 12 L 10 12 L 10 10 L 12 10 L 12 12 Z M 12 8 L 10 8 L 10 6 L 12 6 L 12 8 Z M 12 4 L 10 4 L 10 2 L 12 2 L 12 4 Z M 16 16 L 14 16 L 14 14 L 16 14 L 16 16 Z M 16 12 L 14 12 L 14 10 L 16 10 L 16 12 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 3 3)\"/>"
    },
    "ArrowBackFilled": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 16 7 L 3.83 7 L 9.42 1.41 L 8 0 L 0 8 L 8 16 L 9.41 14.59 L 3.83 9 L 16 9 L 16 7 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 4 4)\"/>"
    },
    "ArrowDownwardFilled": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 16 8 L 14.59 6.59 L 9 12.17 L 9 0 L 7 0 L 7 12.17 L 1.42 6.58 L 0 8 L 8 16 L 16 8 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 4 4)\"/>"
    },
    "ArrowDropDownFilled": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 0 0 L 5 5 L 10 0 L 0 0 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 7 9.500)\"/>"
    },
    "ArrowDropUpFilled": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 0 5 L 5 0 L 10 5 L 0 5 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 7 9)\"/>"
    },
    "ArrowForwardFilled": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 8 0 L 6.59 1.41 L 12.17 7 L 0 7 L 0 9 L 12.17 9 L 6.59 14.59 L 8 16 L 16 8 L 8 0 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 4 4)\"/>"
    },
    "ArrowUpwardFilled": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 0 8 L 1.41 9.41 L 7 3.83 L 7 16 L 9 16 L 9 3.83 L 14.58 9.42 L 16 8 L 8 0 L 0 8 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 4 4)\"/>"
    },
    "BeachAccessFilled": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 10.126 11.559 L 11.556 10.129 L 17.996 16.572 L 16.569 17.999 L 10.126 11.559 Z M 14.419 5.829 L 17.279 2.969 C 13.329 -0.981 6.929 -0.991 2.979 2.949 C 6.909 1.649 11.289 2.699 14.419 5.829 L 14.419 5.829 Z M 2.949 2.979 C -0.991 6.929 -0.981 13.329 2.969 17.279 L 5.829 14.419 C 2.699 11.289 1.649 6.909 2.949 2.979 Z M 2.969 2.959 L 2.959 2.969 C 2.579 5.979 4.129 9.849 7.259 12.989 L 12.989 7.259 C 9.859 4.129 5.979 2.579 2.969 2.959 L 2.969 2.959 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 3.001 3.001)\"/>"
    },
    "BluetoothFilled": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 12.71 5.71 L 7 0 L 6 0 L 6 7.59 L 1.41 3 L 0 4.41 L 5.59 10 L 0 15.59 L 1.41 17 L 6 12.41 L 6 20 L 7 20 L 12.71 14.29 L 8.41 10 L 12.71 5.71 Z M 8 3.83 L 9.88 5.71 L 8 7.59 L 8 3.83 Z M 9.88 14.29 L 8 16.17 L 8 12.41 L 9.88 14.29 L 9.88 14.29 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 5 2)\"/>"
    },
    "CachedFilled": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 18 4 L 14 8 L 17 8 C 17 11.31 14.31 14 11 14 C 9.99 14 9.03 13.75 8.2 13.3 L 6.74 14.76 C 7.97 15.54 9.43 16 11 16 C 15.42 16 19 12.42 19 8 L 22 8 L 18 4 Z M 5 8 C 5 4.69 7.69 2 11 2 C 12.01 2 12.97 2.25 13.8 2.7 L 15.26 1.24 C 14.03 0.46 12.57 0 11 0 C 6.58 0 3 3.58 3 8 L 0 8 L 4 12 L 8 8 L 5 8 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 1 4)\"/>"
    },
    "CalendarTodayFilled": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 18 2 L 17 2 L 17 0 L 15 0 L 15 2 L 5 2 L 5 0 L 3 0 L 3 2 L 2 2 C 0.9 2 0 2.9 0 4 L 0 20 C 0 21.1 0.9 22 2 22 L 18 22 C 19.1 22 20 21.1 20 20 L 20 4 C 20 2.9 19.1 2 18 2 Z M 18 20 L 2 20 L 2 7 L 18 7 L 18 20 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2 1)\"/>"
    },
    "CancelFilled": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 10 0 C 4.47 0 0 4.47 0 10 C 0 15.53 4.47 20 10 20 C 15.53 20 20 15.53 20 10 C 20 4.47 15.53 0 10 0 Z M 15 13.59 L 13.59 15 L 10 11.41 L 6.41 15 L 5 13.59 L 8.59 10 L 5 6.41 L 6.41 5 L 10 8.59 L 13.59 5 L 15 6.41 L 11.41 10 L 15 13.59 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2 2)\"/>"
    },
    "CheckCircleFilled": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 10 0 C 4.48 0 0 4.48 0 10 C 0 15.52 4.48 20 10 20 C 15.52 20 20 15.52 20 10 C 20 4.48 15.52 0 10 0 Z M 8 15 L 3 10 L 4.41 8.59 L 8 12.17 L 15.59 4.58 L 17 6 L 8 15 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2 2)\"/>"
    },
    "CheckCircleOutlined": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 14.59 5.58 L 8 12.17 L 4.41 8.59 L 3 10 L 8 15 L 16 7 L 14.59 5.58 Z M 10 0 C 4.48 0 0 4.48 0 10 C 0 15.52 4.48 20 10 20 C 15.52 20 20 15.52 20 10 C 20 4.48 15.52 0 10 0 Z M 10 18 C 5.58 18 2 14.42 2 10 C 2 5.58 5.58 2 10 2 C 14.42 2 18 5.58 18 10 C 18 14.42 14.42 18 10 18 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2 2)\"/>"
    },
    "CheckFilled": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 5.59 10.58 L 1.42 6.41 L 0 7.82 L 5.59 13.41 L 17.59 1.41 L 16.18 0 L 5.59 10.58 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 3.205 5.295)\"/>"
    },
    "ChevronLeftFilled": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 7.41 1.41 L 6 0 L 0 6 L 6 12 L 7.41 10.59 L 2.83 6 L 7.41 1.41 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 8.295 6)\"/>"
    },
    "ChevronRightFilled": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 1.41 0 L 0 1.41 L 4.58 6 L 0 10.59 L 1.41 12 L 7.41 6 L 1.41 0 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 8.295 6)\"/>"
    },
    "CloseFilled": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 14 1.41 L 12.59 0 L 7 5.59 L 1.41 0 L 0 1.41 L 5.59 7 L 0 12.59 L 1.41 14 L 7 8.41 L 12.59 14 L 14 12.59 L 8.41 7 L 14 1.41 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 5 5)\"/>"
    },
    "CloudFilled": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 19.35 6.04 C 18.67 2.59 15.64 0 12 0 C 9.11 0 6.6 1.64 5.35 4.04 C 2.34 4.36 0 6.91 0 10 C 0 13.31 2.69 16 6 16 L 19 16 C 21.76 16 24 13.76 24 11 C 24 8.36 21.95 6.22 19.35 6.04 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 0 4)\"/>"
    },
    "CollectionsFilled": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 20 14 L 20 2 C 20 0.9 19.1 0 18 0 L 6 0 C 4.9 0 4 0.9 4 2 L 4 14 C 4 15.1 4.9 16 6 16 L 18 16 C 19.1 16 20 15.1 20 14 Z M 9 10 L 11.03 12.71 L 14 9 L 18 14 L 6 14 L 9 10 Z M 0 4 L 0 18 C 0 19.1 0.9 20 2 20 L 16 20 L 16 18 L 2 18 L 2 4 L 0 4 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2 2)\"/>"
    },
    "ContentCopyFilled": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 14 0 L 2 0 C 0.9 0 0 0.9 0 2 L 0 16 L 2 16 L 2 2 L 14 2 L 14 0 Z M 17 4 L 6 4 C 4.9 4 4 4.9 4 6 L 4 20 C 4 21.1 4.9 22 6 22 L 17 22 C 18.1 22 19 21.1 19 20 L 19 6 C 19 4.9 18.1 4 17 4 Z M 17 20 L 6 20 L 6 6 L 17 6 L 17 20 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2.500 1)\"/>"
    },
    "ContentCutFilled": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 4 18 C 5.105 18 6 17.105 6 16 C 6 14.895 5.105 14 4 14 C 2.895 14 2 14.895 2 16 C 2 17.105 2.895 18 4 18 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2 2)\"/><path d=\"M 10 10.5 C 10.276 10.5 10.5 10.276 10.5 10 C 10.5 9.724 10.276 9.5 10 9.5 C 9.724 9.5 9.5 9.724 9.5 10 C 9.5 10.276 9.724 10.5 10 10.5 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2 2)\"/><path d=\"M 4 6 C 5.105 6 6 5.105 6 4 C 6 2.895 5.105 2 4 2 C 2.895 2 2 2.895 2 4 C 2 5.105 2.895 6 4 6 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2 2)\"/><path d=\"M 7.64 5.64 C 7.87 5.14 8 4.59 8 4 C 8 1.79 6.21 0 4 0 C 1.79 0 0 1.79 0 4 C 0 6.21 1.79 8 4 8 C 4.59 8 5.14 7.87 5.64 7.64 L 8 10 L 5.64 12.36 C 5.14 12.13 4.59 12 4 12 C 1.79 12 0 13.79 0 16 C 0 18.21 1.79 20 4 20 C 6.21 20 8 18.21 8 16 C 8 15.41 7.87 14.86 7.64 14.36 L 10 12 L 17 19 L 20 19 L 20 18 L 7.64 5.64 Z M 4 6 C 2.9 6 2 5.11 2 4 C 2 2.89 2.9 2 4 2 C 5.1 2 6 2.89 6 4 C 6 5.11 5.1 6 4 6 Z M 4 18 C 2.9 18 2 17.11 2 16 C 2 14.89 2.9 14 4 14 C 5.1 14 6 14.89 6 16 C 6 17.11 5.1 18 4 18 Z M 10 10.5 C 9.72 10.5 9.5 10.28 9.5 10 C 9.5 9.72 9.72 9.5 10 9.5 C 10.28 9.5 10.5 9.72 10.5 10 C 10.5 10.28 10.28 10.5 10 10.5 Z M 17 1 L 11 7 L 13 9 L 20 2 L 20 1 L 17 1 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2 2)\"/>"
    },
    "ContentPasteOutlined": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 16 2 L 11.82 2 C 11.4 0.84 10.3 0 9 0 C 7.7 0 6.6 0.84 6.18 2 L 2 2 C 0.9 2 0 2.9 0 4 L 0 20 C 0 21.1 0.9 22 2 22 L 16 22 C 17.1 22 18 21.1 18 20 L 18 4 C 18 2.9 17.1 2 16 2 Z M 9 2 C 9.55 2 10 2.45 10 3 C 10 3.55 9.55 4 9 4 C 8.45 4 8 3.55 8 3 C 8 2.45 8.45 2 9 2 Z M 16 20 L 2 20 L 2 4 L 4 4 L 4 7 L 14 7 L 14 4 L 16 4 L 16 20 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 3 1)\"/>"
    },
    "CreditCardFilled": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 18 0 L 2 0 C 0.89 0 0.01 0.89 0.01 2 L 0 14 C 0 15.11 0.89 16 2 16 L 18 16 C 19.11 16 20 15.11 20 14 L 20 2 C 20 0.89 19.11 0 18 0 Z M 18 14 L 2 14 L 2 8 L 18 8 L 18 14 Z M 18 4 L 2 4 L 2 2 L 18 2 L 18 4 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2 4)\"/>"
    },
    "DateRangeFilled": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 6 9 L 4 9 L 4 11 L 6 11 L 6 9 Z M 10 9 L 8 9 L 8 11 L 10 11 L 10 9 Z M 14 9 L 12 9 L 12 11 L 14 11 L 14 9 Z M 16 2 L 15 2 L 15 0 L 13 0 L 13 2 L 5 2 L 5 0 L 3 0 L 3 2 L 2 2 C 0.89 2 0.01 2.9 0.01 4 L 0 18 C 0 19.1 0.89 20 2 20 L 16 20 C 17.1 20 18 19.1 18 18 L 18 4 C 18 2.9 17.1 2 16 2 Z M 16 18 L 2 18 L 2 7 L 16 7 L 16 18 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 3 2)\"/>"
    },
    "DeleteFilled": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 1 16 C 1 17.1 1.9 18 3 18 L 11 18 C 12.1 18 13 17.1 13 16 L 13 4 L 1 4 L 1 16 Z M 14 1 L 10.5 1 L 9.5 0 L 4.5 0 L 3.5 1 L 0 1 L 0 3 L 14 3 L 14 1 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 5 3)\"/>"
    },
    "DownloadFilled": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 0 17 L 14 17 L 14 15 L 0 15 L 0 17 Z M 14 6 L 10 6 L 10 0 L 4 0 L 4 6 L 0 6 L 7 13 L 14 6 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 5 3)\"/>"
    },
    "DraftsFilled": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 19.99 7 C 19.99 6.28 19.62 5.65 19.05 5.3 L 10 0 L 0.95 5.3 C 0.38 5.65 0 6.28 0 7 L 0 17 C 0 18.1 0.9 19 2 19 L 18 19 C 19.1 19 20 18.1 20 17 L 19.99 7 Z M 10 12 L 1.74 6.84 L 10 2 L 18.26 6.84 L 10 12 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2 1)\"/>"
    },
    "DragIndicatorFilled": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 4 14 C 4 15.1 3.1 16 2 16 C 0.9 16 0 15.1 0 14 C 0 12.9 0.9 12 2 12 C 3.1 12 4 12.9 4 14 Z M 2 6 C 0.9 6 0 6.9 0 8 C 0 9.1 0.9 10 2 10 C 3.1 10 4 9.1 4 8 C 4 6.9 3.1 6 2 6 Z M 2 0 C 0.9 0 0 0.9 0 2 C 0 3.1 0.9 4 2 4 C 3.1 4 4 3.1 4 2 C 4 0.9 3.1 0 2 0 Z M 8 4 C 9.1 4 10 3.1 10 2 C 10 0.9 9.1 0 8 0 C 6.9 0 6 0.9 6 2 C 6 3.1 6.9 4 8 4 Z M 8 6 C 6.9 6 6 6.9 6 8 C 6 9.1 6.9 10 8 10 C 9.1 10 10 9.1 10 8 C 10 6.9 9.1 6 8 6 Z M 8 12 C 6.9 12 6 12.9 6 14 C 6 15.1 6.9 16 8 16 C 9.1 16 10 15.1 10 14 C 10 12.9 9.1 12 8 12 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 7 4)\"/>"
    },
    "EditFilled": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 0 14.252 L 0 18.003 L 3.75 18.003 L 14.81 6.942 L 11.06 3.193 L 0 14.252 Z M 17.71 4.043 C 18.1 3.653 18.1 3.023 17.71 2.633 L 15.37 0.292 C 14.98 -0.097 14.35 -0.097 13.96 0.292 L 12.13 2.122 L 15.88 5.872 L 17.71 4.043 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2.999 2.999)\"/>"
    },
    "ErrorFilled": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 10 0 C 4.48 0 0 4.48 0 10 C 0 15.52 4.48 20 10 20 C 15.52 20 20 15.52 20 10 C 20 4.48 15.52 0 10 0 Z M 11 15 L 9 15 L 9 13 L 11 13 L 11 15 Z M 11 11 L 9 11 L 9 5 L 11 5 L 11 11 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2 2)\"/>"
    },
    "ErrorOutline": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 9 13 L 11 13 L 11 15 L 9 15 L 9 13 Z M 9 5 L 11 5 L 11 11 L 9 11 L 9 5 Z M 9.99 0 C 4.47 0 0 4.48 0 10 C 0 15.52 4.47 20 9.99 20 C 15.52 20 20 15.52 20 10 C 20 4.48 15.52 0 9.99 0 Z M 10 18 C 5.58 18 2 14.42 2 10 C 2 5.58 5.58 2 10 2 C 14.42 2 18 5.58 18 10 C 18 14.42 14.42 18 10 18 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2 2)\"/>"
    },
    "EventFilled": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 14 11 L 9 11 L 9 16 L 14 16 L 14 11 Z M 13 0 L 13 2 L 5 2 L 5 0 L 3 0 L 3 2 L 2 2 C 0.89 2 0.01 2.9 0.01 4 L 0 18 C 0 19.1 0.89 20 2 20 L 16 20 C 17.1 20 18 19.1 18 18 L 18 4 C 18 2.9 17.1 2 16 2 L 15 2 L 15 0 L 13 0 Z M 16 18 L 2 18 L 2 7 L 16 7 L 16 18 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 3 1)\"/>"
    },
    "ExpandLessFilled": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 6 0 L 0 6 L 1.41 7.41 L 6 2.83 L 10.59 7.41 L 12 6 L 6 0 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 6 8.295)\"/>"
    },
    "ExpandMoreFilled": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 10.59 0 L 6 4.58 L 1.41 0 L 0 1.41 L 6 7.41 L 12 1.41 L 10.59 0 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 6 8.295)\"/>"
    },
    "FavoriteFilled": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 10 18.35 L 8.55 17.03 C 3.4 12.36 0 9.28 0 5.5 C 0 2.42 2.42 0 5.5 0 C 7.24 0 8.91 0.81 10 2.09 C 11.09 0.81 12.76 0 14.5 0 C 17.58 0 20 2.42 20 5.5 C 20 9.28 16.6 12.36 11.45 17.04 L 10 18.35 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2 2.825)\"/>"
    },
    "FileDownloadFilled": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 14 6 L 10 6 L 10 0 L 4 0 L 4 6 L 0 6 L 7 13 L 14 6 Z M 0 15 L 0 17 L 14 17 L 14 15 L 0 15 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 5 3)\"/>"
    },
    "FilterAltFilled": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 0.212 1.61 C 2.232 4.2 5.962 9 5.962 9 L 5.962 15 C 5.962 15.55 6.412 16 6.962 16 L 8.962 16 C 9.512 16 9.962 15.55 9.962 15 L 9.962 9 C 9.962 9 13.682 4.2 15.702 1.61 C 16.212 0.95 15.742 0 14.912 0 L 1.002 0 C 0.172 0 -0.298 0.95 0.212 1.61 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 4.038 4)\"/>"
    },
    "FilterListFilled": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 7 12 L 11 12 L 11 10 L 7 10 L 7 12 Z M 0 0 L 0 2 L 18 2 L 18 0 L 0 0 Z M 3 7 L 15 7 L 15 5 L 3 5 L 3 7 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 3 6)\"/>"
    },
    "FolderFilled": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 8 0 L 2 0 C 0.9 0 0.01 0.9 0.01 2 L 0 14 C 0 15.1 0.9 16 2 16 L 18 16 C 19.1 16 20 15.1 20 14 L 20 4 C 20 2.9 19.1 2 18 2 L 10 2 L 8 0 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2 4)\"/>"
    },
    "FormatAlignLeftFilled": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 12 12 L 0 12 L 0 14 L 12 14 L 12 12 Z M 12 4 L 0 4 L 0 6 L 12 6 L 12 4 Z M 0 10 L 18 10 L 18 8 L 0 8 L 0 10 Z M 0 18 L 18 18 L 18 16 L 0 16 L 0 18 Z M 0 0 L 0 2 L 18 2 L 18 0 L 0 0 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 3 3)\"/>"
    },
    "HomeFilled": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 8 17 L 8 11 L 12 11 L 12 17 L 17 17 L 17 9 L 20 9 L 10 0 L 0 9 L 3 9 L 3 17 L 8 17 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2 3)\"/>"
    },
    "InboxFilled": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 16 0 L 1.99 0 C 0.88 0 0.01 0.89 0.01 2 L 0 16 C 0 17.1 0.88 18 1.99 18 L 16 18 C 17.1 18 18 17.1 18 16 L 18 2 C 18 0.89 17.1 0 16 0 Z M 16 12 L 12 12 C 12 13.66 10.65 15 9 15 C 7.35 15 6 13.66 6 12 L 1.99 12 L 1.99 2 L 16 2 L 16 12 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 3 3)\"/>"
    },
    "InfoFilled": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 10 0 C 4.48 0 0 4.48 0 10 C 0 15.52 4.48 20 10 20 C 15.52 20 20 15.52 20 10 C 20 4.48 15.52 0 10 0 Z M 11 15 L 9 15 L 9 9 L 11 9 L 11 15 Z M 11 7 L 9 7 L 9 5 L 11 5 L 11 7 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2 2)\"/>"
    },
    "InfoOutlined": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 9 5 L 11 5 L 11 7 L 9 7 L 9 5 Z M 9 9 L 11 9 L 11 15 L 9 15 L 9 9 Z M 10 0 C 4.48 0 0 4.48 0 10 C 0 15.52 4.48 20 10 20 C 15.52 20 20 15.52 20 10 C 20 4.48 15.52 0 10 0 Z M 10 18 C 5.59 18 2 14.41 2 10 C 2 5.59 5.59 2 10 2 C 14.41 2 18 5.59 18 10 C 18 14.41 14.41 18 10 18 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2 2)\"/>"
    },
    "LayersFilled": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 8.99 16.54 L 1.62 10.81 L 0 12.07 L 9 19.07 L 18 12.07 L 16.37 10.8 L 8.99 16.54 L 8.99 16.54 Z M 9 14 L 16.36 8.27 L 18 7 L 9 0 L 0 7 L 1.63 8.27 L 9 14 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 3 2)\"/>"
    },
    "LocationOnFilled": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 7 0 C 3.13 0 0 3.13 0 7 C 0 12.25 7 20 7 20 C 7 20 14 12.25 14 7 C 14 3.13 10.87 0 7 0 Z M 7 9.5 C 5.62 9.5 4.5 8.38 4.5 7 C 4.5 5.62 5.62 4.5 7 4.5 C 8.38 4.5 9.5 5.62 9.5 7 C 9.5 8.38 8.38 9.5 7 9.5 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 5 2)\"/>"
    },
    "LockFilled": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 14 7 L 13 7 L 13 5 C 13 2.24 10.76 0 8 0 C 5.24 0 3 2.24 3 5 L 3 7 L 2 7 C 0.9 7 0 7.9 0 9 L 0 19 C 0 20.1 0.9 21 2 21 L 14 21 C 15.1 21 16 20.1 16 19 L 16 9 C 16 7.9 15.1 7 14 7 Z M 8 16 C 6.9 16 6 15.1 6 14 C 6 12.9 6.9 12 8 12 C 9.1 12 10 12.9 10 14 C 10 15.1 9.1 16 8 16 Z M 11.1 7 L 4.9 7 L 4.9 5 C 4.9 3.29 6.29 1.9 8 1.9 C 9.71 1.9 11.1 3.29 11.1 5 L 11.1 7 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 4 1)\"/>"
    },
    "LogoutFilled": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 15 4 L 13.59 5.41 L 16.17 8 L 6 8 L 6 10 L 16.17 10 L 13.59 12.58 L 15 14 L 20 9 L 15 4 Z M 2 2 L 10 2 L 10 0 L 2 0 C 0.9 0 0 0.9 0 2 L 0 16 C 0 17.1 0.9 18 2 18 L 10 18 L 10 16 L 2 16 L 2 2 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2 3)\"/>"
    },
    "MailFilled": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 18 0 L 2 0 C 0.9 0 0.01 0.9 0.01 2 L 0 14 C 0 15.1 0.9 16 2 16 L 18 16 C 19.1 16 20 15.1 20 14 L 20 2 C 20 0.9 19.1 0 18 0 Z M 18 4 L 10 9 L 2 4 L 2 2 L 10 7 L 18 2 L 18 4 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2 4)\"/>"
    },
    "MailOutlineFilled": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 18 0 L 2 0 C 0.9 0 0.01 0.9 0.01 2 L 0 14 C 0 15.1 0.9 16 2 16 L 18 16 C 19.1 16 20 15.1 20 14 L 20 2 C 20 0.9 19.1 0 18 0 Z M 18 14 L 2 14 L 2 4 L 10 9 L 18 4 L 18 14 Z M 10 7 L 2 2 L 18 2 L 10 7 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2 4)\"/>"
    },
    "MenuFilled": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 0 12 L 18 12 L 18 10 L 0 10 L 0 12 Z M 0 7 L 18 7 L 18 5 L 0 5 L 0 7 Z M 0 0 L 0 2 L 18 2 L 18 0 L 0 0 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 3 6)\"/>"
    },
    "MonitorFilled": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 18 0 L 2 0 C 0.9 0 0 0.9 0 2 L 0 13 C 0 14.1 0.9 15 2 15 L 5 15 L 4 16 L 4 18 L 16 18 L 16 16 L 15 15 L 18 15 C 19.1 15 20 14.1 20 13 L 20 2 C 20 0.9 19.1 0 18 0 Z M 18 13 L 2 13 L 2 2 L 18 2 L 18 13 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2 3)\"/>"
    },
    "MoreHorizFilled": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 2 0 C 0.9 0 0 0.9 0 2 C 0 3.1 0.9 4 2 4 C 3.1 4 4 3.1 4 2 C 4 0.9 3.1 0 2 0 Z M 14 0 C 12.9 0 12 0.9 12 2 C 12 3.1 12.9 4 14 4 C 15.1 4 16 3.1 16 2 C 16 0.9 15.1 0 14 0 Z M 8 0 C 6.9 0 6 0.9 6 2 C 6 3.1 6.9 4 8 4 C 9.1 4 10 3.1 10 2 C 10 0.9 9.1 0 8 0 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 4 10)\"/>"
    },
    "MoreVertFilled": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 2 4 C 3.1 4 4 3.1 4 2 C 4 0.9 3.1 0 2 0 C 0.9 0 0 0.9 0 2 C 0 3.1 0.9 4 2 4 Z M 2 6 C 0.9 6 0 6.9 0 8 C 0 9.1 0.9 10 2 10 C 3.1 10 4 9.1 4 8 C 4 6.9 3.1 6 2 6 Z M 2 12 C 0.9 12 0 12.9 0 14 C 0 15.1 0.9 16 2 16 C 3.1 16 4 15.1 4 14 C 4 12.9 3.1 12 2 12 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 10 4)\"/>"
    },
    "NotificationsFilled": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 8 19.5 C 9.1 19.5 10 18.6 10 17.5 L 6 17.5 C 6 18.6 6.89 19.5 8 19.5 Z M 14 13.5 L 14 8.5 C 14 5.43 12.36 2.86 9.5 2.18 L 9.5 1.5 C 9.5 0.67 8.83 0 8 0 C 7.17 0 6.5 0.67 6.5 1.5 L 6.5 2.18 C 3.63 2.86 2 5.42 2 8.5 L 2 13.5 L 0 15.5 L 0 16.5 L 16 16.5 L 16 15.5 L 14 13.5 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 4 2.250)\"/>"
    },
    "OpeninNewFilled": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 16 16 L 2 16 L 2 2 L 9 2 L 9 0 L 2 0 C 0.89 0 0 0.9 0 2 L 0 16 C 0 17.1 0.89 18 2 18 L 16 18 C 17.1 18 18 17.1 18 16 L 18 9 L 16 9 L 16 16 Z M 11 0 L 11 2 L 14.59 2 L 4.76 11.83 L 6.17 13.24 L 16 3.41 L 16 7 L 18 7 L 18 0 L 11 0 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 3 3)\"/>"
    },
    "PeopleFilled": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 15 6 C 16.66 6 17.99 4.66 17.99 3 C 17.99 1.34 16.66 0 15 0 C 13.34 0 12 1.34 12 3 C 12 4.66 13.34 6 15 6 Z M 7 6 C 8.66 6 9.99 4.66 9.99 3 C 9.99 1.34 8.66 0 7 0 C 5.34 0 4 1.34 4 3 C 4 4.66 5.34 6 7 6 Z M 7 8 C 4.67 8 0 9.17 0 11.5 L 0 14 L 14 14 L 14 11.5 C 14 9.17 9.33 8 7 8 Z M 15 8 C 14.71 8 14.38 8.02 14.03 8.05 C 15.19 8.89 16 10.02 16 11.5 L 16 14 L 22 14 L 22 11.5 C 22 9.17 17.33 8 15 8 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 1 5)\"/>"
    },
    "PersonAddFilled": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 14 8 C 16.21 8 18 6.21 18 4 C 18 1.79 16.21 0 14 0 C 11.79 0 10 1.79 10 4 C 10 6.21 11.79 8 14 8 Z M 5 6 L 5 3 L 3 3 L 3 6 L 0 6 L 0 8 L 3 8 L 3 11 L 5 11 L 5 8 L 8 8 L 8 6 L 5 6 Z M 14 10 C 11.33 10 6 11.34 6 14 L 6 16 L 22 16 L 22 14 C 22 11.34 16.67 10 14 10 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 1 4)\"/>"
    },
    "PersonFilled": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 8 8 C 10.21 8 12 6.21 12 4 C 12 1.79 10.21 0 8 0 C 5.79 0 4 1.79 4 4 C 4 6.21 5.79 8 8 8 Z M 8 10 C 5.33 10 0 11.34 0 14 L 0 16 L 16 16 L 16 14 C 16 11.34 10.67 10 8 10 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 4 4)\"/>"
    },
    "PhoneIphoneFilled": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 10.5 0 L 2.5 0 C 1.12 0 0 1.12 0 2.5 L 0 19.5 C 0 20.88 1.12 22 2.5 22 L 10.5 22 C 11.88 22 13 20.88 13 19.5 L 13 2.5 C 13 1.12 11.88 0 10.5 0 Z M 6.5 21 C 5.67 21 5 20.33 5 19.5 C 5 18.67 5.67 18 6.5 18 C 7.33 18 8 18.67 8 19.5 C 8 20.33 7.33 21 6.5 21 Z M 11 17 L 2 17 L 2 3 L 11 3 L 11 17 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 5 1)\"/>"
    },
    "PhotoFilled": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 18 16 L 18 2 C 18 0.9 17.1 0 16 0 L 2 0 C 0.9 0 0 0.9 0 2 L 0 16 C 0 17.1 0.9 18 2 18 L 16 18 C 17.1 18 18 17.1 18 16 Z M 5.5 10.5 L 8 13.51 L 11.5 9 L 16 15 L 2 15 L 5.5 10.5 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 3 3)\"/>"
    },
    "PhotoOutlined": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 16 2 L 16 16 L 2 16 L 2 2 L 16 2 Z M 16 0 L 2 0 C 0.9 0 0 0.9 0 2 L 0 16 C 0 17.1 0.9 18 2 18 L 16 18 C 17.1 18 18 17.1 18 16 L 18 2 C 18 0.9 17.1 0 16 0 Z M 11.14 8.86 L 8.14 12.73 L 6 10.14 L 3 14 L 15 14 L 11.14 8.86 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 3 3)\"/>"
    },
    "PlayArrowFilled": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 0 0 L 0 14 L 11 7 L 0 0 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 8 5)\"/>"
    },
    "PlayCircleOutlineFilled": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 8 14.5 L 14 10 L 8 5.5 L 8 14.5 Z M 10 0 C 4.48 0 0 4.48 0 10 C 0 15.52 4.48 20 10 20 C 15.52 20 20 15.52 20 10 C 20 4.48 15.52 0 10 0 Z M 10 18 C 5.59 18 2 14.41 2 10 C 2 5.59 5.59 2 10 2 C 14.41 2 18 5.59 18 10 C 18 14.41 14.41 18 10 18 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2 2)\"/>"
    },
    "QueryBuilderFilled": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 9.99 0 C 4.47 0 0 4.48 0 10 C 0 15.52 4.47 20 9.99 20 C 15.52 20 20 15.52 20 10 C 20 4.48 15.52 0 9.99 0 Z M 10 18 C 5.58 18 2 14.42 2 10 C 2 5.58 5.58 2 10 2 C 14.42 2 18 5.58 18 10 C 18 14.42 14.42 18 10 18 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2 2)\"/><path d=\"M 10.5 5 L 9 5 L 9 11 L 14.25 14.15 L 15 12.92 L 10.5 10.25 L 10.5 5 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2 2)\"/>"
    },
    "ReceiptFilled": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 15 15 L 3 15 L 3 13 L 15 13 L 15 15 Z M 15 11 L 3 11 L 3 9 L 15 9 L 15 11 Z M 15 7 L 3 7 L 3 5 L 15 5 L 15 7 Z M 0 20 L 1.5 18.5 L 3 20 L 4.5 18.5 L 6 20 L 7.5 18.5 L 9 20 L 10.5 18.5 L 12 20 L 13.5 18.5 L 15 20 L 16.5 18.5 L 18 20 L 18 0 L 16.5 1.5 L 15 0 L 13.5 1.5 L 12 0 L 10.5 1.5 L 9 0 L 7.5 1.5 L 6 0 L 4.5 1.5 L 3 0 L 1.5 1.5 L 0 0 L 0 20 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 3 2)\"/>"
    },
    "RemoveFilled": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 14 2 L 0 2 L 0 0 L 14 0 L 14 2 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 5 11)\"/>"
    },
    "RemoveRedEyeFilled": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 11 0 C 6 0 1.73 3.11 0 7.5 C 1.73 11.89 6 15 11 15 C 16 15 20.27 11.89 22 7.5 C 20.27 3.11 16 0 11 0 Z M 11 12.5 C 8.24 12.5 6 10.26 6 7.5 C 6 4.74 8.24 2.5 11 2.5 C 13.76 2.5 16 4.74 16 7.5 C 16 10.26 13.76 12.5 11 12.5 Z M 11 4.5 C 9.34 4.5 8 5.84 8 7.5 C 8 9.16 9.34 10.5 11 10.5 C 12.66 10.5 14 9.16 14 7.5 C 14 5.84 12.66 4.5 11 4.5 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 1 4.500)\"/>"
    },
    "SaveAltFilled": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 16 9 L 16 16 L 2 16 L 2 9 L 0 9 L 0 16 C 0 17.1 0.9 18 2 18 L 16 18 C 17.1 18 18 17.1 18 16 L 18 9 L 16 9 Z M 10 9.67 L 12.59 7.09 L 14 8.5 L 9 13.5 L 4 8.5 L 5.41 7.09 L 8 9.67 L 8 0 L 10 0 L 10 9.67 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 3 3)\"/>"
    },
    "SearchFilled": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 12.5 11 L 11.71 11 L 11.43 10.73 C 12.41 9.59 13 8.11 13 6.5 C 13 2.91 10.09 0 6.5 0 C 2.91 0 0 2.91 0 6.5 C 0 10.09 2.91 13 6.5 13 C 8.11 13 9.59 12.41 10.73 11.43 L 11 11.71 L 11 12.5 L 16 17.49 L 17.49 16 L 12.5 11 Z M 6.5 11 C 4.01 11 2 8.99 2 6.5 C 2 4.01 4.01 2 6.5 2 C 8.99 2 11 4.01 11 6.5 C 11 8.99 8.99 11 6.5 11 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 3.255 3.255)\"/>"
    },
    "SendFilled": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 0.01 18 L 21 9 L 0.01 0 L 0 7 L 15 9 L 0 11 L 0.01 18 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2 3)\"/>"
    },
    "SettingsFilled": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 16.478 10.54 C 16.518 10.24 16.538 9.93 16.538 9.6 C 16.538 9.28 16.518 8.96 16.468 8.66 L 18.498 7.08 C 18.678 6.94 18.728 6.67 18.618 6.47 L 16.698 3.15 C 16.578 2.93 16.328 2.86 16.108 2.93 L 13.718 3.89 C 13.218 3.51 12.688 3.19 12.098 2.95 L 11.738 0.41 C 11.698 0.17 11.498 0 11.258 0 L 7.418 0 C 7.178 0 6.988 0.17 6.948 0.41 L 6.588 2.95 C 5.998 3.19 5.458 3.52 4.968 3.89 L 2.578 2.93 C 2.358 2.85 2.108 2.93 1.988 3.15 L 0.078 6.47 C -0.042 6.68 -0.002 6.94 0.198 7.08 L 2.228 8.66 C 2.178 8.96 2.138 9.29 2.138 9.6 C 2.138 9.91 2.158 10.24 2.208 10.54 L 0.178 12.12 C -0.002 12.26 -0.052 12.53 0.058 12.73 L 1.978 16.05 C 2.098 16.27 2.348 16.34 2.568 16.27 L 4.958 15.31 C 5.458 15.69 5.988 16.01 6.578 16.25 L 6.938 18.79 C 6.988 19.03 7.178 19.2 7.418 19.2 L 11.258 19.2 C 11.498 19.2 11.698 19.03 11.728 18.79 L 12.088 16.25 C 12.678 16.01 13.218 15.69 13.708 15.31 L 16.098 16.27 C 16.318 16.35 16.568 16.27 16.688 16.05 L 18.608 12.73 C 18.728 12.51 18.678 12.26 18.488 12.12 L 16.478 10.54 Z M 9.338 13.2 C 7.358 13.2 5.738 11.58 5.738 9.6 C 5.738 7.62 7.358 6 9.338 6 C 11.318 6 12.938 7.62 12.938 9.6 C 12.938 11.58 11.318 13.2 9.338 13.2 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2.662 2.400)\"/>"
    },
    "ShoppingCartFilled": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 6 16 C 4.9 16 4.01 16.9 4.01 18 C 4.01 19.1 4.9 20 6 20 C 7.1 20 8 19.1 8 18 C 8 16.9 7.1 16 6 16 Z M 0 0 L 0 2 L 2 2 L 5.6 9.59 L 4.25 12.04 C 4.09 12.32 4 12.65 4 13 C 4 14.1 4.9 15 6 15 L 18 15 L 18 13 L 6.42 13 C 6.28 13 6.17 12.89 6.17 12.75 L 6.2 12.63 L 7.1 11 L 14.55 11 C 15.3 11 15.96 10.59 16.3 9.97 L 19.88 3.48 C 19.96 3.34 20 3.17 20 3 C 20 2.45 19.55 2 19 2 L 4.21 2 L 3.27 0 L 0 0 Z M 16 16 C 14.9 16 14.01 16.9 14.01 18 C 14.01 19.1 14.9 20 16 20 C 17.1 20 18 19.1 18 18 C 18 16.9 17.1 16 16 16 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2 2)\"/>"
    },
    "SkipNextFilled": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 0 12 L 8.5 6 L 0 0 L 0 12 Z M 10 0 L 10 12 L 12 12 L 12 0 L 10 0 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 6 6)\"/>"
    },
    "SkipPreviousFilled": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 0 0 L 2 0 L 2 12 L 0 12 L 0 0 Z M 3.5 6 L 12 12 L 12 0 L 3.5 6 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 6 6)\"/>"
    },
    "SpaceDashboardFilled": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 8 18 L 2 18 C 0.9 18 0 17.1 0 16 L 0 2 C 0 0.9 0.9 0 2 0 L 8 0 L 8 18 Z M 10 18 L 16 18 C 17.1 18 18 17.1 18 16 L 18 9 L 10 9 L 10 18 Z M 18 7 L 18 2 C 18 0.9 17.1 0 16 0 L 10 0 L 10 7 L 18 7 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 3 3)\"/>"
    },
    "SpaceDashboardOutlined": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 16 0 L 2 0 C 0.9 0 0 0.9 0 2 L 0 16 C 0 17.1 0.9 18 2 18 L 16 18 C 17.1 18 18 17.1 18 16 L 18 2 C 18 0.9 17.1 0 16 0 Z M 2 16 L 2 2 L 8 2 L 8 16 L 2 16 Z M 16 16 L 10 16 L 10 9 L 16 9 L 16 16 Z M 16 7 L 10 7 L 10 2 L 16 2 L 16 7 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 3 3)\"/>"
    },
    "StarBorderFilled": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 20 7.24 L 12.81 6.62 L 10 0 L 7.19 6.63 L 0 7.24 L 5.46 11.97 L 3.82 19 L 10 15.27 L 16.18 19 L 14.55 11.97 L 20 7.24 Z M 10 13.4 L 6.24 15.67 L 7.24 11.39 L 3.92 8.51 L 8.3 8.13 L 10 4.1 L 11.71 8.14 L 16.09 8.52 L 12.77 11.4 L 13.77 15.68 L 10 13.4 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2 2.500)\"/>"
    },
    "StarHalfFilled": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 20 7.24 L 12.81 6.62 L 10 0 L 7.19 6.63 L 0 7.24 L 5.46 11.97 L 3.82 19 L 10 15.27 L 16.18 19 L 14.55 11.97 L 20 7.24 Z M 10 13.4 L 10 4.1 L 11.71 8.14 L 16.09 8.52 L 12.77 11.4 L 13.77 15.68 L 10 13.4 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2 2.500)\"/>"
    },
    "StarOutlineFilled": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 20 7.24 L 12.81 6.62 L 10 0 L 7.19 6.63 L 0 7.24 L 5.46 11.97 L 3.82 19 L 10 15.27 L 16.18 19 L 14.55 11.97 L 20 7.24 Z M 10 13.4 L 6.24 15.67 L 7.24 11.39 L 3.92 8.51 L 8.3 8.13 L 10 4.1 L 11.71 8.14 L 16.09 8.52 L 12.77 11.4 L 13.77 15.68 L 10 13.4 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2 2.500)\"/>"
    },
    "StarSharp": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 10 15.27 L 16.18 19 L 14.54 11.97 L 20 7.24 L 12.81 6.63 L 10 0 L 7.19 6.63 L 0 7.24 L 5.46 11.97 L 3.82 19 L 10 15.27 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2 2.500)\"/>"
    },
    "SwapHorizOutlined": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 3.99 6 L 0 10 L 3.99 14 L 3.99 11 L 11 11 L 11 9 L 3.99 9 L 3.99 6 Z M 18 4 L 14.01 0 L 14.01 3 L 7 3 L 7 5 L 14.01 5 L 14.01 8 L 18 4 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 3 5)\"/>"
    },
    "TableRowsFilled": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 18 4 L 0 4 L 0 0 L 18 0 L 18 4 Z M 18 6 L 0 6 L 0 10 L 18 10 L 18 6 Z M 18 12 L 0 12 L 0 16 L 18 16 L 18 12 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 3 4)\"/>"
    },
    "TitleOutlined": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 0 0 L 0 3 L 5.5 3 L 5.5 15 L 8.5 15 L 8.5 3 L 14 3 L 14 0 L 0 0 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 5 4)\"/>"
    },
    "UnfoldMoreOutlined": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 4.59 2.83 L 7.76 6 L 9.17 4.59 L 4.59 0 L 0 4.59 L 1.42 6 L 4.59 2.83 Z M 4.59 15.17 L 1.42 12 L 0.01 13.41 L 4.59 18 L 9.18 13.41 L 7.76 12 L 4.59 15.17 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 7.410 3)\"/>"
    },
    "UploadFileFilled": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 10 0 L 2 0 C 0.9 0 0.01 0.9 0.01 2 L 0 18 C 0 19.1 0.89 20 1.99 20 L 14 20 C 15.1 20 16 19.1 16 18 L 16 6 L 10 0 Z M 14 18 L 2 18 L 2 2 L 9 2 L 9 7 L 14 7 L 14 18 Z M 4 13.01 L 5.41 14.42 L 7 12.84 L 7 17 L 9 17 L 9 12.84 L 10.59 14.43 L 12 13.01 L 8.01 9 L 4 13.01 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 4 2)\"/>"
    },
    "ViewColumnFilled": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 11.67 0 L 11.67 14 L 6.33 14 L 6.33 0 L 11.67 0 Z M 12.67 14 L 18 14 L 18 0 L 12.67 0 L 12.67 14 Z M 5.33 14 L 5.33 0 L 0 0 L 0 14 L 5.33 14 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 3 5)\"/>"
    },
    "ViewHeadlineFilled": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 0 10 L 16 10 L 16 8 L 0 8 L 0 10 Z M 0 14 L 16 14 L 16 12 L 0 12 L 0 14 Z M 0 6 L 16 6 L 16 4 L 0 4 L 0 6 Z M 0 0 L 0 2 L 16 2 L 16 0 L 0 0 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 4 5)\"/>"
    },
    "ViewModuleFilled": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 11.67 0 L 11.67 6.5 L 6.33 6.5 L 6.33 0 L 11.67 0 Z M 12.67 6.5 L 18 6.5 L 18 0 L 12.67 0 L 12.67 6.5 Z M 11.67 14 L 11.67 7.5 L 6.33 7.5 L 6.33 14 L 11.67 14 Z M 12.67 7.5 L 12.67 14 L 18 14 L 18 7.5 L 12.67 7.5 Z M 5.33 7.5 L 0 7.5 L 0 14 L 5.33 14 L 5.33 7.5 Z M 5.33 6.5 L 5.33 0 L 0 0 L 0 6.5 L 5.33 6.5 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 3 5)\"/>"
    },
    "ViewStreamFilled": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 0 12 L 0 10 C 0 8.9 0.9 8 2 8 L 16 8 C 17.1 8 18 8.9 18 10 L 18 12 C 18 13.1 17.1 14 16 14 L 2 14 C 0.9 14 0 13.1 0 12 Z M 0 2 L 0 4 C 0 5.1 0.9 6 2 6 L 16 6 C 17.1 6 18 5.1 18 4 L 18 2 C 18 0.9 17.1 0 16 0 L 2 0 C 0.9 0 0 0.9 0 2 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 3 5)\"/>"
    },
    "WarningAmberOutlined": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 11 3.99 L 18.53 17 L 3.47 17 L 11 3.99 Z M 11 0 L 0 19 L 22 19 L 11 0 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 1 2.500)\"/><path d=\"M 12 14 L 10 14 L 10 16 L 12 16 L 12 14 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 1 2.500)\"/><path d=\"M 12 8 L 10 8 L 10 13 L 12 13 L 12 8 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 1 2.500)\"/>"
    },
    "WarningFilled": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 0 19 L 22 19 L 11 0 L 0 19 Z M 12 16 L 10 16 L 10 14 L 12 14 L 12 16 Z M 12 12 L 10 12 L 10 8 L 12 8 L 12 12 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 1 2.500)\"/>"
    },
    "WifiFilled": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 0 4.553 L 2 6.553 C 6.97 1.583 15.03 1.583 20 6.553 L 22 4.553 C 15.93 -1.517 6.08 -1.517 0 4.553 Z M 8 12.552 L 11 15.552 L 14 12.552 C 12.35 10.892 9.66 10.892 8 12.552 Z M 4 8.552 L 6 10.552 C 8.76 7.792 13.24 7.792 16 10.552 L 18 8.552 C 14.14 4.693 7.87 4.693 4 8.552 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 1 4.447)\"/>"
    },
    "WorkFilled": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 18 4 L 14 4 L 14 2 C 14 0.89 13.11 0 12 0 L 8 0 C 6.89 0 6 0.89 6 2 L 6 4 L 2 4 C 0.89 4 0.01 4.89 0.01 6 L 0 17 C 0 18.11 0.89 19 2 19 L 18 19 C 19.11 19 20 18.11 20 17 L 20 6 C 20 4.89 19.11 4 18 4 Z M 12 4 L 8 4 L 8 2 L 12 2 L 12 4 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2 2)\"/>"
    }
  };
} catch {}
Object.assign(__ds_scope, { __ds_default_assets_icons_icon_data_imae2q });
})(); } catch (e) { __ds_ns.__errors.push({ path: "assets/icons/icon-data.js", error: String((e && e.message) || e) }); }

__ds_scope.__ds_default_assets_icons_icon_data_imae2q$nab192 = __ds_scope.__ds_default_assets_icons_icon_data_imae2q;

// assets/icons/Icon.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Usability / brand icon glyph. 98 glyphs extracted from the Figma library. */
function Icon({
  name,
  size = 20,
  color = 'currentColor',
  title,
  style,
  ...rest
}) {
  const d = __ds_scope.__ds_default_assets_icons_icon_data_imae2q$nab192[name];
  if (!d) return null;
  return /*#__PURE__*/React.createElement("svg", _extends({
    role: title ? 'img' : 'presentation',
    "aria-label": title,
    width: size,
    height: size,
    viewBox: d.viewBox,
    fill: "none",
    style: {
      display: 'block',
      color,
      flexShrink: 0,
      ...style
    }
    // body strings are emitter-controlled <path> markup — geometry,
    // numeric fills and transforms only; no .fig-authored text reaches them.
    ,
    dangerouslySetInnerHTML: {
      __html: d.body
    }
  }, rest));
}
Object.assign(__ds_scope, { Icon, __ds_default_assets_icons_Icon_2pj96j: Icon });
})(); } catch (e) { __ds_ns.__errors.push({ path: "assets/icons/Icon.jsx", error: String((e && e.message) || e) }); }

// components/core/Divider.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** <Divider> | Horizontal & Vertical. */
function Divider({
  orientation = 'horizontal',
  flexItem = false,
  children,
  style,
  ...rest
}) {
  if (children) {
    return /*#__PURE__*/React.createElement("div", _extends({
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 16,
        ...style
      }
    }, rest), /*#__PURE__*/React.createElement("span", {
      style: {
        flex: 1,
        height: 1,
        background: 'var(--border-divider)'
      }
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--font-ui)',
        fontSize: 14,
        lineHeight: 1.43,
        letterSpacing: '0.17px',
        color: 'var(--text-secondary)'
      }
    }, children), /*#__PURE__*/React.createElement("span", {
      style: {
        flex: 1,
        height: 1,
        background: 'var(--border-divider)'
      }
    }));
  }
  const vertical = orientation === 'vertical';
  return /*#__PURE__*/React.createElement("div", _extends({
    role: "separator",
    "aria-orientation": orientation,
    style: {
      background: 'var(--border-divider)',
      width: vertical ? 1 : '100%',
      height: vertical ? flexItem ? 'auto' : '100%' : 1,
      alignSelf: vertical && flexItem ? 'stretch' : undefined,
      flexShrink: 0,
      ...style
    }
  }, rest));
}
Object.assign(__ds_scope, { Divider });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Divider.jsx", error: String((e && e.message) || e) }); }

// components/core/NativeBrowserScroll.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** _Native Browser Scroll — the platform scrollbar the library draws in its specimens. */
function NativeBrowserScroll({
  orientation = 'vertical',
  style,
  ...rest
}) {
  const vertical = orientation === 'vertical';
  return /*#__PURE__*/React.createElement("div", _extends({
    "aria-hidden": "true",
    style: {
      width: vertical ? 15 : '100%',
      height: vertical ? '100%' : 15,
      background: 'var(--grey-100)',
      display: 'flex',
      flexDirection: vertical ? 'column' : 'row',
      alignItems: 'center',
      justifyContent: 'center',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      background: 'var(--native-scrollbar-bg, #616161)',
      borderRadius: 100,
      width: vertical ? 7 : '40%',
      height: vertical ? '40%' : 7
    }
  }));
}
Object.assign(__ds_scope, { NativeBrowserScroll });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/NativeBrowserScroll.jsx", error: String((e && e.message) || e) }); }

// components/core/Paper.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const SHADOWS = {
  0: 'none',
  1: 'var(--shadow-1)',
  2: 'var(--shadow-2)',
  4: 'var(--shadow-4)',
  8: 'var(--shadow-8)',
  16: 'var(--shadow-16)',
  24: 'var(--shadow-24)'
};
function shadow(e) {
  const keys = [0, 1, 2, 4, 8, 16, 24];
  const k = keys.reduce((a, b) => Math.abs(b - e) < Math.abs(a - e) ? b : a, 0);
  return SHADOWS[k];
}

/** <Paper> — the elevation surface behind cards, menus and dialogs. 25 elevation steps. */
function Paper({
  variant = 'elevation',
  elevation = 1,
  square = false,
  children,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      background: 'var(--surface-card)',
      color: 'var(--text-primary)',
      borderRadius: square ? 0 : 'var(--radius-md)',
      boxShadow: variant === 'outlined' ? 'none' : shadow(elevation),
      border: variant === 'outlined' ? '1px solid var(--border-divider)' : undefined,
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Paper });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Paper.jsx", error: String((e && e.message) || e) }); }

// components/core/Spacing.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const STEPS = [0, 4, 8, 16, 24, 32, 40, 48];

/** <Spacing | Horizontal> — the visible spacer token used in the Figma library's specimen sheets. */
function Spacing({
  step = 2,
  orientation = 'horizontal',
  visible = false,
  style,
  ...rest
}) {
  const size = STEPS[step] ?? step;
  const horizontal = orientation === 'horizontal';
  return /*#__PURE__*/React.createElement("div", _extends({
    "aria-hidden": "true",
    style: {
      width: horizontal ? size : '100%',
      height: horizontal ? '100%' : size,
      minWidth: horizontal ? size : undefined,
      minHeight: horizontal ? undefined : size,
      flexShrink: 0,
      background: visible ? 'var(--secondary-main)' : 'transparent',
      ...style
    }
  }, rest));
}
Object.assign(__ds_scope, { Spacing });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Spacing.jsx", error: String((e && e.message) || e) }); }

// components/core/Stack.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** <Stack> — the layout primitive. Spacing steps are multiples of 8px (semantic/spacing/1). */
function Stack({
  direction = 'column',
  spacing = 0,
  align,
  justify,
  wrap = false,
  divider,
  children,
  style,
  ...rest
}) {
  const items = React.Children.toArray(children);
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: 'flex',
      flexDirection: direction,
      gap: typeof spacing === 'number' ? spacing * 8 : spacing,
      alignItems: align,
      justifyContent: justify,
      flexWrap: wrap ? 'wrap' : 'nowrap',
      ...style
    }
  }, rest), divider ? items.flatMap((c, i) => i ? [React.cloneElement(divider, {
    key: 'd' + i
  }), c] : [c]) : children);
}
Object.assign(__ds_scope, { Stack });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Stack.jsx", error: String((e && e.message) || e) }); }

// components/core/Typography.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** [McTypography] <Typography> — the 13-variant type scale of the Inspira theme. */
const VARIANTS = {
  h1: {
    f: "display",
    s: 96,
    lh: 1.167,
    w: 400
  },
  h2: {
    f: "display",
    s: 60,
    lh: 1.2,
    w: 400
  },
  h3: {
    f: "display",
    s: 48,
    lh: 1.167,
    w: 400
  },
  h4: {
    f: "display",
    s: 34,
    lh: 1.235,
    ls: "0.25px",
    w: 400
  },
  h5: {
    f: "ui",
    s: 24,
    lh: 1.334,
    w: 700
  },
  h6: {
    f: "ui",
    s: 20,
    lh: 1.6,
    ls: "0.15px",
    w: 500
  },
  subtitle1: {
    f: "ui",
    s: 16,
    lh: 1.75,
    ls: "0.15px",
    w: 400
  },
  subtitle2: {
    f: "ui",
    s: 14,
    lh: 1.57,
    ls: "0.1px",
    w: 500
  },
  body1: {
    f: "ui",
    s: 16,
    lh: 1.5,
    ls: "0.15px",
    w: 400
  },
  body2: {
    f: "ui",
    s: 14,
    lh: 1.43,
    ls: "0.17px",
    w: 400
  },
  caption: {
    f: "ui",
    s: 12,
    lh: 1.66,
    ls: "0.4px",
    w: 400
  },
  overline: {
    f: "ui",
    s: 12,
    lh: 2.66,
    ls: "1px",
    w: 400,
    uc: true
  },
  custom: {
    f: "ui",
    s: 14,
    lh: "24px",
    ls: "0.17px",
    w: 500
  }
};
const TAGS = {
  h1: 'h1',
  h2: 'h2',
  h3: 'h3',
  h4: 'h4',
  h5: 'h5',
  h6: 'h6',
  subtitle1: 'h6',
  subtitle2: 'h6',
  body1: 'p',
  body2: 'p',
  caption: 'span',
  overline: 'span',
  custom: 'p'
};
function Typography({
  variant = 'body1',
  gutterBottom = false,
  color,
  align,
  noWrap = false,
  as,
  children,
  style,
  ...rest
}) {
  const v = VARIANTS[variant] || VARIANTS.body1;
  const Tag = as || TAGS[variant] || 'span';
  return /*#__PURE__*/React.createElement(Tag, _extends({
    style: {
      margin: 0,
      fontFamily: v.f === 'display' ? 'var(--font-display)' : 'var(--font-ui)',
      fontWeight: v.w,
      fontSize: v.s,
      lineHeight: v.lh,
      letterSpacing: v.ls,
      textTransform: v.uc ? 'uppercase' : undefined,
      color: color || 'var(--text-primary)',
      textAlign: align,
      whiteSpace: noWrap ? 'nowrap' : undefined,
      overflow: noWrap ? 'hidden' : undefined,
      textOverflow: noWrap ? 'ellipsis' : undefined,
      marginBottom: gutterBottom ? '0.35em' : undefined,
      textWrap: 'pretty',
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Typography });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Typography.jsx", error: String((e && e.message) || e) }); }

// components/data-display/Avatar.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const SIZES = {
  '18px': 18,
  '24px': 24,
  '40px': 40,
  '56px': 56,
  small: 24,
  medium: 40,
  large: 56
};
const RADII = {
  circular: 'var(--radius-pill)',
  rounded: 'var(--radius-sm)',
  square: '0px'
};

/** [McAvatar] <Avatar> — 4 sizes × 3 variants × 3 content types. Indigo fill, white glyph. */
function Avatar({
  size = '40px',
  variant = 'circular',
  initials,
  src,
  alt,
  icon,
  color = 'var(--primary-main)',
  style,
  ...rest
}) {
  const px = SIZES[size] || 40;
  const fontSize = px <= 18 ? 10 : px <= 24 ? 12 : px <= 40 ? 16 : 20;
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      width: px,
      height: px,
      flexShrink: 0,
      borderRadius: RADII[variant] || RADII.circular,
      background: src ? `center/cover no-repeat url(${src})` : color,
      color: '#FFFFFF',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      overflow: 'hidden',
      fontFamily: 'var(--font-ui)',
      fontWeight: 400,
      fontSize,
      lineHeight: 1,
      ...style
    },
    "aria-label": alt
  }, rest), src ? null : icon ? icon : initials);
}
Object.assign(__ds_scope, { Avatar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data-display/Avatar.jsx", error: String((e && e.message) || e) }); }

// components/data-display/AvatarGroup.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const OVERLAP = {
  tight: -12,
  normal: -8,
  loose: -4
};

/** [McAvatarGroup] <AvatarGroup> — 3 spacings × 4 max counts × 3 sizes. */
function AvatarGroup({
  spacing = 'normal',
  max = 4,
  size = '40px',
  children,
  style,
  ...rest
}) {
  const items = React.Children.toArray(children);
  const shown = items.slice(0, max);
  const extra = items.length - shown.length;
  const gap = OVERLAP[spacing] ?? -8;
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      ...style
    }
  }, rest), shown.map((c, i) => /*#__PURE__*/React.createElement("span", {
    key: i,
    style: {
      marginLeft: i ? gap : 0,
      borderRadius: 'var(--radius-pill)',
      boxShadow: '0 0 0 2px var(--surface-card)',
      display: 'flex'
    }
  }, React.cloneElement(c, {
    size
  }))), extra > 0 ? /*#__PURE__*/React.createElement("span", {
    style: {
      marginLeft: gap,
      borderRadius: 'var(--radius-pill)',
      boxShadow: '0 0 0 2px var(--surface-card)',
      display: 'flex'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Avatar, {
    size: size,
    initials: '+' + extra,
    color: "var(--indigo-700)"
  })) : null);
}
Object.assign(__ds_scope, { AvatarGroup });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data-display/AvatarGroup.jsx", error: String((e && e.message) || e) }); }

// components/data-display/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const TINT = {
  primary: {
    bg: 'var(--primary-main)',
    fg: '#FFFFFF'
  },
  secondary: {
    bg: 'var(--secondary-main)',
    fg: 'rgba(0,0,0,0.87)'
  },
  error: {
    bg: 'var(--error-main)',
    fg: '#FFFFFF'
  },
  warning: {
    bg: 'var(--warning-main)',
    fg: '#FFFFFF'
  },
  info: {
    bg: 'var(--info-main)',
    fg: '#FFFFFF'
  },
  success: {
    bg: 'var(--success-main)',
    fg: '#FFFFFF'
  },
  default: {
    bg: 'var(--action-active)',
    fg: '#FFFFFF'
  }
};

/** [McBadge] <Badge> — standard / dot / outlined, 7 colours. */
function Badge({
  variant = 'standard',
  color = 'primary',
  content,
  max = 99,
  invisible = false,
  children,
  style,
  ...rest
}) {
  const t = TINT[color] || TINT.primary;
  const label = typeof content === 'number' && content > max ? max + '+' : content;
  const dot = variant === 'dot';
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      position: 'relative',
      display: 'inline-flex',
      ...style
    }
  }, rest), children, invisible ? null : /*#__PURE__*/React.createElement("span", {
    style: {
      position: children ? 'absolute' : 'static',
      top: children ? 0 : undefined,
      right: children ? 0 : undefined,
      transform: children ? 'translate(50%,-50%)' : 'none',
      minWidth: dot ? 8 : 20,
      height: dot ? 8 : 20,
      padding: dot ? 0 : '0 6px',
      boxSizing: 'border-box',
      borderRadius: 'var(--radius-pill)',
      background: variant === 'outlined' ? 'transparent' : t.bg,
      boxShadow: variant === 'outlined' ? `inset 0 0 0 1px ${t.bg}` : 'none',
      color: variant === 'outlined' ? t.bg : t.fg,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontFamily: 'var(--font-ui)',
      fontWeight: 500,
      fontSize: 12,
      lineHeight: '20px',
      letterSpacing: '0.14px'
    }
  }, dot ? null : label));
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data-display/Badge.jsx", error: String((e && e.message) || e) }); }

// components/data-display/Chip.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const TINT = {
  default: {
    main: 'rgba(0,0,0,0.08)',
    fg: 'var(--text-primary)',
    border: 'rgba(0,0,0,0.23)',
    solidFg: 'var(--text-primary)'
  },
  primary: {
    main: 'var(--primary-main)',
    fg: '#FFFFFF',
    border: 'var(--primary-main)',
    solidFg: '#FFFFFF'
  },
  secondary: {
    main: 'var(--secondary-main)',
    fg: 'rgba(0,0,0,0.87)',
    border: 'var(--secondary-main)',
    solidFg: 'rgba(0,0,0,0.87)'
  },
  error: {
    main: 'var(--error-main)',
    fg: '#FFFFFF',
    border: 'var(--error-main)',
    solidFg: '#FFFFFF'
  },
  warning: {
    main: 'var(--warning-main)',
    fg: '#FFFFFF',
    border: 'var(--warning-main)',
    solidFg: '#FFFFFF'
  },
  info: {
    main: 'var(--info-main)',
    fg: '#FFFFFF',
    border: 'var(--info-main)',
    solidFg: '#FFFFFF'
  },
  success: {
    main: 'var(--success-main)',
    fg: '#FFFFFF',
    border: 'var(--success-main)',
    solidFg: '#FFFFFF'
  }
};

/** [McChip] <Chip> — 2 sizes × 7 colours × 5 states × 3 variants. Pill radius 100px. */
function Chip({
  label,
  size = 'medium',
  color = 'default',
  variant = 'filled',
  avatar,
  icon,
  onDelete,
  disabled = false,
  onClick,
  style,
  ...rest
}) {
  const t = TINT[color] || TINT.default;
  const small = size === 'small';
  const h = small ? 24 : 32;
  const filled = variant === 'filled';
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", _extends({
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    onClick: disabled ? undefined : onClick,
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      boxSizing: 'border-box',
      height: h,
      padding: small ? '3px 3px' : '4px',
      borderRadius: 'var(--radius-pill)',
      overflow: 'hidden',
      background: disabled ? 'rgba(0,0,0,0.04)' : filled ? t.main : hover && onClick ? 'rgba(0,0,0,0.04)' : 'transparent',
      boxShadow: filled ? 'none' : `inset 0 0 0 1px ${disabled ? 'rgba(0,0,0,0.12)' : t.border}`,
      color: disabled ? 'var(--text-disabled)' : filled ? t.fg : color === 'default' ? 'var(--text-primary)' : t.main,
      cursor: onClick && !disabled ? 'pointer' : 'default',
      opacity: disabled ? 0.7 : 1,
      ...style
    }
  }, rest), avatar ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      marginRight: -2
    }
  }, avatar) : null, icon ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      paddingLeft: 4
    }
  }, icon) : null, /*#__PURE__*/React.createElement("span", {
    style: {
      padding: small ? '0 5px' : '0 6px',
      fontFamily: 'var(--font-ui)',
      fontWeight: 400,
      fontSize: small ? 12 : 13,
      lineHeight: small ? '16px' : '18px',
      letterSpacing: '0.16px',
      whiteSpace: 'nowrap'
    }
  }, label), onDelete ? /*#__PURE__*/React.createElement("button", {
    type: "button",
    "aria-label": "Remove",
    onClick: e => {
      e.stopPropagation();
      onDelete();
    },
    style: {
      display: 'flex',
      border: 'none',
      background: 'transparent',
      padding: 0,
      cursor: 'pointer',
      width: small ? 18 : 24,
      height: small ? 18 : 24,
      opacity: 0.26,
      color: 'currentColor'
    }
  }, /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 24 24",
    width: "100%",
    height: "100%",
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement("path", {
    fill: "currentColor",
    d: "M12 2C6.47 2 2 6.47 2 12s4.47 10 10 10 10-4.47 10-10S17.53 2 12 2zm5 13.59L15.59 17 12 13.41 8.41 17 7 15.59 10.59 12 7 8.41 8.41 7 12 10.59 15.59 7 17 8.41 13.41 12 17 15.59z"
  }))) : null);
}
Object.assign(__ds_scope, { Chip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data-display/Chip.jsx", error: String((e && e.message) || e) }); }

// components/data-display/Link.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** <Link> — 2 colours × 3 underline modes × 3 states. */
function Link({
  color = 'primary',
  underline = 'always',
  state,
  children,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const s = state || (hover ? 'hover' : 'enabled');
  const tint = color === 'inherit' ? 'inherit' : s === 'visited' ? 'var(--link-visited)' : 'var(--link-enabled)';
  const showUnderline = underline === 'always' || underline === 'hover' && s === 'hover';
  return /*#__PURE__*/React.createElement("a", _extends({
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      color: tint,
      textDecoration: showUnderline ? 'underline' : 'none',
      textUnderlineOffset: 2,
      fontFamily: 'inherit',
      fontSize: 'inherit',
      lineHeight: 'inherit',
      cursor: 'pointer',
      outline: s === 'focus' ? '3px solid var(--primary-state-focus)' : 'none',
      borderRadius: 2,
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Link });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data-display/Link.jsx", error: String((e && e.message) || e) }); }

// components/data-display/List.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** [McList] <List> — 4 variants (disable padding × dense). */
function List({
  dense = false,
  disablePadding = false,
  subheader,
  children,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("ul", _extends({
    style: {
      listStyle: 'none',
      margin: 0,
      padding: disablePadding ? 0 : '8px 0',
      background: 'var(--surface-card)',
      ...style
    }
  }, rest), subheader, React.Children.map(children, c => React.isValidElement(c) ? React.cloneElement(c, {
    dense: c.props.dense ?? dense
  }) : c));
}
Object.assign(__ds_scope, { List });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data-display/List.jsx", error: String((e && e.message) || e) }); }

// components/data-display/ListItem.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** [McListItem] <ListItem> — 2 densities × disable-gutters × 6 states. 48px tall, 8px 16px padding. */
function ListItem({
  primary,
  secondary,
  icon,
  secondaryAction,
  dense = false,
  disableGutters = false,
  selected = false,
  disabled = false,
  state,
  onClick,
  children,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const s = disabled ? 'disabled' : state || (selected ? 'selected' : hover ? 'hovered' : 'enabled');
  const bg = s === 'selected' ? 'var(--primary-state-selected)' : s === 'hovered' ? 'var(--action-hover)' : 'transparent';
  return /*#__PURE__*/React.createElement("li", _extends({
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    onClick: disabled ? undefined : onClick,
    style: {
      display: 'flex',
      alignItems: 'center',
      boxSizing: 'border-box',
      minHeight: dense ? 40 : 48,
      padding: disableGutters ? dense ? '4px 0' : '8px 0' : dense ? '4px 16px' : '8px 16px',
      background: bg,
      cursor: onClick && !disabled ? 'pointer' : 'default',
      opacity: disabled ? 0.5 : 1,
      transition: 'background-color var(--transition-fast)',
      ...style
    }
  }, rest), icon ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      minWidth: 36,
      color: 'var(--action-active)'
    }
  }, icon) : null, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      padding: '4px 0',
      flex: 1,
      minWidth: 0
    }
  }, primary ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-ui)',
      fontWeight: 400,
      fontSize: dense ? 14 : 16,
      lineHeight: dense ? 1.43 : 1.5,
      letterSpacing: dense ? '0.17px' : '0.15px',
      color: 'var(--text-primary)'
    }
  }, primary) : null, secondary ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-ui)',
      fontWeight: 400,
      fontSize: 14,
      lineHeight: 1.43,
      letterSpacing: '0.17px',
      color: 'var(--text-secondary)'
    }
  }, secondary) : null, children), secondaryAction ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      alignItems: 'center',
      marginLeft: 16
    }
  }, secondaryAction) : null);
}
Object.assign(__ds_scope, { ListItem });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data-display/ListItem.jsx", error: String((e && e.message) || e) }); }

// components/data-display/ListItemSubItem.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const STATUS = {
  neutral: 'var(--action-active)',
  success: 'var(--teal-400)',
  warning: 'var(--warning-main)',
  error: 'var(--error-main)'
};

/** [MCListItemSubItem] — indented sub-row with a status colour. */
function ListItemSubItem({
  statusColor = 'neutral',
  primary,
  secondary,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("li", _extends({
    style: {
      listStyle: 'none',
      display: 'flex',
      alignItems: 'center',
      gap: 12,
      minHeight: 40,
      padding: '4px 16px 4px 52px',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      width: 8,
      height: 8,
      borderRadius: 'var(--radius-pill)',
      background: STATUS[statusColor] || STATUS.neutral,
      flexShrink: 0
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-ui)',
      fontSize: 14,
      lineHeight: 1.43,
      letterSpacing: '0.17px',
      color: 'var(--text-primary)'
    }
  }, primary), secondary ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-ui)',
      fontSize: 12,
      lineHeight: 1.66,
      letterSpacing: '0.4px',
      color: 'var(--text-secondary)'
    }
  }, secondary) : null));
}
Object.assign(__ds_scope, { ListItemSubItem });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data-display/ListItemSubItem.jsx", error: String((e && e.message) || e) }); }

// components/data-display/ListSubheader.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** <ListSubheader> — sticky group label inside a List. */
function ListSubheader({
  disableSticky = false,
  children,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("li", _extends({
    style: {
      listStyle: 'none',
      display: 'flex',
      alignItems: 'center',
      minHeight: 48,
      padding: '0 16px',
      background: 'var(--surface-card)',
      position: disableSticky ? 'static' : 'sticky',
      top: 0,
      zIndex: 1,
      fontFamily: 'var(--font-ui)',
      fontWeight: 500,
      fontSize: 14,
      lineHeight: '48px',
      letterSpacing: '0.1px',
      color: 'var(--text-secondary)',
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { ListSubheader });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data-display/ListSubheader.jsx", error: String((e && e.message) || e) }); }

// components/data-grid/DataGridCell.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** [McDataGrid | Cell] <DataGrid> | Cell — 4 states × 8 types × edit mode. */
function DataGridCell({
  type = 'string',
  value,
  state = 'default',
  editMode = false,
  density = 'standard',
  align,
  width,
  style,
  ...rest
}) {
  const h = density === 'compact' ? 36 : density === 'comfortable' ? 60 : 52;
  const numeric = type === 'number' || type === 'currency';
  const bg = state === 'selected' ? 'var(--primary-state-selected)' : state === 'hover' ? 'var(--action-hover)' : 'transparent';
  return /*#__PURE__*/React.createElement("div", _extends({
    role: "gridcell",
    style: {
      boxSizing: 'border-box',
      height: h,
      width,
      flexShrink: width ? 0 : 1,
      flexGrow: width ? 0 : 1,
      display: 'flex',
      alignItems: 'center',
      padding: '0 10px',
      background: bg,
      justifyContent: (align || (numeric ? 'right' : 'left')) === 'right' ? 'flex-end' : align === 'center' ? 'center' : 'flex-start',
      boxShadow: state === 'focus' ? 'inset 0 0 0 1px var(--primary-main)' : undefined,
      fontFamily: 'var(--font-ui)',
      fontWeight: 400,
      fontSize: 14,
      lineHeight: '20px',
      letterSpacing: '0.17px',
      color: 'var(--text-primary)',
      overflow: 'hidden',
      whiteSpace: 'nowrap',
      textOverflow: 'ellipsis',
      fontVariantNumeric: numeric ? 'tabular-nums' : undefined,
      ...style
    }
  }, rest), editMode ? /*#__PURE__*/React.createElement("input", {
    defaultValue: typeof value === 'string' ? value : '',
    style: {
      width: '100%',
      border: 'none',
      outline: '2px solid var(--primary-main)',
      outlineOffset: -2,
      borderRadius: 4,
      padding: '4px 6px',
      font: 'inherit',
      letterSpacing: 'inherit',
      background: 'var(--surface-card)'
    }
  }) : value);
}
Object.assign(__ds_scope, { DataGridCell });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data-grid/DataGridCell.jsx", error: String((e && e.message) || e) }); }

// components/data-grid/DataGridColumnGroupHeader.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** [McDataGrid | Header | Column Group] — checkbox? × grouped? × empty? × last-of-type. */
function DataGridColumnGroupHeader({
  label,
  span = 2,
  empty = false,
  lastOfType = false,
  width,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    role: "columnheader",
    style: {
      boxSizing: 'border-box',
      height: 40,
      width,
      flex: width ? '0 0 auto' : span,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '0 10px',
      borderBottom: '1px solid var(--border-divider)',
      borderRight: lastOfType ? 'none' : '1px solid var(--border-divider)',
      fontFamily: 'var(--font-ui)',
      fontWeight: 500,
      fontSize: 12,
      lineHeight: '20px',
      letterSpacing: '0.4px',
      textTransform: 'uppercase',
      color: 'var(--text-secondary)',
      ...style
    }
  }, rest), empty ? null : label);
}
Object.assign(__ds_scope, { DataGridColumnGroupHeader });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data-grid/DataGridColumnGroupHeader.jsx", error: String((e && e.message) || e) }); }

// components/data-grid/DataGridColumnGroupRow.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** [McDataGrid | Header Rows | Column Group] — the grouped-column band above the header row. 3–10 columns. */
function DataGridColumnGroupRow({
  groups = [],
  checkbox = false,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    role: "row",
    style: {
      display: 'flex',
      alignItems: 'stretch',
      background: 'var(--surface-card)',
      ...style
    }
  }, rest), checkbox ? /*#__PURE__*/React.createElement(__ds_scope.DataGridColumnGroupHeader, {
    empty: true,
    width: 50
  }) : null, groups.map((g, i) => {
    const grp = typeof g === 'string' ? {
      label: g
    } : g;
    return /*#__PURE__*/React.createElement(__ds_scope.DataGridColumnGroupHeader, _extends({
      key: i
    }, grp, {
      lastOfType: i === groups.length - 1
    }));
  }));
}
Object.assign(__ds_scope, { DataGridColumnGroupRow });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data-grid/DataGridColumnGroupRow.jsx", error: String((e && e.message) || e) }); }

// components/data-grid/DataGridGroupingCell.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** [McDataGrid | Grouping Cell] <DataGrid> | Grouping Cell — group? × expanded. */
function DataGridGroupingCell({
  label,
  isGroup = true,
  expanded = false,
  count,
  depth = 0,
  onToggle,
  width,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    role: "gridcell",
    style: {
      boxSizing: 'border-box',
      height: 52,
      width,
      display: 'flex',
      alignItems: 'center',
      gap: 4,
      padding: `0 10px 0 ${10 + depth * 20}px`,
      fontFamily: 'var(--font-ui)',
      fontWeight: isGroup ? 500 : 400,
      fontSize: 14,
      lineHeight: '20px',
      letterSpacing: '0.17px',
      color: 'var(--text-primary)',
      ...style
    }
  }, rest), isGroup ? /*#__PURE__*/React.createElement("button", {
    type: "button",
    "aria-label": expanded ? 'Collapse group' : 'Expand group',
    onClick: onToggle,
    style: {
      display: 'flex',
      border: 'none',
      background: 'transparent',
      padding: 0,
      cursor: 'pointer',
      color: 'var(--action-active)'
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: "20",
    height: "20",
    viewBox: "0 0 24 24",
    "aria-hidden": "true",
    style: {
      transform: expanded ? 'rotate(90deg)' : 'none',
      transition: 'transform var(--transition-fast)'
    }
  }, /*#__PURE__*/React.createElement("path", {
    fill: "currentColor",
    d: "M10 17l5-5-5-5v10z"
  }))) : /*#__PURE__*/React.createElement("span", {
    style: {
      width: 20
    }
  }), /*#__PURE__*/React.createElement("span", null, label), count != null ? /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-secondary)'
    }
  }, "(", count, ")") : null);
}
Object.assign(__ds_scope, { DataGridGroupingCell });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data-grid/DataGridGroupingCell.jsx", error: String((e && e.message) || e) }); }

// components/data-grid/DetailPanelContent.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** _Custom / My Detail Panel Content — the expandable row detail panel. */
function DetailPanelContent({
  title,
  items = [],
  children,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      background: 'var(--surface-page)',
      padding: '16px 24px',
      borderBottom: '1px solid var(--border-divider)',
      display: 'flex',
      flexDirection: 'column',
      gap: 12,
      ...style
    }
  }, rest), title ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-ui)',
      fontWeight: 500,
      fontSize: 14,
      lineHeight: '24px',
      letterSpacing: '0.17px',
      color: 'var(--text-primary)'
    }
  }, title) : null, items.length ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fit,minmax(160px,1fr))',
      gap: '12px 24px'
    }
  }, items.map((it, i) => /*#__PURE__*/React.createElement("span", {
    key: i,
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 2
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-ui)',
      fontSize: 12,
      lineHeight: 1.66,
      letterSpacing: '0.4px',
      color: 'var(--text-secondary)'
    }
  }, it.label), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-ui)',
      fontSize: 14,
      lineHeight: 1.43,
      letterSpacing: '0.17px',
      color: 'var(--text-primary)'
    }
  }, it.value)))) : null, children);
}
Object.assign(__ds_scope, { DetailPanelContent });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data-grid/DetailPanelContent.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Alert.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const SEV = {
  error: {
    main: 'var(--error-main)',
    bg: 'var(--subtle-error-bg)',
    fg: 'var(--subtle-error-fg)',
    glyph: 'M12 2 1 21h22L12 2zm1 16h-2v-2h2v2zm0-4h-2V9h2v5z'
  },
  warning: {
    main: 'var(--warning-main)',
    bg: 'var(--subtle-warning-bg)',
    fg: 'var(--subtle-warning-fg)',
    glyph: 'M12 2 1 21h22L12 2zm1 16h-2v-2h2v2zm0-4h-2V9h2v5z'
  },
  info: {
    main: 'var(--info-main)',
    bg: 'var(--subtle-info-bg)',
    fg: 'var(--subtle-info-fg)',
    glyph: 'M12 2a10 10 0 100 20 10 10 0 000-20zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z'
  },
  success: {
    main: 'var(--success-main)',
    bg: 'var(--subtle-success-bg)',
    fg: 'var(--subtle-success-fg)',
    glyph: 'M12 2a10 10 0 100 20 10 10 0 000-20zm-2 15-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z'
  }
};

/** [McAlert] <Alert> — 4 severities × 3 variants. Radius 12, padding 6px 16px. */
function Alert({
  severity = 'error',
  variant = 'standard',
  title,
  action,
  onClose,
  children,
  style,
  ...rest
}) {
  const s = SEV[severity] || SEV.error;
  const filled = variant === 'filled';
  const outlined = variant === 'outlined';
  const fg = filled ? '#FFFFFF' : s.fg;
  return /*#__PURE__*/React.createElement("div", _extends({
    role: "alert",
    style: {
      display: 'flex',
      alignItems: 'flex-start',
      boxSizing: 'border-box',
      borderRadius: 'var(--radius-md)',
      padding: '6px 16px',
      overflow: 'hidden',
      background: filled ? s.main : outlined ? 'transparent' : s.bg,
      boxShadow: outlined ? `inset 0 0 0 1px ${s.main}` : 'none',
      color: fg,
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      padding: '7px 12px 7px 0',
      flexShrink: 0,
      color: filled ? '#FFFFFF' : s.main
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: "22",
    height: "22",
    viewBox: "0 0 24 24",
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement("path", {
    fill: "currentColor",
    d: s.glyph
  }))), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 4,
      padding: '8px 0',
      flex: 1,
      minWidth: 0
    }
  }, title ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-ui)',
      fontWeight: 500,
      fontSize: 16,
      lineHeight: '24px',
      letterSpacing: '0.15px',
      color: fg
    }
  }, title) : null, children ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-ui)',
      fontWeight: 400,
      fontSize: 14,
      lineHeight: '20px',
      letterSpacing: '0.17px',
      color: fg
    }
  }, children) : null), action ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      padding: '4px 0 4px 16px',
      flexShrink: 0
    }
  }, action) : null, onClose ? /*#__PURE__*/React.createElement("button", {
    type: "button",
    "aria-label": "Dismiss",
    onClick: onClose,
    style: {
      display: 'flex',
      border: 'none',
      background: 'transparent',
      padding: '8px 0 8px 8px',
      cursor: 'pointer',
      color: fg,
      opacity: 0.7
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: "20",
    height: "20",
    viewBox: "0 0 24 24",
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement("path", {
    fill: "currentColor",
    d: "M19 6.41 17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12 19 6.41z"
  }))) : null);
}
Object.assign(__ds_scope, { Alert });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Alert.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Progress.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const TINT = {
  primary: 'var(--primary-main)',
  secondary: 'var(--secondary-main)',
  inherit: 'currentColor'
};

/** [McProgress] <Progress> | Circular — 3 colours × 2 sizes. Indeterminate spinner. */
function Progress({
  size = 40,
  thickness = 3.6,
  color = 'primary',
  value,
  style,
  ...rest
}) {
  const px = typeof size === 'number' ? size : size === 'small' ? 20 : 40;
  const r = (44 - thickness) / 2;
  const circumference = 2 * Math.PI * r;
  const determinate = value != null;
  return /*#__PURE__*/React.createElement("span", _extends({
    role: "progressbar",
    "aria-valuenow": determinate ? value : undefined,
    style: {
      display: 'inline-flex',
      width: px,
      height: px,
      color: TINT[color] || TINT.primary,
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("svg", {
    viewBox: "22 22 44 44",
    width: px,
    height: px,
    style: {
      animation: determinate ? 'none' : 'mc-spin 1.4s linear infinite'
    }
  }, /*#__PURE__*/React.createElement("circle", {
    cx: "44",
    cy: "44",
    r: r,
    fill: "none",
    stroke: "currentColor",
    strokeWidth: thickness,
    strokeDasharray: determinate ? circumference : circumference * 0.75,
    strokeDashoffset: determinate ? circumference * (1 - value / 100) : circumference * 0.2,
    strokeLinecap: "round",
    transform: "rotate(-90 44 44)"
  })), /*#__PURE__*/React.createElement("style", null, '@keyframes mc-spin{to{transform:rotate(360deg)}}'));
}
Object.assign(__ds_scope, { Progress });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Progress.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Loading.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Loading — the full-surface Inspira loading state. 3 modes × 3 text placements. */
function Loading({
  mode = 'light mode',
  textPlacement = 'bottom',
  primary = 'Sit tight! We\u2019re verifying your identity.',
  secondary = 'This may take a few minutes to complete.',
  style,
  ...rest
}) {
  const dark = mode === 'dark mode';
  const bg = dark ? 'var(--primary-main)' : mode === 'transparent' ? 'rgba(247,246,245,0.9)' : 'var(--surface-page)';
  const fg = dark ? '#FFFFFF' : 'var(--text-primary)';
  const row = textPlacement === 'right';
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: 'flex',
      flexDirection: row ? 'row' : 'column',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 24,
      padding: 48,
      background: bg,
      color: fg,
      minHeight: 240,
      backdropFilter: mode === 'transparent' ? 'blur(2px)' : undefined,
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement(__ds_scope.Progress, {
    size: 48,
    color: dark ? 'secondary' : 'primary'
  }), textPlacement !== 'no' ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 4,
      textAlign: row ? 'left' : 'center',
      maxWidth: 360
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-ui)',
      fontWeight: 500,
      fontSize: 16,
      lineHeight: '24px',
      letterSpacing: '0.15px'
    }
  }, primary), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-ui)',
      fontWeight: 400,
      fontSize: 14,
      lineHeight: '20px',
      letterSpacing: '0.17px',
      opacity: 0.8
    }
  }, secondary)) : null);
}
Object.assign(__ds_scope, { Loading });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Loading.jsx", error: String((e && e.message) || e) }); }

// components/feedback/TooltipBubble.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Tooltip Bubble — white card, 1px grey ring, radius 12, 12px 16px padding. 3 dismiss variants. */
function TooltipBubble({
  children,
  variant = 'default',
  placement = 'bottom',
  onClose,
  style,
  ...rest
}) {
  const arrow = {
    position: 'absolute',
    width: 12,
    height: 12,
    background: 'var(--surface-card)',
    boxShadow: 'inset 0 0 0 1px var(--grey-grey-500, #716A5B)',
    transform: 'rotate(45deg)',
    ...(placement === 'bottom' ? {
      top: -6,
      left: 24
    } : {
      bottom: -6,
      left: 24
    })
  };
  return /*#__PURE__*/React.createElement("div", _extends({
    role: "tooltip",
    style: {
      position: 'relative',
      maxWidth: 320,
      background: 'var(--surface-card)',
      color: 'var(--text-primary)',
      borderRadius: 'var(--radius-md)',
      padding: '12px 16px',
      boxShadow: 'inset 0 0 0 1px var(--grey-500), var(--shadow-2)',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'flex-end',
      gap: 8,
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-ui)',
      fontWeight: 400,
      fontSize: 14,
      lineHeight: '20px',
      color: 'var(--primary-main)',
      alignSelf: 'stretch'
    }
  }, children), variant !== 'default' ? /*#__PURE__*/React.createElement("button", {
    type: "button",
    "aria-label": "Close",
    onClick: onClose,
    style: {
      display: 'flex',
      alignItems: 'center',
      border: 'none',
      background: 'transparent',
      padding: 0,
      cursor: 'pointer',
      color: 'var(--primary-main)'
    }
  }, variant === 'close' ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-ui)',
      fontWeight: 600,
      fontSize: 14,
      lineHeight: '20px'
    }
  }, "Close") : /*#__PURE__*/React.createElement("svg", {
    width: "16",
    height: "16",
    viewBox: "0 0 24 24",
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement("path", {
    fill: "currentColor",
    d: "M19 6.41 17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12 19 6.41z"
  }))) : null, /*#__PURE__*/React.createElement("span", {
    style: arrow,
    "aria-hidden": "true"
  }));
}
Object.assign(__ds_scope, { TooltipBubble });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/TooltipBubble.jsx", error: String((e && e.message) || e) }); }

// components/inputs/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const COLORS = {
  primary: {
    main: 'var(--primary-main)',
    dark: 'var(--primary-dark)',
    contrast: '#FFFFFF',
    hover: 'rgba(69,83,169,0.04)',
    outline: 'rgba(69,83,169,0.5)'
  },
  secondary: {
    main: 'var(--secondary-main)',
    dark: 'var(--secondary-dark)',
    contrast: 'rgba(0,0,0,0.87)',
    hover: 'rgba(255,208,8,0.04)',
    outline: 'rgba(255,208,8,0.5)'
  },
  error: {
    main: 'var(--error-main)',
    dark: 'var(--error-dark)',
    contrast: '#FFFFFF',
    hover: 'rgba(211,47,47,0.04)',
    outline: 'rgba(211,47,47,0.5)'
  },
  warning: {
    main: 'var(--warning-main)',
    dark: 'var(--warning-dark)',
    contrast: '#FFFFFF',
    hover: 'rgba(239,108,0,0.04)',
    outline: 'rgba(239,108,0,0.5)'
  },
  info: {
    main: 'var(--info-main)',
    dark: 'var(--info-dark)',
    contrast: '#FFFFFF',
    hover: 'rgba(2,136,209,0.04)',
    outline: 'rgba(2,136,209,0.5)'
  },
  success: {
    main: 'var(--success-main)',
    dark: 'var(--success-dark)',
    contrast: '#FFFFFF',
    hover: 'rgba(46,125,50,0.04)',
    outline: 'rgba(46,125,50,0.5)'
  },
  inherit: {
    main: 'currentColor',
    dark: 'currentColor',
    contrast: 'var(--text-primary)',
    hover: 'rgba(0,0,0,0.04)',
    outline: 'rgba(0,0,0,0.23)'
  },
  default: {
    main: 'var(--action-active)',
    dark: 'rgba(0,0,0,0.76)',
    contrast: '#FFFFFF',
    hover: 'rgba(0,0,0,0.04)',
    outline: 'rgba(0,0,0,0.23)'
  }
};
const SIZES = {
  small: {
    height: 30,
    padContained: '4px 10px',
    padText: '4px 5px',
    font: 13,
    lh: '22px',
    ls: '0.46px',
    icon: 20
  },
  medium: {
    height: 36,
    padContained: '6px 16px',
    padText: '6px 8px',
    font: 14,
    lh: '24px',
    ls: '0.4px',
    icon: 20
  },
  large: {
    height: 42,
    padContained: '8px 22px',
    padText: '8px 11px',
    font: 15,
    lh: '26px',
    ls: '0.46px',
    icon: 20
  }
};

/** [McButton] <Button> — 3 sizes × 3 variants × 8 colours × 5 states. Radius 12px, flat (no elevation). */
function Button({
  variant = 'contained',
  color = 'primary',
  size = 'medium',
  startIcon,
  endIcon,
  fullWidth = false,
  disabled = false,
  state,
  children,
  style,
  ...rest
}) {
  const c = COLORS[color] || COLORS.primary;
  const s = SIZES[size] || SIZES.medium;
  const [hover, setHover] = React.useState(false);
  const [active, setActive] = React.useState(false);
  const isHover = state === 'hovered' || state == null && hover && !disabled;
  const isActive = state === 'pressed' || state == null && active && !disabled;
  const isFocus = state === 'focused';
  const base = {
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    boxSizing: 'border-box',
    width: fullWidth ? '100%' : undefined,
    minHeight: s.height,
    borderRadius: 'var(--radius-md)',
    border: 'none',
    background: 'transparent',
    fontFamily: 'var(--font-ui)',
    fontWeight: 500,
    fontSize: s.font,
    lineHeight: s.lh,
    letterSpacing: s.ls,
    textTransform: 'none',
    cursor: disabled ? 'default' : 'pointer',
    textDecoration: 'none',
    padding: variant === 'contained' ? s.padContained : variant === 'outlined' ? s.padContained : s.padText,
    transition: 'background-color var(--transition-fast), box-shadow var(--transition-fast)',
    outline: isFocus ? `3px solid ${c.outline}` : 'none',
    outlineOffset: isFocus ? 1 : 0
  };
  let skin;
  if (variant === 'contained') {
    skin = disabled ? {
      background: 'var(--action-disabled-bg)',
      color: 'var(--text-disabled)'
    } : {
      background: isHover || isActive ? c.dark : c.main,
      color: c.contrast
    };
  } else if (variant === 'outlined') {
    skin = disabled ? {
      boxShadow: 'inset 0 0 0 2px rgba(0,0,0,0.12)',
      color: 'var(--text-disabled)'
    } : {
      boxShadow: `inset 0 0 0 2px ${isHover || isActive ? c.main : c.outline}`,
      color: c.main,
      background: isHover || isActive ? c.hover : 'transparent'
    };
  } else {
    skin = disabled ? {
      color: 'var(--text-disabled)'
    } : {
      color: c.main,
      background: isHover || isActive ? c.hover : 'transparent'
    };
  }
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    disabled: disabled,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => {
      setHover(false);
      setActive(false);
    },
    onMouseDown: () => setActive(true),
    onMouseUp: () => setActive(false),
    style: {
      ...base,
      ...skin,
      ...style
    }
  }, rest), startIcon ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      width: s.icon,
      height: s.icon,
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, startIcon) : null, children, endIcon ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      width: s.icon,
      height: s.icon,
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, endIcon) : null);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/inputs/Button.jsx", error: String((e && e.message) || e) }); }

// components/inputs/ButtonGroup.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** [McButtonGroup] <ButtonGroup> — 2 orientations × 3 variants × 7 colours. Radius 12 on the outer corners only. */
function ButtonGroup({
  orientation = 'horizontal',
  variant = 'contained',
  color = 'primary',
  size = 'medium',
  children,
  style,
  ...rest
}) {
  const items = React.Children.toArray(children);
  const row = orientation === 'horizontal';
  return /*#__PURE__*/React.createElement("div", _extends({
    role: "group",
    style: {
      display: 'inline-flex',
      flexDirection: row ? 'row' : 'column',
      ...style
    }
  }, rest), items.map((child, i) => {
    const first = i === 0,
      last = i === items.length - 1;
    const radius = row ? `${first ? 12 : 0}px ${last ? 12 : 0}px ${last ? 12 : 0}px ${first ? 12 : 0}px` : `${first ? 12 : 0}px ${first ? 12 : 0}px ${last ? 12 : 0}px ${last ? 12 : 0}px`;
    return React.cloneElement(child, {
      key: i,
      variant,
      color,
      size,
      style: {
        borderRadius: radius,
        marginLeft: row && !first ? -1 : 0,
        marginTop: !row && !first ? -1 : 0,
        ...(variant === 'contained' && !last ? {
          boxShadow: row ? 'inset -1px 0 0 0 rgba(255,255,255,0.35)' : 'inset 0 -1px 0 0 rgba(255,255,255,0.35)'
        } : null),
        ...(child.props.style || {})
      }
    });
  }));
}
Object.assign(__ds_scope, { ButtonGroup });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/inputs/ButtonGroup.jsx", error: String((e && e.message) || e) }); }

// components/inputs/Checkbox.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const TINT = {
  primary: 'var(--primary-main)',
  secondary: 'var(--secondary-main)',
  error: 'var(--error-main)',
  warning: 'var(--warning-main)',
  info: 'var(--info-main)',
  success: 'var(--success-main)',
  default: 'var(--action-active)'
};
const BOX = {
  small: 20,
  medium: 24,
  large: 28
};
const PAD = {
  small: 7,
  medium: 9,
  large: 11
};

/** [McCheckbox] <Checkbox> — 24px glyph in a 42px round hit area at medium. */
function Checkbox({
  checked,
  indeterminate = false,
  size = 'medium',
  color = 'primary',
  disabled = false,
  onChange,
  state,
  style,
  ...rest
}) {
  const [internal, setInternal] = React.useState(false);
  const on = checked !== undefined ? checked : internal;
  const [hover, setHover] = React.useState(false);
  const glyph = BOX[size] || 24,
    pad = PAD[size] || 9;
  const tint = disabled ? 'var(--action-disabled)' : on || indeterminate ? TINT[color] || TINT.primary : 'var(--action-active)';
  const isFocus = state === 'focused';
  return /*#__PURE__*/React.createElement("span", _extends({
    role: "checkbox",
    "aria-checked": indeterminate ? 'mixed' : on,
    "aria-disabled": disabled,
    tabIndex: disabled ? -1 : 0,
    onClick: () => {
      if (disabled) return;
      const next = !on;
      if (checked === undefined) setInternal(next);
      onChange && onChange(next);
    },
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: pad,
      borderRadius: 'var(--radius-pill)',
      flexShrink: 0,
      background: hover && !disabled || state === 'hovered' ? 'var(--action-hover)' : 'transparent',
      boxShadow: isFocus ? `0 0 0 3px ${TINT[color] || TINT.primary}4D` : 'none',
      cursor: disabled ? 'default' : 'pointer',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("svg", {
    width: glyph,
    height: glyph,
    viewBox: "0 0 24 24",
    style: {
      display: 'block',
      color: tint
    },
    "aria-hidden": "true"
  }, indeterminate ? /*#__PURE__*/React.createElement("path", {
    fill: "currentColor",
    d: "M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-2 10H7v-2h10v2z"
  }) : on ? /*#__PURE__*/React.createElement("path", {
    fill: "currentColor",
    d: "M19 3H5c-1.11 0-2 .9-2 2v14c0 1.1.89 2 2 2h14c1.11 0 2-.9 2-2V5c0-1.1-.89-2-2-2zm-9 14l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"
  }) : /*#__PURE__*/React.createElement("path", {
    fill: "currentColor",
    d: "M19 5v14H5V5h14zm0-2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2z"
  })));
}
Object.assign(__ds_scope, { Checkbox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/inputs/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/data-grid/DataGridCellRow.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** [McDataGrid | Cell Rows] <DataGrid> | Cell Rows — 4 states × 3–10 columns × divider. */
function DataGridCellRow({
  cells = [],
  checkbox = false,
  selected = false,
  divider = true,
  density = 'standard',
  state,
  onClick,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const s = state || (selected ? 'selected' : hover ? 'hover' : 'default');
  const h = density === 'compact' ? 36 : density === 'comfortable' ? 60 : 52;
  return /*#__PURE__*/React.createElement("div", _extends({
    role: "row",
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    onClick: onClick,
    style: {
      display: 'flex',
      alignItems: 'stretch',
      background: s === 'selected' ? 'var(--primary-state-selected)' : s === 'hover' ? 'var(--action-hover)' : 'transparent',
      borderBottom: divider ? '1px solid var(--border-divider)' : 'none',
      cursor: onClick ? 'pointer' : 'default',
      transition: 'background-color var(--transition-fast)',
      ...style
    }
  }, rest), checkbox ? /*#__PURE__*/React.createElement("div", {
    style: {
      width: 50,
      height: h,
      flexShrink: 0,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Checkbox, {
    size: "small",
    checked: selected
  })) : null, cells.map((c, i) => {
    const cell = c && typeof c === 'object' && !React.isValidElement(c) ? c : {
      value: c
    };
    return /*#__PURE__*/React.createElement(__ds_scope.DataGridCell, _extends({
      key: i,
      density: density,
      state: "default"
    }, cell));
  }));
}
Object.assign(__ds_scope, { DataGridCellRow });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data-grid/DataGridCellRow.jsx", error: String((e && e.message) || e) }); }

// components/data-grid/DataGridHeader.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** [McDataGrid | Header] <DataGrid> | Header — checkbox × 4 states × 3 sort states × master-detail × aggregation. */
function DataGridHeader({
  label,
  checkbox = false,
  state = 'default',
  sort = 'none',
  aggregation = false,
  rowOrdering = false,
  width,
  align,
  density = 'standard',
  style,
  ...rest
}) {
  const h = density === 'compact' ? 40 : density === 'comfortable' ? 60 : 56;
  const [hover, setHover] = React.useState(false);
  const showSort = sort !== 'none' || hover || state === 'hover';
  if (checkbox) {
    return /*#__PURE__*/React.createElement("div", _extends({
      role: "columnheader",
      style: {
        boxSizing: 'border-box',
        height: h,
        width: 50,
        flexShrink: 0,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        ...style
      }
    }, rest), /*#__PURE__*/React.createElement(__ds_scope.Checkbox, {
      size: "small"
    }));
  }
  return /*#__PURE__*/React.createElement("div", _extends({
    role: "columnheader",
    "aria-sort": sort === 'none' ? 'none' : sort === 'asc' ? 'ascending' : 'descending',
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      boxSizing: 'border-box',
      height: h,
      width,
      flexShrink: width ? 0 : 1,
      flexGrow: width ? 0 : 1,
      display: 'flex',
      alignItems: 'center',
      gap: 4,
      padding: '0 10px',
      background: state === 'selected' ? 'var(--primary-state-selected)' : state === 'hover' ? 'var(--action-hover)' : 'transparent',
      justifyContent: align === 'right' ? 'flex-end' : align === 'center' ? 'center' : 'flex-start',
      fontFamily: 'var(--font-ui)',
      fontWeight: 500,
      fontSize: 14,
      lineHeight: '24px',
      letterSpacing: '0.17px',
      color: 'var(--text-primary)',
      whiteSpace: 'nowrap',
      overflow: 'hidden',
      cursor: 'pointer',
      ...style
    }
  }, rest), rowOrdering ? /*#__PURE__*/React.createElement("svg", {
    width: "20",
    height: "20",
    viewBox: "0 0 24 24",
    "aria-hidden": "true",
    style: {
      color: 'var(--action-active)'
    }
  }, /*#__PURE__*/React.createElement("path", {
    fill: "currentColor",
    d: "M11 18c0 1.1-.9 2-2 2s-2-.9-2-2 .9-2 2-2 2 .9 2 2zm-2-8c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0-6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm6 4c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm0 2c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0 6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z"
  })) : null, /*#__PURE__*/React.createElement("span", {
    style: {
      overflow: 'hidden',
      textOverflow: 'ellipsis'
    }
  }, label), aggregation ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-ui)',
      fontSize: 12,
      letterSpacing: '0.4px',
      color: 'var(--text-secondary)'
    }
  }, "(sum)") : null, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      opacity: showSort ? 1 : 0,
      transition: 'opacity var(--transition-fast)',
      color: 'var(--action-active)'
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: "20",
    height: "20",
    viewBox: "0 0 24 24",
    "aria-hidden": "true",
    style: {
      transform: sort === 'desc' ? 'rotate(180deg)' : 'none'
    }
  }, /*#__PURE__*/React.createElement("path", {
    fill: "currentColor",
    d: "M4 12l1.41 1.41L11 7.83V20h2V7.83l5.58 5.59L20 12l-8-8-8 8z"
  }))));
}
Object.assign(__ds_scope, { DataGridHeader });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data-grid/DataGridHeader.jsx", error: String((e && e.message) || e) }); }

// components/data-grid/DataGridHeaderRow.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** [McDataGrid | Header Rows] <DataGrid> | Header Rows — 2 states × 3–10 columns. */
function DataGridHeaderRow({
  columns = [],
  checkbox = false,
  selected = false,
  density = 'standard',
  sort,
  onSort,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    role: "row",
    style: {
      display: 'flex',
      alignItems: 'stretch',
      background: selected ? 'var(--primary-state-selected)' : 'var(--surface-card)',
      borderBottom: '1px solid var(--border-divider)',
      ...style
    }
  }, rest), checkbox ? /*#__PURE__*/React.createElement(__ds_scope.DataGridHeader, {
    checkbox: true,
    density: density
  }) : null, columns.map((c, i) => {
    const col = typeof c === 'string' ? {
      label: c
    } : c;
    return /*#__PURE__*/React.createElement(__ds_scope.DataGridHeader, _extends({
      key: i,
      density: density
    }, col, {
      sort: sort && sort.index === i ? sort.direction : 'none',
      onClick: onSort ? () => onSort(i) : undefined
    }));
  }));
}
Object.assign(__ds_scope, { DataGridHeaderRow });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data-grid/DataGridHeaderRow.jsx", error: String((e && e.message) || e) }); }

// components/inputs/EyeIconToggle.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** _Eye Icon Toggle — the show/hide-value control inside masked inputs. */
function EyeIconToggle({
  visible,
  onChange,
  disabled = false,
  size = 20,
  style,
  ...rest
}) {
  const [internal, setInternal] = React.useState(false);
  const on = visible !== undefined ? visible : internal;
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    "aria-label": on ? 'Hide value' : 'Show value',
    disabled: disabled,
    onClick: () => {
      const n = !on;
      if (visible === undefined) setInternal(n);
      onChange && onChange(n);
    },
    style: {
      display: 'inline-flex',
      border: 'none',
      background: 'transparent',
      padding: 0,
      cursor: disabled ? 'default' : 'pointer',
      color: disabled ? 'var(--action-disabled)' : 'var(--action-active)',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("svg", {
    width: size,
    height: size,
    viewBox: "0 0 24 24",
    "aria-hidden": "true"
  }, on ? /*#__PURE__*/React.createElement("path", {
    fill: "currentColor",
    d: "M12 4.5C7 4.5 2.73 7.61 1 12c1.73 4.39 6 7.5 11 7.5s9.27-3.11 11-7.5c-1.73-4.39-6-7.5-11-7.5zm0 12a4.5 4.5 0 110-9 4.5 4.5 0 010 9zm0-7.2a2.7 2.7 0 100 5.4 2.7 2.7 0 000-5.4z"
  }) : /*#__PURE__*/React.createElement("path", {
    fill: "currentColor",
    d: "M12 7a5 5 0 015 5c0 .65-.13 1.26-.36 1.83l2.92 2.92A11.8 11.8 0 0023 12c-1.73-4.39-6-7.5-11-7.5-1.27 0-2.49.2-3.64.57l2.17 2.16A5 5 0 0112 7zM2.71 3.16L1.3 4.57l2.48 2.48A11.8 11.8 0 001 12c1.73 4.39 6 7.5 11 7.5 1.55 0 3.03-.3 4.38-.84l3.05 3.05 1.41-1.41L2.71 3.16zM12 17a5 5 0 01-4.72-6.63l1.53 1.53c-.01.03-.01.07-.01.1a3.2 3.2 0 003.2 3.2c.04 0 .07 0 .1-.01l1.53 1.53c-.5.18-1.05.28-1.63.28z"
  })));
}
Object.assign(__ds_scope, { EyeIconToggle });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/inputs/EyeIconToggle.jsx", error: String((e && e.message) || e) }); }

// components/inputs/FormControlLabel.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** [MCFormControlLabel] <FormControlLabel> — pairs a control with its label. 4 placements × disabled. */
function FormControlLabel({
  control,
  label,
  labelPlacement = 'end',
  disabled = false,
  style,
  ...rest
}) {
  const column = labelPlacement === 'top' || labelPlacement === 'bottom';
  const reverse = labelPlacement === 'start' || labelPlacement === 'top';
  return /*#__PURE__*/React.createElement("label", _extends({
    style: {
      display: 'inline-flex',
      flexDirection: column ? reverse ? 'column-reverse' : 'column' : reverse ? 'row-reverse' : 'row',
      alignItems: 'center',
      gap: column ? 0 : 0,
      cursor: disabled ? 'default' : 'pointer',
      ...style
    }
  }, rest), control, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-ui)',
      fontWeight: 400,
      fontSize: 16,
      lineHeight: 1.5,
      letterSpacing: '0.15px',
      color: disabled ? 'var(--text-disabled)' : 'var(--text-primary)',
      paddingRight: labelPlacement === 'start' ? 8 : 0,
      paddingLeft: labelPlacement === 'end' ? 0 : 0
    }
  }, label));
}
Object.assign(__ds_scope, { FormControlLabel });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/inputs/FormControlLabel.jsx", error: String((e && e.message) || e) }); }

// components/inputs/FormGroup.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** <FormGroup> | <Checkbox> — vertical or row grouping of selection controls, with optional label + helper. */
function FormGroup({
  label,
  helperText,
  error = false,
  disabled = false,
  row = false,
  children,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("fieldset", _extends({
    style: {
      border: 'none',
      margin: 0,
      padding: 0,
      display: 'flex',
      flexDirection: 'column',
      gap: 4,
      ...style
    }
  }, rest), label ? /*#__PURE__*/React.createElement("legend", {
    style: {
      padding: 0,
      fontFamily: 'var(--font-ui)',
      fontWeight: 400,
      fontSize: 16,
      lineHeight: 1.5,
      letterSpacing: '0.15px',
      color: error ? 'var(--error-main)' : disabled ? 'var(--text-disabled)' : 'var(--text-secondary)'
    }
  }, label) : null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: row ? 'row' : 'column',
      gap: row ? 16 : 0,
      flexWrap: 'wrap'
    }
  }, children), helperText ? /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      padding: '3px 14px',
      fontFamily: 'var(--font-ui)',
      fontSize: 12,
      lineHeight: 1.66,
      letterSpacing: '0.4px',
      color: error ? 'var(--error-main)' : 'var(--text-secondary)'
    }
  }, helperText) : null);
}
Object.assign(__ds_scope, { FormGroup });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/inputs/FormGroup.jsx", error: String((e && e.message) || e) }); }

// components/inputs/FormHelperText.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** [McFormHelperText] <FormHelperText> — 3px 14px padding, caption type. */
function FormHelperText({
  disabled = false,
  error = false,
  children,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("p", _extends({
    style: {
      margin: 0,
      padding: '3px 14px',
      fontFamily: 'var(--font-ui)',
      fontWeight: 400,
      fontSize: 12,
      lineHeight: 1.66,
      letterSpacing: '0.4px',
      color: error ? 'var(--error-main)' : disabled ? 'var(--text-disabled)' : 'var(--text-secondary)',
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { FormHelperText });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/inputs/FormHelperText.jsx", error: String((e && e.message) || e) }); }

// components/inputs/FormLabel.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const TINT = {
  primary: 'var(--primary-main)',
  secondary: 'var(--secondary-main)',
  error: 'var(--error-main)',
  warning: 'var(--warning-main)',
  info: 'var(--info-main)',
  success: 'var(--success-main)',
  default: 'var(--text-secondary)'
};

/** [McFormLabel] <FormLabel> — 7 colours × 3 states. */
function FormLabel({
  color = 'default',
  focused = false,
  disabled = false,
  error = false,
  required = false,
  children,
  style,
  ...rest
}) {
  const c = error ? TINT.error : focused ? TINT[color] || TINT.primary : disabled ? 'var(--text-disabled)' : 'var(--text-secondary)';
  return /*#__PURE__*/React.createElement("label", _extends({
    style: {
      fontFamily: 'var(--font-ui)',
      fontWeight: 400,
      fontSize: 16,
      lineHeight: 1.5,
      letterSpacing: '0.15px',
      color: c,
      ...style
    }
  }, rest), children, required ? /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--error-main)'
    }
  }, " *") : null);
}
Object.assign(__ds_scope, { FormLabel });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/inputs/FormLabel.jsx", error: String((e && e.message) || e) }); }

// components/inputs/HelpersButtonIconContainer.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const SIZES = {
  sm: 16,
  md: 20,
  lg: 24
};
const TINT = {
  primary: '#FFFFFF',
  secondary: 'var(--primary-main)',
  disabled: 'var(--text-disabled)'
};

/** .Helpers/button-icon-container — the padded icon slot inside Button. 3 types × 2 placements × 3 sizes. */
function HelpersButtonIconContainer({
  type = 'primary',
  placement = 'left',
  size = 'md',
  children,
  style,
  ...rest
}) {
  const px = SIZES[size] || 20;
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      width: px,
      height: px,
      color: TINT[type] || TINT.primary,
      marginLeft: placement === 'right' ? 4 : 0,
      marginRight: placement === 'left' ? 4 : 0,
      flexShrink: 0,
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { HelpersButtonIconContainer });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/inputs/HelpersButtonIconContainer.jsx", error: String((e && e.message) || e) }); }

// components/inputs/HelpersField.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** .Helpers / Field — the annotated field skeleton the library uses in specimen sheets. 5 types × 6 states. */
function HelpersField({
  type = 'text',
  state = 'enabled',
  label = 'Label',
  children,
  style,
  ...rest
}) {
  const border = state === 'error' ? 'var(--error-main)' : state === 'focused' ? 'var(--primary-main)' : state === 'disabled' ? 'rgba(0,0,0,0.12)' : state === 'hovered' ? 'var(--border-input-hover)' : 'var(--border-input)';
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 4,
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-ui)',
      fontSize: 12,
      lineHeight: '12px',
      letterSpacing: '0.15px',
      color: 'var(--text-secondary)'
    }
  }, label), /*#__PURE__*/React.createElement("div", {
    style: {
      minHeight: 56,
      borderRadius: 'var(--radius-md)',
      boxShadow: `inset 0 0 0 2px ${border}`,
      display: 'flex',
      alignItems: 'center',
      padding: '0 12px',
      gap: 8
    }
  }, children), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-ui)',
      fontSize: 12,
      lineHeight: 1.66,
      letterSpacing: '0.4px',
      color: 'var(--text-disabled)',
      padding: '0 14px'
    }
  }, "type: ", type, " \xB7 state: ", state));
}
Object.assign(__ds_scope, { HelpersField });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/inputs/HelpersField.jsx", error: String((e && e.message) || e) }); }

// components/inputs/HelpersText.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const OPTS = {
  'text-only': {
    icon: false,
    secondary: false
  },
  'text-secondary': {
    icon: false,
    secondary: true
  },
  'text-icon': {
    icon: true,
    secondary: false
  },
  'icon-only': {
    icon: true,
    secondary: false,
    hideText: true
  },
  'text-icon-secondary': {
    icon: true,
    secondary: true
  }
};

/** .Helpers / Text — the 5-option text slot (text only / +secondary / +icon / icon only). */
function HelpersText({
  option = 'text-only',
  primary = 'Primary',
  secondary = 'Secondary',
  icon,
  style,
  ...rest
}) {
  const o = OPTS[option] || OPTS['text-only'];
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 8,
      ...style
    }
  }, rest), o.icon && icon ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      color: 'var(--action-active)'
    }
  }, icon) : null, !o.hideText ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      flexDirection: 'column'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-ui)',
      fontSize: 14,
      lineHeight: '24px',
      letterSpacing: '0.17px',
      fontWeight: 500,
      color: 'var(--text-primary)'
    }
  }, primary), o.secondary ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-ui)',
      fontSize: 12,
      lineHeight: 1.66,
      letterSpacing: '0.4px',
      color: 'var(--text-secondary)'
    }
  }, secondary) : null) : null);
}
Object.assign(__ds_scope, { HelpersText });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/inputs/HelpersText.jsx", error: String((e && e.message) || e) }); }

// components/inputs/IconButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const COLORS = {
  primary: {
    main: 'var(--primary-main)',
    dark: 'var(--primary-dark)',
    contrast: '#FFFFFF',
    hover: 'rgba(69,83,169,0.04)',
    outline: 'rgba(69,83,169,0.5)'
  },
  secondary: {
    main: 'var(--secondary-main)',
    dark: 'var(--secondary-dark)',
    contrast: 'rgba(0,0,0,0.87)',
    hover: 'rgba(255,208,8,0.04)',
    outline: 'rgba(255,208,8,0.5)'
  },
  error: {
    main: 'var(--error-main)',
    dark: 'var(--error-dark)',
    contrast: '#FFFFFF',
    hover: 'rgba(211,47,47,0.04)',
    outline: 'rgba(211,47,47,0.5)'
  },
  warning: {
    main: 'var(--warning-main)',
    dark: 'var(--warning-dark)',
    contrast: '#FFFFFF',
    hover: 'rgba(239,108,0,0.04)',
    outline: 'rgba(239,108,0,0.5)'
  },
  info: {
    main: 'var(--info-main)',
    dark: 'var(--info-dark)',
    contrast: '#FFFFFF',
    hover: 'rgba(2,136,209,0.04)',
    outline: 'rgba(2,136,209,0.5)'
  },
  success: {
    main: 'var(--success-main)',
    dark: 'var(--success-dark)',
    contrast: '#FFFFFF',
    hover: 'rgba(46,125,50,0.04)',
    outline: 'rgba(46,125,50,0.5)'
  },
  inherit: {
    main: 'currentColor',
    dark: 'currentColor',
    contrast: 'var(--text-primary)',
    hover: 'rgba(0,0,0,0.04)',
    outline: 'rgba(0,0,0,0.23)'
  },
  default: {
    main: 'var(--action-active)',
    dark: 'rgba(0,0,0,0.76)',
    contrast: '#FFFFFF',
    hover: 'rgba(0,0,0,0.04)',
    outline: 'rgba(0,0,0,0.23)'
  }
};
const SIZES = {
  small: {
    box: 30,
    pad: 5,
    icon: 20
  },
  medium: {
    box: 40,
    pad: 8,
    icon: 24
  },
  large: {
    box: 48,
    pad: 12,
    icon: 24
  }
};

/** [McIconButton] <IconButton> — circular 100px-radius hit target. 3 sizes × 9 colours × 5 states. */
function IconButton({
  color = 'default',
  size = 'medium',
  disabled = false,
  state,
  edge,
  children,
  style,
  ...rest
}) {
  const c = COLORS[color] || COLORS.default;
  const s = SIZES[size] || SIZES.medium;
  const [hover, setHover] = React.useState(false);
  const isHover = state === 'hovered' || state == null && hover && !disabled;
  const isFocus = state === 'focused';
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    disabled: disabled,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      width: s.box,
      height: s.box,
      padding: s.pad,
      boxSizing: 'border-box',
      borderRadius: 'var(--radius-pill)',
      border: 'none',
      background: isHover ? color === 'default' ? 'var(--action-hover)' : c.hover : 'transparent',
      color: disabled ? 'var(--action-disabled)' : c.main,
      cursor: disabled ? 'default' : 'pointer',
      outline: isFocus ? `3px solid ${c.outline}` : 'none',
      marginLeft: edge === 'start' ? -s.pad : undefined,
      marginRight: edge === 'end' ? -s.pad : undefined,
      transition: 'background-color var(--transition-fast)',
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/inputs/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/inputs/LoadingButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** [McLoadingButton] <LoadingButton> — Button with an inline circular indicator. */
function LoadingButton({
  loading = false,
  loadingPosition = 'start',
  size = 'medium',
  variant = 'contained',
  children,
  ...rest
}) {
  const spinnerSize = size === 'small' ? 16 : size === 'large' ? 20 : 18;
  const spinner = /*#__PURE__*/React.createElement(__ds_scope.Progress, {
    size: spinnerSize,
    thickness: 3.6,
    color: variant === 'contained' ? 'inherit' : 'primary'
  });
  return /*#__PURE__*/React.createElement(__ds_scope.Button, _extends({
    size: size,
    variant: variant,
    disabled: loading || rest.disabled,
    startIcon: loading && loadingPosition === 'start' ? spinner : rest.startIcon,
    endIcon: loading && loadingPosition === 'end' ? spinner : rest.endIcon
  }, rest), children);
}
Object.assign(__ds_scope, { LoadingButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/inputs/LoadingButton.jsx", error: String((e && e.message) || e) }); }

// components/inputs/LockIconToggle.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** _Lock Icon Toggle — marks a field as locked / editable. */
function LockIconToggle({
  locked,
  onChange,
  disabled = false,
  size = 20,
  style,
  ...rest
}) {
  const [internal, setInternal] = React.useState(true);
  const on = locked !== undefined ? locked : internal;
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    "aria-label": on ? 'Unlock field' : 'Lock field',
    disabled: disabled,
    onClick: () => {
      const n = !on;
      if (locked === undefined) setInternal(n);
      onChange && onChange(n);
    },
    style: {
      display: 'inline-flex',
      border: 'none',
      background: 'transparent',
      padding: 0,
      cursor: disabled ? 'default' : 'pointer',
      color: disabled ? 'var(--action-disabled)' : on ? 'var(--action-active)' : 'var(--primary-main)',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("svg", {
    width: size,
    height: size,
    viewBox: "0 0 24 24",
    "aria-hidden": "true"
  }, on ? /*#__PURE__*/React.createElement("path", {
    fill: "currentColor",
    d: "M18 8h-1V6a5 5 0 00-10 0v2H6a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V10a2 2 0 00-2-2zm-6 9a2 2 0 110-4 2 2 0 010 4zm3-9H9V6a3 3 0 016 0v2z"
  }) : /*#__PURE__*/React.createElement("path", {
    fill: "currentColor",
    d: "M18 8h-1V6a5 5 0 00-9.9-.9l1.95.4A3 3 0 0115 6v2H6a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V10a2 2 0 00-2-2zm-6 9a2 2 0 110-4 2 2 0 010 4z"
  })));
}
Object.assign(__ds_scope, { LockIconToggle });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/inputs/LockIconToggle.jsx", error: String((e && e.message) || e) }); }

// components/inputs/Select.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const VALUE_TYPE = {
  fontFamily: 'var(--font-ui)',
  fontWeight: 400,
  fontSize: 16,
  lineHeight: '24px',
  letterSpacing: '0.15px'
};
const HEIGHTS = {
  outlined: {
    medium: 56,
    small: 40
  },
  filled: {
    medium: 56,
    small: 40
  },
  standard: {
    medium: 48,
    small: 40
  }
};
const CONTENT_PAD = {
  outlined: {
    medium: '16px 0',
    small: '8px 0'
  },
  filled: {
    medium: '9px 12px 8px',
    small: '6px 12px 5px'
  },
  standard: {
    medium: '12px 0',
    small: '8px 0'
  }
};
function shellStyle(variant, size, state, error) {
  const h = HEIGHTS[variant][size];
  const accent = error ? 'var(--error-main)' : state === 'focused' ? 'var(--primary-main)' : null;
  if (variant === 'outlined') {
    const ring = state === 'disabled' ? 'rgba(0,0,0,0.12)' : accent || (state === 'hovered' ? 'var(--border-input-hover)' : 'var(--border-input)');
    return {
      height: h,
      borderRadius: 'var(--radius-md)',
      padding: '0 12px',
      boxShadow: `inset 0 0 0 ${state === 'focused' ? 2 : 2}px ${ring}`
    };
  }
  if (variant === 'filled') {
    return {
      height: h,
      borderRadius: '12px 12px 0 0',
      background: state === 'disabled' ? 'rgba(0,0,0,0.03)' : state === 'hovered' ? 'rgba(0,0,0,0.09)' : 'rgba(0,0,0,0.06)',
      boxShadow: `inset 0 -${accent ? 2 : 1}px 0 0 ${accent || 'rgba(0,0,0,0.42)'}`
    };
  }
  return {
    height: h,
    boxShadow: `inset 0 -${accent ? 2 : 1}px 0 0 ${accent || 'rgba(0,0,0,0.42)'}`
  };
}

/** [McSelect] <Select> — same shell as TextField plus the drop-down caret. 72 variants. */
function Select({
  variant = 'outlined',
  size = 'medium',
  label,
  value,
  placeholder = 'Select',
  options = [],
  helperText,
  error = false,
  disabled = false,
  state,
  active,
  fullWidth = false,
  onChange,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const [open, setOpen] = React.useState(false);
  const isOpen = active !== undefined ? active : open;
  const s = disabled ? 'disabled' : state || (isOpen ? 'focused' : hover ? 'hovered' : 'enabled');
  const shell = shellStyle(variant, size, s, error);
  const hasValue = value !== undefined && value !== '';
  const floated = variant !== 'outlined' || hasValue || s === 'focused';
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: 'flex',
      flexDirection: 'column',
      width: fullWidth ? '100%' : 220,
      position: 'relative',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    role: "combobox",
    "aria-expanded": isOpen,
    tabIndex: disabled ? -1 : 0,
    onClick: () => {
      if (!disabled) setOpen(o => !o);
    },
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      ...shell,
      boxSizing: 'border-box',
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      cursor: disabled ? 'default' : 'pointer',
      padding: variant === 'outlined' ? '0 12px' : shell.padding
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      ...VALUE_TYPE,
      flex: 1,
      minWidth: 0,
      overflow: 'hidden',
      textOverflow: 'ellipsis',
      whiteSpace: 'nowrap',
      color: disabled ? 'var(--text-disabled)' : hasValue ? 'var(--text-primary)' : 'var(--text-disabled)'
    }
  }, hasValue ? value : placeholder), /*#__PURE__*/React.createElement("svg", {
    width: "24",
    height: "24",
    viewBox: "0 0 24 24",
    "aria-hidden": "true",
    style: {
      flexShrink: 0,
      color: disabled ? 'var(--action-disabled)' : 'var(--action-active)',
      transform: isOpen ? 'rotate(180deg)' : 'none',
      transition: 'transform var(--transition-fast)'
    }
  }, /*#__PURE__*/React.createElement("path", {
    fill: "currentColor",
    d: "M7 10l5 5 5-5z"
  }))), label ? /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      left: variant === 'outlined' ? 12 : 12,
      top: floated ? -6 : '50%',
      transform: floated ? 'none' : 'translateY(-50%)',
      padding: variant === 'outlined' ? '0 4px' : 0,
      background: variant === 'outlined' ? 'var(--surface-card)' : 'transparent',
      fontFamily: 'var(--font-ui)',
      fontSize: floated ? 12 : 16,
      lineHeight: floated ? '12px' : '24px',
      letterSpacing: '0.15px',
      pointerEvents: 'none',
      color: error ? 'var(--error-main)' : s === 'focused' ? 'var(--primary-main)' : 'var(--text-secondary)'
    }
  }, label) : null, isOpen && options.length ? /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: '100%',
      left: 0,
      right: 0,
      marginTop: 4,
      zIndex: 20,
      background: 'var(--surface-card)',
      borderRadius: 'var(--radius-md)',
      boxShadow: 'var(--shadow-8)',
      padding: '8px 0',
      maxHeight: 288,
      overflowY: 'auto'
    }
  }, options.map(o => /*#__PURE__*/React.createElement("div", {
    key: o,
    onClick: () => {
      onChange && onChange(o);
      setOpen(false);
    },
    style: {
      padding: '6px 16px',
      minHeight: 36,
      display: 'flex',
      alignItems: 'center',
      fontFamily: 'var(--font-ui)',
      fontSize: 16,
      lineHeight: 1.5,
      letterSpacing: '0.15px',
      background: o === value ? 'var(--primary-state-selected)' : 'transparent',
      cursor: 'pointer'
    }
  }, o))) : null, helperText ? /*#__PURE__*/React.createElement(__ds_scope.FormHelperText, {
    error: error,
    disabled: disabled
  }, helperText) : null);
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/inputs/Select.jsx", error: String((e && e.message) || e) }); }

// components/inputs/Star.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const SIZES = {
  small: 18,
  medium: 24,
  large: 30
};

/** [McStar] <Star> — one rating glyph. 3 sizes × 3 active states × hovered. */
function Star({
  size = 'medium',
  active = 'empty',
  hovered = false,
  style,
  ...rest
}) {
  const px = SIZES[size] || 24;
  const color = active === 'empty' && !hovered ? 'var(--action-disabled)' : 'var(--secondary-main)';
  return /*#__PURE__*/React.createElement("svg", _extends({
    width: px,
    height: px,
    viewBox: "0 0 24 24",
    "aria-hidden": "true",
    style: {
      display: 'block',
      color,
      ...style
    }
  }, rest), active === 'half' ? /*#__PURE__*/React.createElement("path", {
    fill: "currentColor",
    d: "M22 9.24l-7.19-.62L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21 12 17.27 18.18 21l-1.63-7.03L22 9.24zM12 15.4V6.1l1.71 4.04 4.38.38-3.32 2.88 1 4.28L12 15.4z"
  }) : active === 'filled' ? /*#__PURE__*/React.createElement("path", {
    fill: "currentColor",
    d: "M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"
  }) : /*#__PURE__*/React.createElement("path", {
    fill: "currentColor",
    d: "M22 9.24l-7.19-.62L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21 12 17.27 18.18 21l-1.63-7.03L22 9.24zM12 15.4l-3.76 2.27 1-4.28-3.32-2.88 4.38-.38L12 6.1l1.71 4.04 4.38.38-3.32 2.88 1 4.28L12 15.4z"
  }));
}
Object.assign(__ds_scope, { Star });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/inputs/Star.jsx", error: String((e && e.message) || e) }); }

// components/inputs/Rating.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** <Rating> — 3 sizes × disabled. Five stars, gold when filled. */
function Rating({
  value = 0,
  max = 5,
  size = 'medium',
  disabled = false,
  readOnly = false,
  onChange,
  style,
  ...rest
}) {
  const [hoverIdx, setHoverIdx] = React.useState(null);
  const shown = hoverIdx ?? value;
  return /*#__PURE__*/React.createElement("div", _extends({
    role: "radiogroup",
    style: {
      display: 'inline-flex',
      gap: 2,
      opacity: disabled ? 0.38 : 1,
      ...style
    }
  }, rest), Array.from({
    length: max
  }).map((_, i) => {
    const n = i + 1;
    const active = shown >= n ? 'filled' : shown >= n - 0.5 ? 'half' : 'empty';
    return /*#__PURE__*/React.createElement("span", {
      key: i,
      onMouseEnter: () => !disabled && !readOnly && setHoverIdx(n),
      onMouseLeave: () => setHoverIdx(null),
      onClick: () => !disabled && !readOnly && onChange && onChange(n),
      style: {
        cursor: disabled || readOnly ? 'default' : 'pointer',
        display: 'flex'
      }
    }, /*#__PURE__*/React.createElement(__ds_scope.Star, {
      size: size,
      active: active,
      hovered: hoverIdx === n
    }));
  }));
}
Object.assign(__ds_scope, { Rating });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/inputs/Rating.jsx", error: String((e && e.message) || e) }); }

// components/inputs/Switch.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const TINT = {
  primary: 'var(--primary-main)',
  secondary: 'var(--secondary-main)',
  error: 'var(--error-main)',
  warning: 'var(--warning-main)',
  info: 'var(--info-main)',
  success: 'var(--success-main)',
  default: 'var(--action-active)'
};

/** [McSwitch] <Switch> — 2 sizes × 7 colours × 5 states. */
function Switch({
  checked,
  size = 'medium',
  color = 'primary',
  disabled = false,
  onChange,
  style,
  ...rest
}) {
  const [internal, setInternal] = React.useState(false);
  const on = checked !== undefined ? checked : internal;
  const small = size === 'small';
  const trackW = small ? 26 : 34,
    trackH = small ? 14 : 14,
    thumb = small ? 12 : 20;
  const tint = TINT[color] || TINT.primary;
  return /*#__PURE__*/React.createElement("span", _extends({
    role: "switch",
    "aria-checked": on,
    "aria-disabled": disabled,
    tabIndex: disabled ? -1 : 0,
    onClick: () => {
      if (disabled) return;
      const n = !on;
      if (checked === undefined) setInternal(n);
      onChange && onChange(n);
    },
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      padding: small ? '6px 8px' : '9px 12px',
      cursor: disabled ? 'default' : 'pointer',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'relative',
      width: trackW,
      height: trackH,
      borderRadius: 'var(--radius-pill)',
      background: disabled ? 'rgba(0,0,0,0.12)' : on ? tint : 'rgba(0,0,0,0.38)',
      opacity: on && !disabled ? 0.5 : 1,
      transition: 'background-color var(--transition-fast)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      top: '50%',
      left: on ? trackW - thumb + (small ? 2 : 6) : small ? -2 : -6,
      transform: 'translateY(-50%)',
      width: thumb,
      height: thumb,
      borderRadius: 'var(--radius-pill)',
      background: disabled ? 'var(--grey-100)' : on ? tint : '#FFFFFF',
      boxShadow: 'var(--shadow-1)',
      transition: 'left var(--transition-fast), background-color var(--transition-fast)'
    }
  })));
}
Object.assign(__ds_scope, { Switch });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/inputs/Switch.jsx", error: String((e && e.message) || e) }); }

// components/inputs/TextField.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const VALUE_TYPE = {
  fontFamily: 'var(--font-ui)',
  fontWeight: 400,
  fontSize: 16,
  lineHeight: '24px',
  letterSpacing: '0.15px'
};
const HEIGHTS = {
  outlined: {
    medium: 56,
    small: 40
  },
  filled: {
    medium: 56,
    small: 40
  },
  standard: {
    medium: 48,
    small: 40
  }
};
const CONTENT_PAD = {
  outlined: {
    medium: '16px 0',
    small: '8px 0'
  },
  filled: {
    medium: '9px 12px 8px',
    small: '6px 12px 5px'
  },
  standard: {
    medium: '12px 0',
    small: '8px 0'
  }
};
function shellStyle(variant, size, state, error) {
  const h = HEIGHTS[variant][size];
  const accent = error ? 'var(--error-main)' : state === 'focused' ? 'var(--primary-main)' : null;
  if (variant === 'outlined') {
    const ring = state === 'disabled' ? 'rgba(0,0,0,0.12)' : accent || (state === 'hovered' ? 'var(--border-input-hover)' : 'var(--border-input)');
    return {
      height: h,
      borderRadius: 'var(--radius-md)',
      padding: '0 12px',
      boxShadow: `inset 0 0 0 ${state === 'focused' ? 2 : 2}px ${ring}`
    };
  }
  if (variant === 'filled') {
    return {
      height: h,
      borderRadius: '12px 12px 0 0',
      background: state === 'disabled' ? 'rgba(0,0,0,0.03)' : state === 'hovered' ? 'rgba(0,0,0,0.09)' : 'rgba(0,0,0,0.06)',
      boxShadow: `inset 0 -${accent ? 2 : 1}px 0 0 ${accent || 'rgba(0,0,0,0.42)'}`
    };
  }
  return {
    height: h,
    boxShadow: `inset 0 -${accent ? 2 : 1}px 0 0 ${accent || 'rgba(0,0,0,0.42)'}`
  };
}

/** [McTextField] <TextField> — 3 variants × 2 sizes × 5 states × has-value. */
function TextField({
  variant = 'outlined',
  size = 'medium',
  label,
  value,
  placeholder,
  helperText,
  error = false,
  disabled = false,
  state,
  startAdornment,
  endAdornment,
  fullWidth = false,
  onChange,
  style,
  inputProps,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const [focus, setFocus] = React.useState(false);
  const s = disabled ? 'disabled' : state || (focus ? 'focused' : hover ? 'hovered' : 'enabled');
  const shell = shellStyle(variant, size, s, error);
  const hasValue = value !== undefined && value !== '';
  const floated = variant !== 'outlined' || hasValue || s === 'focused' || !!placeholder;
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: 'flex',
      flexDirection: 'column',
      width: fullWidth ? '100%' : 220,
      position: 'relative',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      ...shell,
      boxSizing: 'border-box',
      display: 'flex',
      alignItems: 'center',
      width: '100%'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 0,
      flex: 1,
      minWidth: 0,
      padding: CONTENT_PAD[variant][size],
      boxSizing: 'border-box',
      height: '100%'
    }
  }, startAdornment ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      alignItems: 'center',
      paddingRight: 8,
      color: 'var(--action-active)'
    }
  }, startAdornment) : null, /*#__PURE__*/React.createElement("input", _extends({
    disabled: disabled,
    value: value,
    placeholder: placeholder,
    onChange: e => onChange && onChange(e.target.value),
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      ...VALUE_TYPE,
      flex: 1,
      minWidth: 0,
      border: 'none',
      outline: 'none',
      background: 'transparent',
      padding: 0,
      color: disabled ? 'var(--text-disabled)' : 'var(--text-primary)'
    }
  }, inputProps)), endAdornment ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      alignItems: 'center',
      paddingLeft: 8,
      color: 'var(--action-active)'
    }
  }, endAdornment) : null)), label ? /*#__PURE__*/React.createElement("span", {
    style: variant === 'outlined' ? {
      position: 'absolute',
      left: 12,
      top: floated ? -6 : '50%',
      transform: floated ? 'none' : 'translateY(-50%)',
      padding: '0 4px',
      background: 'var(--surface-card)',
      fontFamily: 'var(--font-ui)',
      fontWeight: 400,
      fontSize: floated ? 12 : 16,
      lineHeight: floated ? '12px' : '24px',
      letterSpacing: '0.15px',
      pointerEvents: 'none',
      color: error ? 'var(--error-main)' : s === 'focused' ? 'var(--primary-main)' : disabled ? 'var(--text-disabled)' : 'var(--text-secondary)'
    } : {
      position: 'absolute',
      left: variant === 'filled' ? 12 : 0,
      top: 4,
      fontFamily: 'var(--font-ui)',
      fontSize: 12,
      lineHeight: '12px',
      letterSpacing: '0.15px',
      pointerEvents: 'none',
      color: error ? 'var(--error-main)' : s === 'focused' ? 'var(--primary-main)' : 'var(--text-secondary)'
    }
  }, label) : null, helperText ? /*#__PURE__*/React.createElement(__ds_scope.FormHelperText, {
    error: error,
    disabled: disabled
  }, helperText) : null);
}
Object.assign(__ds_scope, { TextField });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/inputs/TextField.jsx", error: String((e && e.message) || e) }); }

// components/data-grid/GridToolbarQuickFilter.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** [MCGridToolbarQuickFilter] <GridToolbarQuickFilter> — the grid's search + menu strip. */
function GridToolbarQuickFilter({
  value,
  onChange,
  onMenu,
  menus = ['Columns', 'Filters', 'Density', 'Export'],
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      padding: '8px 10px',
      borderBottom: '1px solid var(--border-divider)',
      background: 'var(--surface-card)',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 4,
      flex: 1,
      flexWrap: 'wrap'
    }
  }, menus.map(m => /*#__PURE__*/React.createElement(__ds_scope.Button, {
    key: m,
    variant: "text",
    size: "small",
    onClick: () => onMenu && onMenu(m)
  }, m))), /*#__PURE__*/React.createElement(__ds_scope.TextField, {
    size: "small",
    variant: "standard",
    placeholder: "Search\u2026",
    value: value,
    onChange: onChange,
    style: {
      width: 200
    },
    startAdornment: /*#__PURE__*/React.createElement("svg", {
      width: "20",
      height: "20",
      viewBox: "0 0 24 24",
      "aria-hidden": "true"
    }, /*#__PURE__*/React.createElement("path", {
      fill: "currentColor",
      d: "M15.5 14h-.79l-.28-.27a6.5 6.5 0 10-.7.7l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0A4.5 4.5 0 1114 9.5 4.5 4.5 0 019.5 14z"
    }))
  }));
}
Object.assign(__ds_scope, { GridToolbarQuickFilter });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data-grid/GridToolbarQuickFilter.jsx", error: String((e && e.message) || e) }); }

// components/data-grid/DataGridTable.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** [McDataGridTable] <DataGridTable> — 12 variants (checkbox × 3 densities × rows). The assembled grid. */
function DataGridTable({
  columns = [],
  rows = [],
  checkbox = false,
  density = 'standard',
  toolbar = false,
  selectedRows = [],
  onSelectRow,
  footer,
  pinnedRight = 0,
  style,
  ...rest
}) {
  const [sort, setSort] = React.useState(null);
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      background: 'var(--surface-card)',
      borderRadius: 'var(--radius-md)',
      boxShadow: 'var(--shadow-1)',
      overflow: 'hidden',
      display: 'flex',
      flexDirection: 'column',
      ...style
    }
  }, rest), toolbar ? /*#__PURE__*/React.createElement(__ds_scope.GridToolbarQuickFilter, null) : null, /*#__PURE__*/React.createElement("div", {
    style: {
      overflowX: 'auto'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      minWidth: '100%'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.DataGridHeaderRow, {
    columns: columns,
    checkbox: checkbox,
    density: density,
    sort: sort,
    onSort: i => setSort(s => s && s.index === i ? {
      index: i,
      direction: s.direction === 'asc' ? 'desc' : 'asc'
    } : {
      index: i,
      direction: 'asc'
    })
  }), rows.map((r, i) => /*#__PURE__*/React.createElement(__ds_scope.DataGridCellRow, {
    key: i,
    cells: r,
    checkbox: checkbox,
    density: density,
    selected: selectedRows.includes(i),
    onClick: onSelectRow ? () => onSelectRow(i) : undefined,
    divider: i < rows.length - 1
  })))), footer ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'flex-end',
      gap: 16,
      minHeight: 52,
      padding: '0 10px',
      borderTop: '1px solid var(--border-divider)',
      fontFamily: 'var(--font-ui)',
      fontSize: 12,
      lineHeight: 1.66,
      letterSpacing: '0.4px',
      color: 'var(--text-secondary)'
    }
  }, footer) : null);
}
Object.assign(__ds_scope, { DataGridTable });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data-grid/DataGridTable.jsx", error: String((e && e.message) || e) }); }

// components/inputs/Autocomplete.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** [McAutocomplete] <Autocomplete> — single or multiple value, open or closed. */
function Autocomplete({
  label,
  options = [],
  value,
  values = [],
  multiple = false,
  open,
  placeholder,
  onChange,
  disabled = false,
  fullWidth = false,
  style,
  ...rest
}) {
  const [q, setQ] = React.useState('');
  const [isOpen, setOpen] = React.useState(false);
  const shown = open !== undefined ? open : isOpen;
  const list = options.filter(o => o.toLowerCase().includes(q.toLowerCase()));
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      position: 'relative',
      width: fullWidth ? '100%' : 220,
      ...style
    }
  }, rest), multiple && values.length ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: 4,
      marginBottom: 4
    }
  }, values.map(v => /*#__PURE__*/React.createElement(__ds_scope.Chip, {
    key: v,
    label: v,
    size: "small",
    onDelete: () => onChange && onChange(values.filter(x => x !== v))
  }))) : null, /*#__PURE__*/React.createElement(__ds_scope.TextField, {
    label: label,
    fullWidth: true,
    disabled: disabled,
    value: multiple ? q : value ?? q,
    placeholder: placeholder,
    onChange: v => {
      setQ(v);
      setOpen(true);
    },
    inputProps: {
      onFocus: () => setOpen(true)
    },
    endAdornment: /*#__PURE__*/React.createElement("svg", {
      width: "24",
      height: "24",
      viewBox: "0 0 24 24",
      "aria-hidden": "true",
      style: {
        transform: shown ? 'rotate(180deg)' : 'none'
      }
    }, /*#__PURE__*/React.createElement("path", {
      fill: "currentColor",
      d: "M7 10l5 5 5-5z"
    }))
  }), shown && list.length ? /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: '100%',
      left: 0,
      right: 0,
      marginTop: 4,
      zIndex: 20,
      background: 'var(--surface-card)',
      borderRadius: 'var(--radius-md)',
      boxShadow: 'var(--shadow-8)',
      padding: '8px 0',
      maxHeight: 288,
      overflowY: 'auto'
    }
  }, list.map(o => /*#__PURE__*/React.createElement("div", {
    key: o,
    onClick: () => {
      multiple ? onChange && onChange([...new Set([...values, o])]) : onChange && onChange(o);
      setQ('');
      setOpen(false);
    },
    style: {
      padding: '6px 16px',
      minHeight: 36,
      display: 'flex',
      alignItems: 'center',
      fontFamily: 'var(--font-ui)',
      fontSize: 16,
      lineHeight: 1.5,
      letterSpacing: '0.15px',
      cursor: 'pointer'
    }
  }, o))) : null);
}
Object.assign(__ds_scope, { Autocomplete });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/inputs/Autocomplete.jsx", error: String((e && e.message) || e) }); }

// components/inputs/TextFieldMultiline.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const VALUE_TYPE = {
  fontFamily: 'var(--font-ui)',
  fontWeight: 400,
  fontSize: 16,
  lineHeight: '24px',
  letterSpacing: '0.15px'
};
const HEIGHTS = {
  outlined: {
    medium: 56,
    small: 40
  },
  filled: {
    medium: 56,
    small: 40
  },
  standard: {
    medium: 48,
    small: 40
  }
};
const CONTENT_PAD = {
  outlined: {
    medium: '16px 0',
    small: '8px 0'
  },
  filled: {
    medium: '9px 12px 8px',
    small: '6px 12px 5px'
  },
  standard: {
    medium: '12px 0',
    small: '8px 0'
  }
};
function shellStyle(variant, size, state, error) {
  const h = HEIGHTS[variant][size];
  const accent = error ? 'var(--error-main)' : state === 'focused' ? 'var(--primary-main)' : null;
  if (variant === 'outlined') {
    const ring = state === 'disabled' ? 'rgba(0,0,0,0.12)' : accent || (state === 'hovered' ? 'var(--border-input-hover)' : 'var(--border-input)');
    return {
      height: h,
      borderRadius: 'var(--radius-md)',
      padding: '0 12px',
      boxShadow: `inset 0 0 0 ${state === 'focused' ? 2 : 2}px ${ring}`
    };
  }
  if (variant === 'filled') {
    return {
      height: h,
      borderRadius: '12px 12px 0 0',
      background: state === 'disabled' ? 'rgba(0,0,0,0.03)' : state === 'hovered' ? 'rgba(0,0,0,0.09)' : 'rgba(0,0,0,0.06)',
      boxShadow: `inset 0 -${accent ? 2 : 1}px 0 0 ${accent || 'rgba(0,0,0,0.42)'}`
    };
  }
  return {
    height: h,
    boxShadow: `inset 0 -${accent ? 2 : 1}px 0 0 ${accent || 'rgba(0,0,0,0.42)'}`
  };
}

/** [McTextField] <TextField> | Multiline — 3 variants × rows / min-rows / max-rows. */
function TextFieldMultiline({
  variant = 'outlined',
  label,
  value,
  placeholder,
  helperText,
  rows = 4,
  minRows,
  maxRows,
  error = false,
  disabled = false,
  state,
  fullWidth = false,
  onChange,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const [focus, setFocus] = React.useState(false);
  const s = disabled ? 'disabled' : state || (focus ? 'focused' : hover ? 'hovered' : 'enabled');
  const shell = shellStyle(variant, 'medium', s, error);
  delete shell.height;
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: 'flex',
      flexDirection: 'column',
      width: fullWidth ? '100%' : 220,
      position: 'relative',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      ...shell,
      boxSizing: 'border-box',
      padding: variant === 'outlined' ? '16px 12px' : '25px 12px 8px'
    }
  }, /*#__PURE__*/React.createElement("textarea", {
    disabled: disabled,
    value: value,
    placeholder: placeholder,
    rows: rows,
    onChange: e => onChange && onChange(e.target.value),
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      ...VALUE_TYPE,
      display: 'block',
      width: '100%',
      resize: 'vertical',
      border: 'none',
      outline: 'none',
      background: 'transparent',
      padding: 0,
      minHeight: (minRows || rows) * 24,
      maxHeight: maxRows ? maxRows * 24 : undefined,
      color: disabled ? 'var(--text-disabled)' : 'var(--text-primary)'
    }
  })), label ? /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      left: 12,
      top: -6,
      padding: '0 4px',
      background: 'var(--surface-card)',
      fontFamily: 'var(--font-ui)',
      fontSize: 12,
      lineHeight: '12px',
      letterSpacing: '0.15px',
      pointerEvents: 'none',
      color: error ? 'var(--error-main)' : s === 'focused' ? 'var(--primary-main)' : 'var(--text-secondary)'
    }
  }, label) : null, helperText ? /*#__PURE__*/React.createElement(__ds_scope.FormHelperText, {
    error: error,
    disabled: disabled
  }, helperText) : null);
}
Object.assign(__ds_scope, { TextFieldMultiline });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/inputs/TextFieldMultiline.jsx", error: String((e && e.message) || e) }); }

// components/inspira/ActionButtonsOnWhite.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Action Buttons (On White) — the inline text action pattern. 5 kinds × 3 states. */
function ActionButtonsOnWhite({
  kind = 'text chevron',
  state = 'default',
  children = 'Action',
  icon,
  onClick,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const st = state !== 'default' ? state : hover ? 'hover' : 'default';
  const color = st === 'disabled' ? 'var(--components-button-disabled-label, rgba(28,28,28,0.5))' : st === 'hover' ? 'var(--indigo-900)' : 'var(--primary-main)';
  const glyph = {
    'add action': 'M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z',
    'pdf download': 'M19 9h-4V3H9v6H5l7 7 7-7zM5 18v2h14v-2H5z',
    'text icon': null,
    'text only': null,
    'text chevron': 'M8.59 16.59 13.17 12 8.59 7.41 10 6l6 6-6 6-1.41-1.41z'
  }[kind];
  const leading = kind === 'add action' || kind === 'pdf download';
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    onClick: onClick,
    disabled: st === 'disabled',
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 8,
      border: 'none',
      background: 'transparent',
      padding: 0,
      color,
      cursor: st === 'disabled' ? 'default' : 'pointer',
      ...style
    }
  }, rest), leading && glyph ? /*#__PURE__*/React.createElement("svg", {
    width: "18",
    height: "18",
    viewBox: "0 0 24 24",
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement("path", {
    fill: "currentColor",
    d: glyph
  })) : null, kind === 'text icon' && icon ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      width: 18,
      height: 18
    }
  }, icon) : null, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-ui)',
      fontWeight: 600,
      fontSize: 14,
      lineHeight: '20px',
      textDecoration: st === 'hover' ? 'underline' : 'none',
      textUnderlineOffset: 2
    }
  }, children), !leading && kind === 'text chevron' && glyph ? /*#__PURE__*/React.createElement("svg", {
    width: "18",
    height: "18",
    viewBox: "0 0 24 24",
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement("path", {
    fill: "currentColor",
    d: glyph
  })) : null);
}
Object.assign(__ds_scope, { ActionButtonsOnWhite });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/inspira/ActionButtonsOnWhite.jsx", error: String((e && e.message) || e) }); }

// components/inspira/ErrorMessage.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Error Message (H-B) — the alert-red inline error line with its leading glyph. */
function ErrorMessage({
  children = 'Error Message',
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 8,
      color: 'var(--alerts-alert)',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("svg", {
    width: "18",
    height: "18",
    viewBox: "0 0 24 24",
    "aria-hidden": "true",
    style: {
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement("path", {
    fill: "currentColor",
    d: "M12 2a10 10 0 100 20 10 10 0 000-20zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-ui)',
      fontWeight: 500,
      fontSize: 14,
      lineHeight: '20px'
    }
  }, children));
}
Object.assign(__ds_scope, { ErrorMessage });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/inspira/ErrorMessage.jsx", error: String((e && e.message) || e) }); }

// components/inspira/FilterChips.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Filter Chips (H-B) — 3 states × selected. Radius 16, brand-font label. */
function FilterChips({
  label = 'Option',
  selected = false,
  state = 'enabled',
  onClick,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const st = state !== 'enabled' ? state : hover ? 'hover' : 'enabled';
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 8,
      boxSizing: 'border-box',
      border: 'none',
      borderRadius: 16,
      padding: selected ? '6px 16px 6px 12px' : '6px 16px',
      background: selected ? 'var(--primary-200, var(--indigo-200))' : st === 'hover' ? 'var(--primary-hover)' : 'transparent',
      boxShadow: selected ? 'inset 0 0 0 1.5px var(--primary-500, var(--indigo-700)), var(--shadow-chip-selected)' : st === 'focused' ? 'inset 0 0 0 2px var(--primary-main)' : 'inset 0 0 0 1px var(--grey-400)',
      cursor: 'pointer',
      transition: 'background-color var(--transition-fast)',
      ...style
    },
    "aria-pressed": selected
  }, rest), selected ? /*#__PURE__*/React.createElement("svg", {
    width: "20",
    height: "20",
    viewBox: "0 0 24 24",
    "aria-hidden": "true",
    style: {
      color: 'var(--primary-600, var(--indigo-900))'
    }
  }, /*#__PURE__*/React.createElement("path", {
    fill: "currentColor",
    d: "M9 16.17 4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"
  })) : null, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-brand)',
      fontWeight: 500,
      fontSize: 14,
      lineHeight: '20px',
      textAlign: 'center',
      whiteSpace: 'nowrap',
      color: 'var(--primary-600, var(--indigo-900))'
    }
  }, label));
}
Object.assign(__ds_scope, { FilterChips });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/inspira/FilterChips.jsx", error: String((e && e.message) || e) }); }

// components/inspira/HideTextOverflow.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Hide Text Overflow (H-B) — single-line clamp with an ellipsis, used inside InputBox and table cells. */
function HideTextOverflow({
  children,
  placeholder,
  lines = 1,
  style,
  ...rest
}) {
  const clamp = lines > 1 ? {
    display: '-webkit-box',
    WebkitBoxOrient: 'vertical',
    WebkitLineClamp: lines,
    overflow: 'hidden'
  } : {
    whiteSpace: 'nowrap',
    overflow: 'hidden',
    textOverflow: 'ellipsis'
  };
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: 'block',
      minWidth: 0,
      fontFamily: 'var(--font-ui)',
      fontWeight: 400,
      fontSize: 14,
      lineHeight: '18px',
      color: children ? 'var(--grey-700)' : 'var(--grey-500)',
      ...clamp,
      ...style
    }
  }, rest), children ?? placeholder);
}
Object.assign(__ds_scope, { HideTextOverflow });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/inspira/HideTextOverflow.jsx", error: String((e && e.message) || e) }); }

// components/inspira/IconButtons.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const SIZES = {
  lg: 48,
  md: 40,
  sm: 32
};

/** Icon Buttons (H-B) — 6 variants × 4 states × 3 sizes. Circular. */
function IconButtons({
  variant = 'general',
  size = 'md',
  state,
  disabled = false,
  children,
  style,
  ...rest
}) {
  const px = SIZES[size] || 40;
  const [hover, setHover] = React.useState(false);
  const st = disabled ? 'disabled' : state || (hover ? 'hover' : 'enabled');
  const SKIN = {
    general: {
      bg: st === 'hover' ? 'var(--primary-hover)' : 'transparent',
      fg: 'var(--primary-main)',
      ring: 'none',
      shadow: 'none'
    },
    outlined: {
      bg: st === 'hover' ? 'var(--primary-hover)' : 'transparent',
      fg: 'var(--primary-main)',
      ring: 'inset 0 0 0 1px var(--primary-main)',
      shadow: 'none'
    },
    success: {
      bg: 'var(--teal-400)',
      fg: '#FFFFFF',
      ring: 'none',
      shadow: 'none'
    },
    elevated: {
      bg: '#FFFFFF',
      fg: 'var(--primary-main)',
      ring: 'none',
      shadow: 'var(--shadow-2)'
    },
    contained: {
      bg: 'var(--primary-main)',
      fg: '#FFFFFF',
      ring: 'none',
      shadow: 'none'
    },
    'general dark mode': {
      bg: st === 'hover' ? 'rgba(255,255,255,0.12)' : 'transparent',
      fg: '#FFFFFF',
      ring: 'none',
      shadow: 'none'
    }
  };
  const k = SKIN[variant] || SKIN.general;
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    disabled: disabled,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      width: px,
      height: px,
      borderRadius: 'var(--radius-pill)',
      border: 'none',
      padding: 0,
      background: st === 'disabled' ? 'rgba(28,28,28,0.1)' : k.bg,
      color: st === 'disabled' ? 'rgba(28,28,28,0.5)' : k.fg,
      boxShadow: st === 'focus' ? 'inset 0 0 0 2px var(--primary-main)' : `${k.ring === 'none' ? '' : k.ring + ', '}${k.shadow === 'none' ? '0 0 transparent' : k.shadow}`,
      cursor: disabled ? 'default' : 'pointer',
      transition: 'background-color var(--transition-fast)',
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { IconButtons });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/inspira/IconButtons.jsx", error: String((e && e.message) || e) }); }

// components/inspira/InputBox.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** _input box (H-B) — 320×42, radius 8, 1px ring, 11px 12px 13px padding. 6 states. */
function InputBox({
  state = 'default',
  value,
  placeholder = 'Placeholder',
  showEyeToggle = false,
  showLockToggle = false,
  onChange,
  fullWidth = false,
  style,
  ...rest
}) {
  const ring = state === 'error' ? 'var(--alerts-alert)' : state === 'focus' ? 'var(--primary-main)' : state === 'disabled' ? 'rgba(28,28,28,0.1)' : state === 'hover' ? 'var(--grey-700)' : 'var(--grey-600)';
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      boxSizing: 'border-box',
      width: fullWidth ? '100%' : 320,
      height: 42,
      borderRadius: 'var(--radius-sm)',
      background: state === 'disabled' ? 'var(--grey-50)' : '#FFFFFF',
      boxShadow: `inset 0 0 0 1px ${ring}`,
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      padding: '11px 12px 13px',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("input", {
    value: value,
    placeholder: placeholder,
    disabled: state === 'disabled',
    onChange: e => onChange && onChange(e.target.value),
    style: {
      flex: 1,
      minWidth: 0,
      border: 'none',
      outline: 'none',
      background: 'transparent',
      padding: 0,
      fontFamily: 'var(--font-ui)',
      fontWeight: 400,
      fontSize: 14,
      lineHeight: '18px',
      color: state === 'disabled' ? 'var(--text-disabled)' : 'var(--grey-700)'
    }
  }), showLockToggle ? /*#__PURE__*/React.createElement("svg", {
    width: "18",
    height: "18",
    viewBox: "0 0 24 24",
    "aria-hidden": "true",
    style: {
      color: 'var(--grey-500)',
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement("path", {
    fill: "currentColor",
    d: "M18 8h-1V6a5 5 0 00-10 0v2H6a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V10a2 2 0 00-2-2zm-6 9a2 2 0 110-4 2 2 0 010 4zm3-9H9V6a3 3 0 016 0v2z"
  })) : null, showEyeToggle ? /*#__PURE__*/React.createElement("svg", {
    width: "18",
    height: "18",
    viewBox: "0 0 24 24",
    "aria-hidden": "true",
    style: {
      color: 'var(--grey-500)',
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement("path", {
    fill: "currentColor",
    d: "M12 4.5C7 4.5 2.73 7.61 1 12c1.73 4.39 6 7.5 11 7.5s9.27-3.11 11-7.5c-1.73-4.39-6-7.5-11-7.5zm0 12a4.5 4.5 0 110-9 4.5 4.5 0 010 9zm0-7.2a2.7 2.7 0 100 5.4 2.7 2.7 0 000-5.4z"
  })) : null);
}
Object.assign(__ds_scope, { InputBox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/inspira/InputBox.jsx", error: String((e && e.message) || e) }); }

// components/inspira/InspiraButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const SIZES = {
  lg: {
    h: 48,
    font: 16,
    lh: '24px'
  },
  md: {
    h: 40,
    font: 14,
    lh: '20px'
  },
  sm: {
    h: 32,
    font: 14,
    lh: '20px'
  }
};

/** Button (H-B) — the Inspira product button: 12px radius, Inter SemiBold, 24px side padding. 45 variants. */
function InspiraButton({
  hierarchy = 'primary',
  size = 'md',
  state,
  disabled = false,
  leftIcon,
  rightIcon,
  loading = false,
  children,
  style,
  ...rest
}) {
  const s = SIZES[size] || SIZES.md;
  const [hover, setHover] = React.useState(false);
  const [press, setPress] = React.useState(false);
  const st = disabled ? 'disabled' : loading ? 'loading' : state || (press ? 'pressed' : hover ? 'hover' : 'enabled');
  let skin;
  if (hierarchy === 'primary') {
    skin = st === 'disabled' ? {
      background: 'var(--components-button-primary-fill-disabled, rgba(28,28,28,0.1))',
      color: 'var(--components-button-disabled-label, rgba(28,28,28,0.5))',
      boxShadow: 'none'
    } : {
      background: 'var(--primary-main)',
      color: '#FFFFFF',
      boxShadow: 'inset 0 0 0 1px var(--primary-main)'
    };
  } else if (hierarchy === 'secondary') {
    skin = st === 'disabled' ? {
      background: '#FFFFFF',
      color: 'var(--components-button-disabled-label, rgba(28,28,28,0.5))',
      boxShadow: 'inset 0 0 0 1px rgba(28,28,28,0.1)'
    } : {
      background: '#FFFFFF',
      color: 'var(--primary-main)',
      boxShadow: 'inset 0 0 0 1px var(--primary-main)'
    };
  } else {
    skin = st === 'disabled' ? {
      background: 'transparent',
      color: 'var(--components-button-disabled-label, rgba(28,28,28,0.5))',
      boxShadow: 'none'
    } : {
      background: 'transparent',
      color: 'var(--primary-main)',
      boxShadow: 'none'
    };
  }
  const overlay = hierarchy === 'primary' ? st === 'hover' ? 'rgba(255,255,255,0.12)' : st === 'pressed' ? 'rgba(255,255,255,0.2)' : 'transparent' : st === 'hover' ? 'var(--primary-hover)' : st === 'pressed' ? 'var(--primary-pressed)' : 'transparent';
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    disabled: disabled || loading,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => {
      setHover(false);
      setPress(false);
    },
    onMouseDown: () => setPress(true),
    onMouseUp: () => setPress(false),
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      boxSizing: 'border-box',
      height: s.h,
      borderRadius: 'var(--radius-md)',
      border: 'none',
      overflow: 'hidden',
      padding: 0,
      cursor: disabled ? 'default' : 'pointer',
      ...skin,
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 4,
      padding: '0 24px',
      height: '100%',
      background: overlay,
      transition: 'background-color var(--transition-fast)'
    }
  }, leftIcon ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      width: 20,
      height: 20
    }
  }, leftIcon) : null, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-ui)',
      fontWeight: 600,
      fontSize: s.font,
      lineHeight: s.lh,
      textAlign: 'center',
      whiteSpace: 'nowrap'
    }
  }, children), rightIcon ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      width: 20,
      height: 20
    }
  }, rightIcon) : null));
}
Object.assign(__ds_scope, { InspiraButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/inspira/InspiraButton.jsx", error: String((e && e.message) || e) }); }

// components/inspira/LabelAndTooltipTrigger.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Label and Tooltip Trigger (H-B) — field label plus the (?) tooltip trigger and optional filter affordance. */
function LabelAndTooltipTrigger({
  label = 'Label',
  variant = 'default',
  showTooltip = true,
  showFilter = false,
  onTooltip,
  style,
  ...rest
}) {
  const h1 = variant === 'h1';
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6,
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-ui)',
      fontWeight: h1 ? 700 : 500,
      fontSize: h1 ? 24 : 14,
      lineHeight: h1 ? 1.334 : '20px',
      color: 'var(--grey-700)'
    }
  }, label), showTooltip ? /*#__PURE__*/React.createElement("button", {
    type: "button",
    "aria-label": 'About ' + label,
    onClick: onTooltip,
    style: {
      display: 'flex',
      border: 'none',
      background: 'transparent',
      padding: 0,
      cursor: 'pointer',
      color: 'var(--primary-main)'
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: "16",
    height: "16",
    viewBox: "0 0 24 24",
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement("path", {
    fill: "currentColor",
    d: "M12 2a10 10 0 100 20 10 10 0 000-20zm1 17h-2v-2h2v2zm2.07-7.75-.9.92C13.45 12.9 13 13.5 13 15h-2v-.5c0-1.1.45-2.1 1.17-2.83l1.24-1.26A1.96 1.96 0 0014 9a2 2 0 10-4 0H8a4 4 0 118 0c0 .88-.36 1.68-.93 2.25z"
  }))) : null, showFilter ? /*#__PURE__*/React.createElement("svg", {
    width: "16",
    height: "16",
    viewBox: "0 0 24 24",
    "aria-hidden": "true",
    style: {
      color: 'var(--grey-500)'
    }
  }, /*#__PURE__*/React.createElement("path", {
    fill: "currentColor",
    d: "M10 18h4v-2h-4v2zM3 6v2h18V6H3zm3 7h12v-2H6v2z"
  })) : null);
}
Object.assign(__ds_scope, { LabelAndTooltipTrigger });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/inspira/LabelAndTooltipTrigger.jsx", error: String((e && e.message) || e) }); }

// components/inspira/PrimaryInputVert.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Primary input (Vert) (H-B) — the vertical form stack: error, label + tooltip, input box. 5 states. */
function PrimaryInputVert({
  label = 'Label',
  state = 'default',
  value,
  placeholder,
  errorText = 'Error Message',
  onChange,
  onTooltip,
  fullWidth = false,
  style,
  ...rest
}) {
  const masked = state === 'masked';
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 4,
      alignItems: 'flex-start',
      width: fullWidth ? '100%' : undefined,
      ...style
    }
  }, rest), state === 'error' ? /*#__PURE__*/React.createElement(__ds_scope.ErrorMessage, null, errorText) : null, /*#__PURE__*/React.createElement(__ds_scope.LabelAndTooltipTrigger, {
    label: label,
    onTooltip: onTooltip
  }), /*#__PURE__*/React.createElement(__ds_scope.InputBox, {
    state: state === 'masked' || state === 'unmasked' ? 'default' : state,
    value: value,
    placeholder: placeholder,
    onChange: onChange,
    showEyeToggle: masked || state === 'unmasked',
    fullWidth: fullWidth
  }));
}
Object.assign(__ds_scope, { PrimaryInputVert });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/inspira/PrimaryInputVert.jsx", error: String((e && e.message) || e) }); }

// components/inspira/StandaloneLink.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Standalone link (H-B) — 28 variants (dark mode × 7 states × 2 sizes). Underlined, SemiBold. */
function StandaloneLink({
  children = 'Standalone Enabled',
  size = 'default',
  darkMode = false,
  state = 'enabled',
  externalLinkIcon = false,
  href = '#',
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const st = state !== 'enabled' ? state : hover ? 'hover' : 'enabled';
  const color = st === 'disabled' ? 'var(--components-button-disabled-label, rgba(28,28,28,0.5))' : darkMode ? st.includes('visited') ? 'var(--link-visited-dark)' : 'var(--link-enabled-dark)' : st.includes('visited') ? 'var(--link-visited)' : 'var(--link-enabled)';
  const font = size === 'lg' ? {
    fontSize: 16,
    lineHeight: '24px'
  } : {
    fontSize: 14,
    lineHeight: '20px'
  };
  return /*#__PURE__*/React.createElement("a", _extends({
    href: st === 'disabled' ? undefined : href,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: 'inline-flex',
      flexDirection: 'column',
      alignItems: 'flex-start',
      padding: '3px 0 2px',
      textDecoration: 'none',
      color,
      cursor: st === 'disabled' ? 'default' : 'pointer',
      outline: st.startsWith('focus') ? '2px solid var(--primary-main)' : 'none',
      outlineOffset: 2,
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 6
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-ui)',
      fontWeight: 600,
      ...font,
      whiteSpace: 'nowrap'
    }
  }, children), externalLinkIcon ? /*#__PURE__*/React.createElement("svg", {
    width: "16",
    height: "16",
    viewBox: "0 0 13.334 13.334",
    "aria-hidden": "true",
    style: {
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement("path", {
    fill: "currentColor",
    fillRule: "nonzero",
    d: "M 6 1.334 L 6 2.667 L 2 2.667 C 1.633 2.667 1.334 2.967 1.334 3.334 L 1.334 11.334 C 1.334 11.7 1.634 12 2 12 L 10 12 C 10.367 12 10.667 11.701 10.667 11.334 L 10.667 7.334 L 12 7.334 L 12 11.334 C 12 12.434 11.1 13.334 10 13.334 L 2 13.334 C 0.9 13.334 0 12.434 0 11.334 L 0 3.334 C 0 2.234 0.9 1.334 2 1.334 L 6 1.334 Z M 13.334 0 L 13.334 6 L 12 6 L 12 2.273 L 5.141 9.141 L 4.193 8.193 L 11.061 1.334 L 7.334 1.334 L 7.334 0 L 13.334 0 Z"
  })) : null), /*#__PURE__*/React.createElement("span", {
    style: {
      height: 1,
      alignSelf: 'stretch',
      background: st === 'active' ? 'transparent' : 'currentColor'
    }
  }));
}
Object.assign(__ds_scope, { StandaloneLink });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/inspira/StandaloneLink.jsx", error: String((e && e.message) || e) }); }

// components/inspira/TextAction.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Text Action (H-B) — 5 states × 2 sizes. Underlined SemiBold action without a container. */
function TextAction({
  children = 'Standalone Enabled',
  size = 'default',
  state = 'enabled',
  icon = false,
  onClick,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const st = state !== 'enabled' ? state : hover ? 'hover' : 'enabled';
  const color = st === 'disabled' ? 'var(--components-button-disabled-label, rgba(28,28,28,0.5))' : st === 'hover' || st === 'active' ? 'var(--indigo-900)' : 'var(--primary-main)';
  const font = size === 'lg' ? {
    fontSize: 16,
    lineHeight: '24px'
  } : {
    fontSize: 14,
    lineHeight: '20px'
  };
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    onClick: onClick,
    disabled: st === 'disabled',
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: 'inline-flex',
      flexDirection: 'column',
      alignItems: 'flex-start',
      border: 'none',
      background: 'transparent',
      padding: '3px 0 2px',
      color,
      cursor: st === 'disabled' ? 'default' : 'pointer',
      outline: st === 'focus' ? '2px solid var(--primary-main)' : 'none',
      outlineOffset: 2,
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 6
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-ui)',
      fontWeight: 600,
      ...font,
      whiteSpace: 'nowrap'
    }
  }, children), icon ? /*#__PURE__*/React.createElement("svg", {
    width: "18",
    height: "18",
    viewBox: "0 0 24 24",
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement("path", {
    fill: "currentColor",
    d: "M8.59 16.59 13.17 12 8.59 7.41 10 6l6 6-6 6-1.41-1.41z"
  })) : null), /*#__PURE__*/React.createElement("span", {
    style: {
      height: 1,
      alignSelf: 'stretch',
      background: 'currentColor'
    }
  }));
}
Object.assign(__ds_scope, { TextAction });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/inspira/TextAction.jsx", error: String((e && e.message) || e) }); }

// components/inspira/VerticalTrigger.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Vertical Trigger (H-B) — the small vertical caret that reveals a tooltip or panel. */
function VerticalTrigger({
  visible = true,
  onClick,
  style,
  ...rest
}) {
  if (!visible) return null;
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    "aria-label": "Show details",
    onClick: onClick,
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      width: 24,
      height: 24,
      border: 'none',
      background: 'transparent',
      padding: 0,
      cursor: 'pointer',
      color: 'var(--primary-main)',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("svg", {
    width: "16",
    height: "16",
    viewBox: "0 0 24 24",
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement("path", {
    fill: "currentColor",
    d: "M7 14l5-5 5 5z"
  })));
}
Object.assign(__ds_scope, { VerticalTrigger });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/inspira/VerticalTrigger.jsx", error: String((e && e.message) || e) }); }

// components/library/Hidden.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** _hidden — the library's marker for intentionally hidden layers. Renders nothing visible. */
function Hidden({
  children,
  note,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("span", _extends({
    hidden: true,
    "data-hidden-note": note
  }, rest), children);
}
Object.assign(__ds_scope, { Hidden });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/library/Hidden.jsx", error: String((e && e.message) || e) }); }

// components/library/LibraryComponentHeading.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** _Library / Component Heading — the 600px-wide spec panel beside every component sheet in the Figma file. */
function LibraryComponentHeading({
  category = 'Category',
  name = 'Component',
  title,
  description,
  overrides,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      width: 600,
      boxSizing: 'border-box',
      padding: 64,
      background: 'rgba(0,0,0,0.02)',
      display: 'flex',
      flexDirection: 'column',
      gap: 24,
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      gap: 8,
      fontFamily: 'var(--font-ui)',
      fontWeight: 400,
      fontSize: 14,
      lineHeight: 1.43,
      letterSpacing: '0.17px',
      color: 'rgba(0,0,0,0.56)'
    }
  }, /*#__PURE__*/React.createElement("span", null, category), /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true"
  }, "/"), /*#__PURE__*/React.createElement("span", null, name)), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 400,
      fontSize: 34,
      lineHeight: 1.235,
      letterSpacing: '0.25px',
      color: 'var(--text-primary)'
    }
  }, title || name), description ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-ui)',
      fontWeight: 400,
      fontSize: 16,
      lineHeight: 1.5,
      letterSpacing: '0.15px',
      color: 'var(--text-secondary)',
      textWrap: 'pretty'
    }
  }, description) : null, overrides ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-ui)',
      fontWeight: 400,
      fontSize: 12,
      lineHeight: 1.66,
      letterSpacing: '0.4px',
      color: 'var(--text-disabled)',
      whiteSpace: 'pre-line'
    }
  }, overrides) : null);
}
Object.assign(__ds_scope, { LibraryComponentHeading });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/library/LibraryComponentHeading.jsx", error: String((e && e.message) || e) }); }

// components/library/LibraryComponentInformation.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** _Library / Component Information — the 420px heading block above each specimen grid. */
function LibraryComponentInformation({
  heading,
  note,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      width: 420,
      display: 'flex',
      flexDirection: 'column',
      gap: 24,
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-ui)',
      fontWeight: 500,
      fontSize: 20,
      lineHeight: 1.6,
      letterSpacing: '0.15px',
      color: 'var(--text-primary)'
    }
  }, heading), note ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-ui)',
      fontSize: 14,
      lineHeight: 1.43,
      letterSpacing: '0.17px',
      color: 'var(--text-secondary)'
    }
  }, note) : null);
}
Object.assign(__ds_scope, { LibraryComponentInformation });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/library/LibraryComponentInformation.jsx", error: String((e && e.message) || e) }); }

// components/library/LibraryComponentProperties.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const KIND = {
  variant: 'var(--primary-main)',
  boolean: 'var(--success-main)',
  instance: 'var(--secondary-dark)',
  text: 'var(--info-main)'
};

/** _Library / Component Properties — the property-type chip used in the library's annotations. 4 types. */
function LibraryComponentProperties({
  type = 'variant',
  name,
  value,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6,
      padding: '2px 8px',
      borderRadius: 'var(--radius-pill)',
      boxShadow: `inset 0 0 0 1px ${KIND[type] || KIND.variant}`,
      color: KIND[type] || KIND.variant,
      fontFamily: 'var(--font-ui)',
      fontWeight: 500,
      fontSize: 12,
      lineHeight: '18px',
      letterSpacing: '0.16px',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", null, name), value != null ? /*#__PURE__*/React.createElement("span", {
    style: {
      opacity: 0.7
    }
  }, value) : null);
}
Object.assign(__ds_scope, { LibraryComponentProperties });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/library/LibraryComponentProperties.jsx", error: String((e && e.message) || e) }); }

// components/library/LibraryInstanceSlot.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** _Library / Instance Slot — the dashed purple placeholder marking a swappable instance. */
function LibraryInstanceSlot({
  label = 'Instance',
  width,
  height,
  children,
  style,
  ...rest
}) {
  if (children) return /*#__PURE__*/React.createElement(React.Fragment, null, children);
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      boxSizing: 'border-box',
      width: width || 'auto',
      height: height || 'auto',
      minWidth: 24,
      minHeight: 24,
      padding: '4px 8px',
      borderRadius: 5,
      outline: '1px dashed rgb(151,71,255)',
      outlineOffset: -1,
      color: 'rgb(151,71,255)',
      fontFamily: 'var(--font-ui)',
      fontSize: 12,
      lineHeight: '18px',
      letterSpacing: '0.16px',
      ...style
    }
  }, rest), label);
}
Object.assign(__ds_scope, { LibraryInstanceSlot });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/library/LibraryInstanceSlot.jsx", error: String((e && e.message) || e) }); }

// components/library/LibraryPlaceholderImage.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** _Library / Placeholder Image — the neutral image plate the library uses where a real bitmap will go. */
function LibraryPlaceholderImage({
  width = '100%',
  height = 160,
  label = 'Image',
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    role: "img",
    "aria-label": label,
    style: {
      width,
      height,
      background: 'var(--grey-100)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: 'var(--grey-500)',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("svg", {
    width: "40",
    height: "40",
    viewBox: "0 0 24 24",
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement("path", {
    fill: "currentColor",
    d: "M21 19V5a2 2 0 00-2-2H5a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2zM8.5 13.5l2.5 3 3.5-4.5 4.5 6H5l3.5-4.5z"
  })));
}
Object.assign(__ds_scope, { LibraryPlaceholderImage });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/library/LibraryPlaceholderImage.jsx", error: String((e && e.message) || e) }); }

// components/library/UsabilityIconContainer.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const SIZES = {
  xs: 16,
  s: 20,
  m: 24,
  l: 32,
  xl: 40
};

/** usability icon container / [McIcon] <Usability Icon> — the padded icon frame. 5 sizes × padded. */
function UsabilityIconContainer({
  size = 'm',
  padded = false,
  color = 'currentColor',
  children,
  style,
  ...rest
}) {
  const px = SIZES[size] ?? (typeof size === 'number' ? size : 24);
  const box = padded ? px + 8 : px;
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      width: box,
      height: box,
      flexShrink: 0,
      color,
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { UsabilityIconContainer });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/library/UsabilityIconContainer.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Menu.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** [MCMenu] <Menu> — Paper elevation 8, 8px vertical padding. Auto width × max height. */
function Menu({
  autoWidth = true,
  maxHeight,
  open = true,
  children,
  style,
  ...rest
}) {
  if (!open) return null;
  return /*#__PURE__*/React.createElement("div", _extends({
    role: "menu",
    style: {
      background: 'var(--surface-card)',
      borderRadius: 'var(--radius-md)',
      boxShadow: 'var(--shadow-8)',
      padding: '8px 0',
      minWidth: autoWidth ? 112 : 224,
      maxHeight: maxHeight || 288,
      overflowY: 'auto',
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Menu });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Menu.jsx", error: String((e && e.message) || e) }); }

// components/navigation/MenuItem.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** [MCMenuItem] <MenuItem> — 2 densities × disable-gutters × small screen × 4 states. */
function MenuItem({
  dense = false,
  disableGutters = false,
  selected = false,
  disabled = false,
  state,
  icon,
  trailing,
  children,
  onClick,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const s = disabled ? 'disabled' : state || (selected ? 'selected' : hover ? 'hovered' : 'enabled');
  return /*#__PURE__*/React.createElement("div", _extends({
    role: "menuitem",
    tabIndex: disabled ? -1 : 0,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    onClick: disabled ? undefined : onClick,
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12,
      boxSizing: 'border-box',
      minHeight: dense ? 32 : 36,
      padding: disableGutters ? '6px 0' : '6px 16px',
      background: s === 'selected' ? 'var(--primary-state-selected)' : s === 'hovered' ? 'var(--action-hover)' : 'transparent',
      color: disabled ? 'var(--text-disabled)' : 'var(--text-primary)',
      cursor: disabled ? 'default' : 'pointer',
      fontFamily: 'var(--font-ui)',
      fontWeight: 400,
      fontSize: dense ? 14 : 16,
      lineHeight: dense ? 1.43 : 1.5,
      letterSpacing: dense ? '0.17px' : '0.15px',
      ...style
    }
  }, rest), icon ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      color: 'var(--action-active)'
    }
  }, icon) : null, /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      minWidth: 0,
      overflow: 'hidden',
      textOverflow: 'ellipsis',
      whiteSpace: 'nowrap'
    }
  }, children), trailing ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      color: 'var(--text-secondary)'
    }
  }, trailing) : null);
}
Object.assign(__ds_scope, { MenuItem });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/MenuItem.jsx", error: String((e && e.message) || e) }); }

// components/data-grid/GridToolbarMenu.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const DENSITIES = ['Compact', 'Standard', 'Comfortable'];
const EXPORTS = ['Download as CSV', 'Download as Excel', 'Print'];

/**
 * The four grid-toolbar menus the kit defines as standalone symbols:
 * Columns Menu, Density Menu, Export Menu, Filters Menu.
 */
function GridToolbarMenu({
  kind = 'columns',
  columns = [],
  visibleColumns = [],
  density = 'Standard',
  filters = [],
  onChange,
  style,
  ...rest
}) {
  if (kind === 'density') {
    return /*#__PURE__*/React.createElement(__ds_scope.Menu, _extends({
      style: style
    }, rest), DENSITIES.map(d => /*#__PURE__*/React.createElement(__ds_scope.MenuItem, {
      key: d,
      dense: true,
      selected: d === density,
      onClick: () => onChange && onChange(d),
      icon: /*#__PURE__*/React.createElement("span", {
        style: {
          width: 20,
          display: 'flex',
          color: 'var(--primary-main)'
        }
      }, d === density ? /*#__PURE__*/React.createElement("svg", {
        width: "20",
        height: "20",
        viewBox: "0 0 24 24",
        "aria-hidden": "true"
      }, /*#__PURE__*/React.createElement("path", {
        fill: "currentColor",
        d: "M9 16.17 4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"
      })) : null)
    }, d)));
  }
  if (kind === 'export') {
    return /*#__PURE__*/React.createElement(__ds_scope.Menu, _extends({
      style: style
    }, rest), EXPORTS.map(e => /*#__PURE__*/React.createElement(__ds_scope.MenuItem, {
      key: e,
      dense: true,
      onClick: () => onChange && onChange(e)
    }, e)));
  }
  if (kind === 'filters') {
    return /*#__PURE__*/React.createElement(__ds_scope.Menu, _extends({
      autoWidth: false,
      style: style
    }, rest), filters.length ? filters.map((fl, i) => /*#__PURE__*/React.createElement(__ds_scope.MenuItem, {
      key: i,
      dense: true,
      trailing: fl.value
    }, fl.label)) : /*#__PURE__*/React.createElement(__ds_scope.MenuItem, {
      dense: true,
      disabled: true
    }, "No filters applied"));
  }
  return /*#__PURE__*/React.createElement(__ds_scope.Menu, _extends({
    autoWidth: false,
    style: style
  }, rest), columns.map(c => /*#__PURE__*/React.createElement(__ds_scope.MenuItem, {
    key: c,
    dense: true,
    disableGutters: false,
    icon: /*#__PURE__*/React.createElement(__ds_scope.Switch, {
      size: "small",
      checked: visibleColumns.includes(c),
      onChange: () => onChange && onChange(c)
    })
  }, c)));
}
Object.assign(__ds_scope, { GridToolbarMenu });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data-grid/GridToolbarMenu.jsx", error: String((e && e.message) || e) }); }

// components/navigation/MenuList.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** [MCMenuList] <MenuList> — 12 variants (auto width × dense × small screen × disable gutters). */
function MenuList({
  autoWidth = true,
  dense = false,
  smallScreen = false,
  disableGutters = false,
  children,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    role: "menu",
    style: {
      display: 'flex',
      flexDirection: 'column',
      minWidth: autoWidth ? 112 : smallScreen ? '100%' : 224,
      ...style
    }
  }, rest), React.Children.map(children, c => React.isValidElement(c) ? React.cloneElement(c, {
    dense: c.props.dense ?? dense,
    disableGutters: c.props.disableGutters ?? disableGutters
  }) : c));
}
Object.assign(__ds_scope, { MenuList });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/MenuList.jsx", error: String((e && e.message) || e) }); }

// components/surfaces/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** <Card> — 4 variants (small screen × blank). Paper elevation 1, radius 12. */
function Card({
  smallScreen = false,
  blank = false,
  children,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      background: 'var(--surface-card)',
      borderRadius: 'var(--radius-md)',
      boxShadow: 'var(--shadow-1)',
      overflow: 'hidden',
      display: 'flex',
      flexDirection: 'column',
      width: smallScreen ? '100%' : undefined,
      maxWidth: smallScreen ? 360 : undefined,
      minHeight: blank ? 160 : undefined,
      ...style
    }
  }, rest), blank ? null : children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/surfaces/Card.jsx", error: String((e && e.message) || e) }); }

// components/surfaces/CardActions.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** [MCCardActions] <CardActions> — 8px padding, 8px gap. */
function CardActions({
  align = 'start',
  children,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: 'flex',
      gap: 8,
      padding: 8,
      alignItems: 'center',
      justifyContent: align === 'end' ? 'flex-end' : align === 'between' ? 'space-between' : 'flex-start',
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { CardActions });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/surfaces/CardActions.jsx", error: String((e && e.message) || e) }); }

// components/surfaces/CardContent.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** [MCCardContent] <CardContent> — 16px padding, 24px on the last child's bottom. */
function CardContent({
  children,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      padding: '16px 16px 24px',
      display: 'flex',
      flexDirection: 'column',
      gap: 8,
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { CardContent });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/surfaces/CardContent.jsx", error: String((e && e.message) || e) }); }

// components/surfaces/CardHeader.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** [MCCardHeader] <CardHeader> — avatar × density. */
function CardHeader({
  title,
  subheader,
  avatar,
  action,
  dense = false,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 16,
      padding: dense ? '12px 16px' : '16px',
      ...style
    }
  }, rest), avatar ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      flexShrink: 0
    }
  }, avatar) : null, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      flex: 1,
      minWidth: 0
    }
  }, title ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-ui)',
      fontWeight: 500,
      fontSize: dense ? 16 : 20,
      lineHeight: dense ? 1.5 : 1.6,
      letterSpacing: '0.15px',
      color: 'var(--text-primary)'
    }
  }, title) : null, subheader ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-ui)',
      fontWeight: 400,
      fontSize: 14,
      lineHeight: 1.43,
      letterSpacing: '0.17px',
      color: 'var(--text-secondary)'
    }
  }, subheader) : null), action ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      flexShrink: 0
    }
  }, action) : null);
}
Object.assign(__ds_scope, { CardHeader });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/surfaces/CardHeader.jsx", error: String((e && e.message) || e) }); }

// components/surfaces/CardMedia.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** [MCCardMedia] <CardMedia> — 16:9 or 4:3. Pass a real bitmap; never a drawn placeholder. */
function CardMedia({
  ratio = '16:9',
  src,
  alt = '',
  children,
  style,
  ...rest
}) {
  const pct = ratio === '4:3' ? 75 : 56.25;
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      position: 'relative',
      width: '100%',
      paddingTop: pct + '%',
      background: 'var(--grey-100)',
      overflow: 'hidden',
      ...style
    }
  }, rest), src ? /*#__PURE__*/React.createElement("img", {
    src: src,
    alt: alt,
    style: {
      position: 'absolute',
      inset: 0,
      width: '100%',
      height: '100%',
      objectFit: 'cover'
    }
  }) : null, children ? /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0
    }
  }, children) : null);
}
Object.assign(__ds_scope, { CardMedia });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/surfaces/CardMedia.jsx", error: String((e && e.message) || e) }); }

// components/surfaces/CardElements.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** [MCCard Elements] Card Elements — the assembled specimen showing every card slot in order. */
function CardElements({
  title = 'Title',
  subheader = 'Subheader',
  body = 'Body copy',
  mediaSrc,
  actions,
  avatar,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      background: 'var(--surface-card)',
      borderRadius: 'var(--radius-md)',
      boxShadow: 'var(--shadow-1)',
      overflow: 'hidden',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement(__ds_scope.CardHeader, {
    title: title,
    subheader: subheader,
    avatar: avatar
  }), /*#__PURE__*/React.createElement(__ds_scope.CardMedia, {
    src: mediaSrc
  }), /*#__PURE__*/React.createElement(__ds_scope.CardContent, null, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-ui)',
      fontSize: 14,
      lineHeight: 1.43,
      letterSpacing: '0.17px',
      color: 'var(--text-secondary)'
    }
  }, body)), actions ? /*#__PURE__*/React.createElement(__ds_scope.CardActions, null, actions) : null);
}
Object.assign(__ds_scope, { CardElements });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/surfaces/CardElements.jsx", error: String((e && e.message) || e) }); }

// components/tables/CustomTableToolbar.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** _Custom / Table / Toolbar — 2 sizes. Title, count and trailing actions above a table. */
function CustomTableToolbar({
  title,
  count,
  size = 'medium',
  actions,
  selectedCount = 0,
  style,
  ...rest
}) {
  const dense = size === 'small';
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 16,
      minHeight: dense ? 52 : 64,
      padding: dense ? '8px 16px' : '12px 16px',
      background: selectedCount ? 'var(--primary-state-selected)' : 'var(--surface-card)',
      borderBottom: '1px solid var(--border-divider)',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      alignItems: 'baseline',
      gap: 8,
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-ui)',
      fontWeight: 500,
      fontSize: dense ? 16 : 20,
      lineHeight: 1.6,
      letterSpacing: '0.15px',
      color: 'var(--text-primary)'
    }
  }, selectedCount ? selectedCount + ' selected' : title), !selectedCount && count != null ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-ui)',
      fontSize: 14,
      lineHeight: 1.43,
      letterSpacing: '0.17px',
      color: 'var(--text-secondary)'
    }
  }, count) : null), actions ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8
    }
  }, actions) : null);
}
Object.assign(__ds_scope, { CustomTableToolbar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/tables/CustomTableToolbar.jsx", error: String((e && e.message) || e) }); }

// components/tables/HelpersTableActions.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** .Helpers/Table Actions — the trailing action cluster in a row. 2 variants (inline / overflow). */
function HelpersTableActions({
  variant = 'inline',
  actions = [],
  style,
  ...rest
}) {
  if (variant === 'overflow') {
    return /*#__PURE__*/React.createElement("span", _extends({
      style: {
        display: 'inline-flex',
        justifyContent: 'flex-end',
        ...style
      }
    }, rest), /*#__PURE__*/React.createElement(__ds_scope.IconButton, {
      size: "small",
      "aria-label": "Row actions"
    }, /*#__PURE__*/React.createElement("svg", {
      width: "20",
      height: "20",
      viewBox: "0 0 24 24",
      "aria-hidden": "true"
    }, /*#__PURE__*/React.createElement("path", {
      fill: "currentColor",
      d: "M12 8c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm0 2c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0 6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z"
    }))));
  }
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: 'inline-flex',
      gap: 4,
      justifyContent: 'flex-end',
      ...style
    }
  }, rest), actions.map((a, i) => /*#__PURE__*/React.createElement(React.Fragment, {
    key: i
  }, a)));
}
Object.assign(__ds_scope, { HelpersTableActions });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/tables/HelpersTableActions.jsx", error: String((e && e.message) || e) }); }

// components/tables/HelpersTableCellContent.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** .Helpers/Table cell content — the 8 cell content types the library defines. */
function HelpersTableCellContent({
  type = 'text',
  value,
  secondary,
  style,
  ...rest
}) {
  const base = {
    fontFamily: 'var(--font-ui)',
    fontSize: 14,
    lineHeight: '24px',
    letterSpacing: '0.17px',
    color: 'var(--text-primary)'
  };
  const wrap = c => /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 8,
      ...style
    }
  }, rest), c);
  switch (type) {
    case 'number':
      return wrap(/*#__PURE__*/React.createElement("span", {
        style: {
          ...base,
          fontVariantNumeric: 'tabular-nums'
        }
      }, value));
    case 'currency':
      return wrap(/*#__PURE__*/React.createElement("span", {
        style: {
          ...base,
          fontVariantNumeric: 'tabular-nums'
        }
      }, value));
    case 'date':
      return wrap(/*#__PURE__*/React.createElement("span", {
        style: {
          ...base,
          fontVariantNumeric: 'tabular-nums'
        }
      }, value));
    case 'status':
      return wrap(/*#__PURE__*/React.createElement(__ds_scope.Chip, {
        label: value,
        size: "small"
      }));
    case 'avatar':
      return wrap(/*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(__ds_scope.Avatar, {
        size: "24px",
        initials: secondary
      }), /*#__PURE__*/React.createElement("span", {
        style: base
      }, value)));
    case 'link':
      return wrap(/*#__PURE__*/React.createElement(__ds_scope.Link, {
        href: "#"
      }, value));
    case 'two-line':
      return wrap(/*#__PURE__*/React.createElement("span", {
        style: {
          display: 'flex',
          flexDirection: 'column'
        }
      }, /*#__PURE__*/React.createElement("span", {
        style: base
      }, value), /*#__PURE__*/React.createElement("span", {
        style: {
          ...base,
          fontSize: 12,
          lineHeight: 1.66,
          letterSpacing: '0.4px',
          color: 'var(--text-secondary)'
        }
      }, secondary)));
    default:
      return wrap(/*#__PURE__*/React.createElement("span", {
        style: base
      }, value));
  }
}
Object.assign(__ds_scope, { HelpersTableCellContent });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/tables/HelpersTableCellContent.jsx", error: String((e && e.message) || e) }); }

// components/tables/CustomTableCustomCell.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** _Custom / Table / Custom Cell — 8 types, wrapped in a real <td>. */
function CustomTableCustomCell({
  type = 'text',
  value,
  secondary,
  small = false,
  align,
  style,
  ...rest
}) {
  const numeric = type === 'number' || type === 'currency';
  return /*#__PURE__*/React.createElement("td", _extends({
    style: {
      boxSizing: 'border-box',
      height: small ? 36 : 52,
      padding: small ? '6px 16px' : '16px',
      borderBottom: '1px solid var(--border-divider)',
      textAlign: align || (numeric ? 'right' : 'left'),
      verticalAlign: 'middle',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement(__ds_scope.HelpersTableCellContent, {
    type: type,
    value: value,
    secondary: secondary
  }));
}
Object.assign(__ds_scope, { CustomTableCustomCell });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/tables/CustomTableCustomCell.jsx", error: String((e && e.message) || e) }); }

// components/tables/HelpersTableCells.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** .Helpers/Table Cells — 14 variants (5 states × 4 alignments × head/body). The state study cell. */
function HelpersTableCells({
  state = 'enabled',
  textAlignment = 'left',
  type = 'body',
  children,
  style,
  ...rest
}) {
  const bg = state === 'selected' ? 'var(--primary-state-selected)' : state === 'hovered' ? 'var(--action-hover)' : state === 'focused' ? 'var(--action-focus)' : state === 'disabled' ? 'rgba(0,0,0,0.02)' : 'transparent';
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      boxSizing: 'border-box',
      minHeight: type === 'head' ? 56 : 52,
      padding: 16,
      background: bg,
      borderBottom: '1px solid var(--border-divider)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: textAlignment === 'right' ? 'flex-end' : textAlignment === 'center' ? 'center' : 'flex-start',
      fontFamily: 'var(--font-ui)',
      fontWeight: type === 'head' ? 500 : 400,
      fontSize: 14,
      lineHeight: '24px',
      letterSpacing: '0.17px',
      color: state === 'disabled' ? 'var(--text-disabled)' : 'var(--text-primary)',
      textAlign: textAlignment === 'justify' ? 'justify' : undefined,
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { HelpersTableCells });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/tables/HelpersTableCells.jsx", error: String((e && e.message) || e) }); }

// components/tables/HelpersTableTitle.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const SIZES = {
  large: {
    f: 24,
    lh: 1.334,
    w: 700
  },
  medium: {
    f: 20,
    lh: 1.6,
    w: 500
  },
  small: {
    f: 16,
    lh: 1.5,
    w: 500
  }
};

/** .Helpers/Table Title — 3 title sizes. */
function HelpersTableTitle({
  size = 'medium',
  children,
  caption,
  style,
  ...rest
}) {
  const s = SIZES[size] || SIZES.medium;
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 4,
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: size === 'large' ? 'var(--font-ui)' : 'var(--font-ui)',
      fontWeight: s.w,
      fontSize: s.f,
      lineHeight: s.lh,
      letterSpacing: '0.15px',
      color: 'var(--text-primary)'
    }
  }, children), caption ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-ui)',
      fontSize: 14,
      lineHeight: 1.43,
      letterSpacing: '0.17px',
      color: 'var(--text-secondary)'
    }
  }, caption) : null);
}
Object.assign(__ds_scope, { HelpersTableTitle });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/tables/HelpersTableTitle.jsx", error: String((e && e.message) || e) }); }

// components/tables/Table.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** [MCTable] <Table> — 16 variants (small × checkbox × small screen × rows). */
function Table({
  small = false,
  checkbox = false,
  smallScreen = false,
  children,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      width: '100%',
      overflowX: smallScreen ? 'auto' : 'visible',
      background: 'var(--surface-card)',
      ...style
    }
  }, /*#__PURE__*/React.createElement("table", _extends({
    "data-small": small ? '' : undefined,
    "data-checkbox": checkbox ? '' : undefined,
    style: {
      width: '100%',
      borderCollapse: 'collapse',
      fontFamily: 'var(--font-ui)'
    }
  }, rest), children));
}
Object.assign(__ds_scope, { Table });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/tables/Table.jsx", error: String((e && e.message) || e) }); }

// components/tables/TableCell.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** [McTableCell] <TableCell> — 16px padding, 52px row height (36px when small). */
function TableCell({
  head = false,
  small = false,
  checkbox = false,
  align = 'left',
  style,
  children,
  ...rest
}) {
  const Tag = head ? 'th' : 'td';
  return /*#__PURE__*/React.createElement(Tag, _extends({
    style: {
      boxSizing: 'border-box',
      height: head ? small ? 40 : 56 : small ? 36 : 52,
      padding: checkbox ? '0 0 0 4px' : small ? '6px 16px' : '16px',
      textAlign: align,
      verticalAlign: 'middle',
      borderBottom: '1px solid var(--border-divider)',
      fontFamily: 'var(--font-ui)',
      fontWeight: head ? 500 : 400,
      fontSize: 14,
      lineHeight: '24px',
      letterSpacing: '0.17px',
      color: head ? 'var(--text-primary)' : 'var(--text-primary)',
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { TableCell });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/tables/TableCell.jsx", error: String((e && e.message) || e) }); }

// components/tables/TableCellRow.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** [McTableCellRow] <TableCellRow> — 144 variants (small × checkbox × hover × selected × columns × divider). */
function TableCellRow({
  cells = [],
  small = false,
  checkbox = false,
  selected = false,
  divider = true,
  align = {},
  onClick,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("tr", _extends({
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    onClick: onClick,
    style: {
      background: selected ? 'var(--primary-state-selected)' : hover ? 'var(--action-hover)' : 'transparent',
      cursor: onClick ? 'pointer' : 'default',
      transition: 'background-color var(--transition-fast)',
      ...style
    }
  }, rest), checkbox ? /*#__PURE__*/React.createElement(__ds_scope.TableCell, {
    small: small,
    checkbox: true,
    style: {
      borderBottom: divider ? undefined : 'none'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Checkbox, {
    size: "small",
    checked: selected
  })) : null, cells.map((c, i) => /*#__PURE__*/React.createElement(__ds_scope.TableCell, {
    key: i,
    small: small,
    align: align[i] || (i === cells.length - 1 ? 'right' : 'left'),
    style: {
      borderBottom: divider ? undefined : 'none'
    }
  }, c)));
}
Object.assign(__ds_scope, { TableCellRow });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/tables/TableCellRow.jsx", error: String((e && e.message) || e) }); }

// components/tables/TableColumns.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const WIDTHS = {
  text: 180,
  number: 120,
  currency: 140,
  date: 120,
  status: 140,
  actions: 96,
  checkbox: 56
};

/** 🚧 Table Columns (detachable) — the column-definition helper (7 types). */
function TableColumns({
  columns = [],
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("colgroup", _extends({
    style: style
  }, rest), columns.map((c, i) => /*#__PURE__*/React.createElement("col", {
    key: i,
    style: {
      width: (typeof c === 'string' ? WIDTHS[c] : c.width) || 'auto'
    }
  })));
}
Object.assign(__ds_scope, { TableColumns });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/tables/TableColumns.jsx", error: String((e && e.message) || e) }); }

// components/tables/TableFooter.jsx
try { (() => {
/** [McTableFooter] <TableFooter> — pagination / summary row. */
function TableFooter({
  children,
  colSpan = 99,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("tfoot", rest, /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("td", {
    colSpan: colSpan,
    style: {
      padding: '8px 16px',
      borderTop: '1px solid var(--border-divider)',
      fontFamily: 'var(--font-ui)',
      fontSize: 12,
      lineHeight: 1.66,
      letterSpacing: '0.4px',
      color: 'var(--text-secondary)',
      ...style
    }
  }, children)));
}
Object.assign(__ds_scope, { TableFooter });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/tables/TableFooter.jsx", error: String((e && e.message) || e) }); }

// components/tables/TableHead.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** [McTableHead] <TableHead> — 4 variants (small × checkbox). */
function TableHead({
  small = false,
  checkbox = false,
  children,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("thead", _extends({
    style: {
      background: 'var(--surface-card)',
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { TableHead });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/tables/TableHead.jsx", error: String((e && e.message) || e) }); }

// components/tables/TableHeadRow.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** [McTableHeadRow] <TableHeadRow> — 36 variants (small × checkbox × selected × 3–10 columns). */
function TableHeadRow({
  columns = [],
  small = false,
  checkbox = false,
  selected = false,
  align = {},
  onSort,
  sorted,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("tr", _extends({
    style: {
      background: selected ? 'var(--primary-state-selected)' : 'transparent',
      ...style
    }
  }, rest), checkbox ? /*#__PURE__*/React.createElement(__ds_scope.TableCell, {
    head: true,
    small: small,
    checkbox: true
  }, /*#__PURE__*/React.createElement(__ds_scope.Checkbox, {
    size: "small"
  })) : null, columns.map((c, i) => /*#__PURE__*/React.createElement(__ds_scope.TableCell, {
    key: i,
    head: true,
    small: small,
    align: align[i] || (i === columns.length - 1 ? 'right' : 'left'),
    onClick: onSort ? () => onSort(i) : undefined,
    style: {
      cursor: onSort ? 'pointer' : undefined,
      whiteSpace: 'nowrap'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 4
    }
  }, c, sorted && sorted.index === i ? /*#__PURE__*/React.createElement("svg", {
    width: "20",
    height: "20",
    viewBox: "0 0 24 24",
    "aria-hidden": "true",
    style: {
      color: 'var(--action-active)',
      transform: sorted.direction === 'desc' ? 'rotate(180deg)' : 'none'
    }
  }, /*#__PURE__*/React.createElement("path", {
    fill: "currentColor",
    d: "M4 12l1.41 1.41L11 7.83V20h2V7.83l5.58 5.59L20 12l-8-8-8 8z"
  })) : null))));
}
Object.assign(__ds_scope, { TableHeadRow });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/tables/TableHeadRow.jsx", error: String((e && e.message) || e) }); }

// ui_kits/advisor-console/AccountDetailScreen.jsx
try { (() => {
const {
  Card,
  CardHeader,
  CardContent,
  CardActions,
  Avatar,
  AvatarGroup,
  Typography,
  Button,
  IconButton,
  Icon,
  Table,
  TableHead,
  TableHeadRow,
  TableCellRow,
  TableFooter,
  CustomTableToolbar,
  HelpersTableActions,
  Chip,
  Divider,
  ActionButtonsOnWhite,
  StandaloneLink,
  Alert,
  Rating,
  Switch,
  FormControlLabel,
  List,
  ListItem,
  ListItemSubItem,
  ListSubheader
} = window.InspiraAdvisorMUILibrary_3f4835;
const ACTIVITY = [['Mar 14, 2026', 'Contribution', '2026 tax year', '$1,200.00'], ['Mar 01, 2026', 'Dividend', 'ISBLX', '$412.66'], ['Feb 18, 2026', 'Rebalance', '4 positions', '\u2014'], ['Feb 02, 2026', 'Contribution', '2026 tax year', '$1,200.00']];
const POSITIONS = [['Inspira Broad Market Index', 'ISBLX', '1,204.55', '$118,442.10', '64.3%'], ['Inspira Core Bond', 'ISCBX', '742.10', '$48,120.44', '26.1%'], ['Inspira Short Treasury', 'ISTRX', '210.00', '$17,657.60', '9.6%']];
function AccountDetailScreen() {
  const [paperless, setPaperless] = React.useState(true);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 20,
      padding: 32,
      flex: 1,
      minHeight: 0,
      overflowY: 'auto'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 20,
      alignItems: 'stretch',
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(Card, {
    style: {
      flex: '1 1 340px'
    }
  }, /*#__PURE__*/React.createElement(CardHeader, {
    avatar: /*#__PURE__*/React.createElement(Avatar, {
      size: "56px",
      initials: "JW"
    }),
    title: "Jane Whitfield",
    subheader: "Traditional IRA \\u00b7 \u2022\u20224821",
    action: /*#__PURE__*/React.createElement(IconButton, {
      "aria-label": "More"
    }, /*#__PURE__*/React.createElement(Icon, {
      name: "MoreVertFilled",
      size: 24
    }))
  }), /*#__PURE__*/React.createElement(CardContent, null, /*#__PURE__*/React.createElement(Typography, {
    variant: "h3",
    style: {
      letterSpacing: '-1px'
    }
  }, "$184,220.14"), /*#__PURE__*/React.createElement(Typography, {
    variant: "body2",
    color: "var(--success-main)"
  }, "+$2,410.02 (+6.2%) year to date"), /*#__PURE__*/React.createElement(Divider, {
    style: {
      margin: '8px 0'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: '10px 16px'
    }
  }, [['Opened', 'March 2019'], ['Custodian', 'Inspira Trust'], ['2026 contributions', '$4,200.00 of $7,000'], ['Beneficiaries', '2 on file']].map(([l, v]) => /*#__PURE__*/React.createElement("div", {
    key: l,
    style: {
      display: 'flex',
      flexDirection: 'column'
    }
  }, /*#__PURE__*/React.createElement(Typography, {
    variant: "caption",
    color: "var(--text-secondary)"
  }, l), /*#__PURE__*/React.createElement(Typography, {
    variant: "body2"
  }, v))))), /*#__PURE__*/React.createElement(CardActions, null, /*#__PURE__*/React.createElement(Button, {
    variant: "text"
  }, "Contribute"), /*#__PURE__*/React.createElement(Button, {
    variant: "text"
  }, "Transfer"), /*#__PURE__*/React.createElement(ActionButtonsOnWhite, null, "Statements"))), /*#__PURE__*/React.createElement(Card, {
    style: {
      flex: '1 1 280px'
    }
  }, /*#__PURE__*/React.createElement(CardHeader, {
    title: "Household",
    subheader: "Whitfield",
    dense: true,
    action: /*#__PURE__*/React.createElement(AvatarGroup, {
      max: 3,
      size: "24px"
    }, /*#__PURE__*/React.createElement(Avatar, {
      initials: "JW"
    }), /*#__PURE__*/React.createElement(Avatar, {
      initials: "RW"
    }), /*#__PURE__*/React.createElement(Avatar, {
      initials: "TK"
    }), /*#__PURE__*/React.createElement(Avatar, {
      initials: "MC"
    }))
  }), /*#__PURE__*/React.createElement(CardContent, {
    style: {
      padding: 0
    }
  }, /*#__PURE__*/React.createElement(List, {
    disablePadding: true,
    subheader: /*#__PURE__*/React.createElement(ListSubheader, null, "Accounts")
  }, /*#__PURE__*/React.createElement(ListItem, {
    dense: true,
    selected: true,
    primary: "Traditional IRA",
    secondary: "\u2022\u20224821 \\u00b7 $184,220.14"
  }), /*#__PURE__*/React.createElement(ListItem, {
    dense: true,
    primary: "Roth IRA",
    secondary: "\u2022\u20227702 \\u00b7 $92,004.77"
  }), /*#__PURE__*/React.createElement(ListItem, {
    dense: true,
    primary: "HSA",
    secondary: "\u2022\u20221130 \\u00b7 $14,880.20",
    secondaryAction: /*#__PURE__*/React.createElement(Chip, {
      label: "Pending",
      size: "small",
      color: "warning"
    })
  }), /*#__PURE__*/React.createElement(ListItemSubItem, {
    statusColor: "warning",
    primary: "Signature required",
    secondary: "Sent Mar 11"
  })))), /*#__PURE__*/React.createElement(Card, {
    style: {
      flex: '1 1 240px'
    }
  }, /*#__PURE__*/React.createElement(CardHeader, {
    title: "Preferences",
    dense: true
  }), /*#__PURE__*/React.createElement(CardContent, null, /*#__PURE__*/React.createElement(FormControlLabel, {
    control: /*#__PURE__*/React.createElement(Switch, {
      checked: paperless,
      onChange: setPaperless
    }),
    label: "Paperless statements"
  }), /*#__PURE__*/React.createElement(FormControlLabel, {
    control: /*#__PURE__*/React.createElement(Switch, {
      checked: true
    }),
    label: "Contribution alerts"
  }), /*#__PURE__*/React.createElement(FormControlLabel, {
    control: /*#__PURE__*/React.createElement(Switch, null),
    label: "Quarterly review calls"
  }), /*#__PURE__*/React.createElement(Divider, {
    style: {
      margin: '6px 0'
    }
  }), /*#__PURE__*/React.createElement(Typography, {
    variant: "caption",
    color: "var(--text-secondary)"
  }, "Advisor satisfaction"), /*#__PURE__*/React.createElement(Rating, {
    value: 4,
    readOnly: true,
    size: "small"
  }), /*#__PURE__*/React.createElement(StandaloneLink, {
    externalLinkIcon: true,
    style: {
      marginTop: 8
    }
  }, "Open the client portal")))), /*#__PURE__*/React.createElement(Alert, {
    severity: "warning",
    title: "Contribution limit is close",
    action: /*#__PURE__*/React.createElement(Button, {
      size: "small",
      color: "warning",
      variant: "outlined"
    }, "Adjust")
  }, "Jane has contributed $4,200 of the $7,000 limit for the 2026 tax year."), /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--surface-card)',
      borderRadius: 'var(--radius-md)',
      boxShadow: 'var(--shadow-1)',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement(CustomTableToolbar, {
    title: "Positions",
    count: "3 holdings",
    actions: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
      variant: "text",
      size: "small",
      startIcon: /*#__PURE__*/React.createElement(Icon, {
        name: "DownloadFilled",
        size: 20
      })
    }, "Export"), /*#__PURE__*/React.createElement(HelpersTableActions, {
      variant: "overflow"
    }))
  }), /*#__PURE__*/React.createElement(Table, null, /*#__PURE__*/React.createElement(TableHead, null, /*#__PURE__*/React.createElement(TableHeadRow, {
    columns: ['Fund', 'Ticker', 'Units', 'Market value', 'Weight'],
    align: {
      2: 'right',
      3: 'right',
      4: 'right'
    },
    sorted: {
      index: 3,
      direction: 'desc'
    }
  })), /*#__PURE__*/React.createElement("tbody", null, POSITIONS.map((p, i) => /*#__PURE__*/React.createElement(TableCellRow, {
    key: p[1],
    cells: p,
    align: {
      2: 'right',
      3: 'right',
      4: 'right'
    },
    divider: i < POSITIONS.length - 1
  }))), /*#__PURE__*/React.createElement(TableFooter, {
    colSpan: 5
  }, "Values as of market close, March 14, 2026"))), /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--surface-card)',
      borderRadius: 'var(--radius-md)',
      boxShadow: 'var(--shadow-1)',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement(CustomTableToolbar, {
    title: "Recent activity",
    size: "small"
  }), /*#__PURE__*/React.createElement(Table, {
    small: true
  }, /*#__PURE__*/React.createElement(TableHead, {
    small: true
  }, /*#__PURE__*/React.createElement(TableHeadRow, {
    small: true,
    columns: ['Date', 'Type', 'Detail', 'Amount'],
    align: {
      3: 'right'
    }
  })), /*#__PURE__*/React.createElement("tbody", null, ACTIVITY.map((a, i) => /*#__PURE__*/React.createElement(TableCellRow, {
    key: i,
    small: true,
    cells: a,
    align: {
      3: 'right'
    },
    divider: i < ACTIVITY.length - 1
  }))))));
}
Object.assign(window, {
  AccountDetailScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/advisor-console/AccountDetailScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/advisor-console/AccountsScreen.jsx
try { (() => {
const {
  DataGridTable,
  GridToolbarQuickFilter,
  GridToolbarMenu,
  DataGridColumnGroupRow,
  DataGridHeaderRow,
  DataGridCellRow,
  DetailPanelContent,
  Chip,
  Button,
  Icon,
  Alert,
  FilterChips,
  Typography,
  Menu
} = window.InspiraAdvisorMUILibrary_3f4835;
const ROWS = [['Jane Whitfield', 'Traditional IRA', '••4821', '$184,220.14', '+6.2%', 'Funded'], ['Robert Whitfield', 'Roth IRA', '••7702', '$92,004.77', '+4.8%', 'Funded'], ['Whitfield Family Trust', 'HSA', '••1130', '$14,880.20', '+1.1%', 'Pending'], ['Alan Okonjo', 'Traditional IRA', '••9014', '$402,776.05', '+7.4%', 'Funded'], ['Priya Raman', 'SEP IRA', '••3388', '$61,442.90', '\u22120.6%', 'Review'], ['Dana Feldstein', 'Roth IRA', '••2276', '$28,315.44', '+3.0%', 'Funded']];
const STATUS = {
  Funded: 'success',
  Pending: 'warning',
  Review: 'error'
};
const FILTERS = ['All accounts', 'Traditional IRA', 'Roth IRA', 'HSA', 'SEP IRA'];
function AccountsScreen() {
  const [filter, setFilter] = React.useState('All accounts');
  const [q, setQ] = React.useState('');
  const [selected, setSelected] = React.useState([]);
  const [expanded, setExpanded] = React.useState(null);
  const [sort, setSort] = React.useState({
    index: 3,
    direction: 'desc'
  });
  const [openMenu, setOpenMenu] = React.useState(null);
  const [density, setDensity] = React.useState('Standard');
  let rows = ROWS.filter(r => filter === 'All accounts' || r[1] === filter);
  if (q) rows = rows.filter(r => r.join(' ').toLowerCase().includes(q.toLowerCase()));
  const cols = [{
    label: 'Owner',
    width: 220
  }, {
    label: 'Type',
    width: 150
  }, {
    label: 'Account',
    width: 110
  }, {
    label: 'Balance',
    align: 'right',
    width: 140
  }, {
    label: 'YTD',
    align: 'right',
    width: 90
  }, {
    label: 'Status',
    width: 130
  }];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 20,
      padding: 32,
      flex: 1,
      minHeight: 0,
      overflowY: 'auto'
    }
  }, /*#__PURE__*/React.createElement(Alert, {
    severity: "info",
    variant: "outlined",
    title: "Quarterly statements are available"
  }, "Statements for Q1 2026 posted on April 3. Download them from any account's detail view."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8,
      flexWrap: 'wrap'
    }
  }, FILTERS.map(fl => /*#__PURE__*/React.createElement(FilterChips, {
    key: fl,
    label: fl,
    selected: filter === fl,
    onClick: () => setFilter(fl)
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--surface-card)',
      borderRadius: 'var(--radius-md)',
      boxShadow: 'var(--shadow-1)',
      overflow: 'visible',
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement(GridToolbarQuickFilter, {
    value: q,
    onChange: setQ,
    onMenu: m => setOpenMenu(o => o === m ? null : m)
  }), openMenu ? /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: 52,
      left: 12,
      zIndex: 30
    }
  }, /*#__PURE__*/React.createElement(GridToolbarMenu, {
    kind: openMenu.toLowerCase(),
    density: density,
    onChange: v => {
      if (openMenu === 'Density') setDensity(v);
      setOpenMenu(null);
    },
    columns: cols.map(c => c.label),
    visibleColumns: cols.map(c => c.label),
    filters: filter === 'All accounts' ? [] : [{
      label: 'Type',
      value: filter
    }]
  })) : null, /*#__PURE__*/React.createElement(DataGridColumnGroupRow, {
    checkbox: true,
    groups: [{
      label: 'Identity',
      span: 3
    }, {
      label: 'Balances',
      span: 2
    }, {
      label: '',
      span: 1,
      empty: true
    }]
  }), /*#__PURE__*/React.createElement(DataGridHeaderRow, {
    checkbox: true,
    columns: cols,
    density: density.toLowerCase(),
    sort: sort,
    onSort: i => setSort(s => s.index === i ? {
      index: i,
      direction: s.direction === 'asc' ? 'desc' : 'asc'
    } : {
      index: i,
      direction: 'asc'
    })
  }), rows.map((r, i) => /*#__PURE__*/React.createElement(React.Fragment, {
    key: r[2]
  }, /*#__PURE__*/React.createElement(DataGridCellRow, {
    checkbox: true,
    density: density.toLowerCase(),
    selected: selected.includes(i),
    onClick: () => {
      setSelected(s => s.includes(i) ? s.filter(x => x !== i) : [...s, i]);
      setExpanded(e => e === i ? null : i);
    },
    cells: [{
      value: r[0],
      width: 220
    }, {
      value: r[1],
      width: 150
    }, {
      value: r[2],
      width: 110
    }, {
      value: r[3],
      type: 'currency',
      align: 'right',
      width: 140
    }, {
      value: r[4],
      align: 'right',
      width: 90
    }, {
      value: /*#__PURE__*/React.createElement(Chip, {
        label: r[5],
        size: "small",
        color: STATUS[r[5]]
      }),
      width: 130
    }]
  }), expanded === i ? /*#__PURE__*/React.createElement(DetailPanelContent, {
    title: r[0] + ' \u00b7 ' + r[1],
    items: [{
      label: 'Opened',
      value: 'Mar 2019'
    }, {
      label: 'Custodian',
      value: 'Inspira Trust'
    }, {
      label: 'YTD contributions',
      value: '$4,200.00'
    }, {
      label: 'Advisor',
      value: 'M. Cortez'
    }]
  }) : null)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: '10px 16px',
      borderTop: '1px solid var(--border-divider)',
      fontFamily: 'var(--font-ui)',
      fontSize: 12,
      lineHeight: 1.66,
      letterSpacing: '0.4px',
      color: 'var(--text-secondary)'
    }
  }, /*#__PURE__*/React.createElement("span", null, selected.length ? selected.length + ' selected' : 'Showing 1\u2013' + rows.length + ' of 312'), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      gap: 4
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "text",
    size: "small",
    startIcon: /*#__PURE__*/React.createElement(Icon, {
      name: "ChevronLeftFilled",
      size: 20
    })
  }, "Prev"), /*#__PURE__*/React.createElement(Button, {
    variant: "text",
    size: "small",
    endIcon: /*#__PURE__*/React.createElement(Icon, {
      name: "ChevronRightFilled",
      size: 20
    })
  }, "Next")))));
}
Object.assign(window, {
  AccountsScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/advisor-console/AccountsScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/advisor-console/HouseholdsScreen.jsx
try { (() => {
const {
  Card,
  CardHeader,
  CardContent,
  Avatar,
  AvatarGroup,
  Typography,
  Chip,
  Button,
  IconButton,
  Icon,
  TextField,
  Select,
  Autocomplete,
  Checkbox,
  List,
  ListItem,
  ListSubheader,
  Divider,
  Menu,
  MenuItem,
  CustomTableToolbar,
  Table,
  TableHead,
  TableHeadRow,
  TableCellRow,
  TableFooter,
  Badge,
  Progress,
  TooltipBubble,
  LabelAndTooltipTrigger
} = window.InspiraAdvisorMUILibrary_3f4835;
const HOUSEHOLDS = [['Whitfield', 4, '$291,105.11', 'M. Cortez', 'Review due'], ['Okonjo', 2, '$402,776.05', 'M. Cortez', 'On track'], ['Raman', 3, '$61,442.90', 'D. Ng', 'Review due'], ['Feldstein', 1, '$28,315.44', 'D. Ng', 'On track'], ['Aliyev', 5, '$1,204,880.00', 'M. Cortez', 'On track']];
function HouseholdsScreen() {
  const [q, setQ] = React.useState('');
  const [advisor, setAdvisor] = React.useState('');
  const [tip, setTip] = React.useState(false);
  const [menuFor, setMenuFor] = React.useState(null);
  const rows = HOUSEHOLDS.filter(h => (!q || h[0].toLowerCase().includes(q.toLowerCase())) && (!advisor || h[3] === advisor));
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 20,
      padding: 32,
      flex: 1,
      minHeight: 0,
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0,
      display: 'flex',
      flexDirection: 'column',
      gap: 20,
      overflowY: 'auto'
    }
  }, /*#__PURE__*/React.createElement(Card, null, /*#__PURE__*/React.createElement(CardContent, {
    style: {
      padding: 16,
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(LabelAndTooltipTrigger, {
    label: "Filter households",
    onTooltip: () => setTip(t => !t)
  })), tip ? /*#__PURE__*/React.createElement(TooltipBubble, {
    variant: "x",
    onClose: () => setTip(false),
    style: {
      maxWidth: 300
    }
  }, "Households group accounts by family relationship, not by mailing address.") : null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 12,
      flexWrap: 'wrap',
      alignItems: 'flex-start'
    }
  }, /*#__PURE__*/React.createElement(TextField, {
    label: "Search",
    size: "small",
    value: q,
    onChange: setQ,
    placeholder: "Household name",
    startAdornment: /*#__PURE__*/React.createElement(Icon, {
      name: "SearchFilled",
      size: 20
    }),
    style: {
      width: 200
    }
  }), /*#__PURE__*/React.createElement(Select, {
    label: "Advisor",
    size: "small",
    value: advisor,
    placeholder: "Any advisor",
    options: ['M. Cortez', 'D. Ng'],
    onChange: setAdvisor,
    style: {
      width: 170
    }
  }), /*#__PURE__*/React.createElement(Autocomplete, {
    label: "Fund held",
    options: ['ISBLX', 'ISCBX', 'ISTRX'],
    style: {
      width: 180
    }
  }), /*#__PURE__*/React.createElement(Button, {
    variant: "text",
    size: "small",
    onClick: () => {
      setQ('');
      setAdvisor('');
    }
  }, "Clear")))), /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--surface-card)',
      borderRadius: 'var(--radius-md)',
      boxShadow: 'var(--shadow-1)',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement(CustomTableToolbar, {
    title: "Households",
    count: rows.length + ' of 128',
    actions: /*#__PURE__*/React.createElement(IconButton, {
      "aria-label": "Filter"
    }, /*#__PURE__*/React.createElement(Icon, {
      name: "FilterListFilled",
      size: 24
    }))
  }), /*#__PURE__*/React.createElement(Table, {
    checkbox: true
  }, /*#__PURE__*/React.createElement(TableHead, {
    checkbox: true
  }, /*#__PURE__*/React.createElement(TableHeadRow, {
    checkbox: true,
    columns: ['Household', 'Accounts', 'Total assets', 'Advisor', 'Status'],
    align: {
      1: 'right',
      2: 'right',
      4: 'left'
    }
  })), /*#__PURE__*/React.createElement("tbody", null, rows.map((h, i) => /*#__PURE__*/React.createElement(TableCellRow, {
    key: h[0],
    checkbox: true,
    align: {
      1: 'right',
      2: 'right',
      4: 'left'
    },
    divider: i < rows.length - 1,
    cells: [/*#__PURE__*/React.createElement("span", {
      style: {
        display: 'inline-flex',
        alignItems: 'center',
        gap: 10
      }
    }, /*#__PURE__*/React.createElement(Avatar, {
      size: "24px",
      initials: h[0].slice(0, 2).toUpperCase()
    }), h[0]), h[1], h[2], h[3], /*#__PURE__*/React.createElement(Chip, {
      label: h[4],
      size: "small",
      color: h[4] === 'Review due' ? 'warning' : 'success'
    })]
  }))), /*#__PURE__*/React.createElement(TableFooter, {
    colSpan: 6
  }, "Sorted by total assets \\u00b7 updated 4 minutes ago")))), /*#__PURE__*/React.createElement("div", {
    style: {
      width: 280,
      flexShrink: 0,
      display: 'flex',
      flexDirection: 'column',
      gap: 20
    }
  }, /*#__PURE__*/React.createElement(Card, null, /*#__PURE__*/React.createElement(CardHeader, {
    title: "Book of business",
    dense: true
  }), /*#__PURE__*/React.createElement(CardContent, null, /*#__PURE__*/React.createElement(Typography, {
    variant: "h4"
  }, "$4.1M"), /*#__PURE__*/React.createElement(Typography, {
    variant: "body2",
    color: "var(--text-secondary)"
  }, "across 128 households"), /*#__PURE__*/React.createElement(Divider, {
    style: {
      margin: '8px 0'
    }
  }), [['Reviews due', 12, 'warning'], ['Signatures pending', 4, 'error'], ['New this quarter', 9, 'success']].map(([l, n, c]) => /*#__PURE__*/React.createElement("div", {
    key: l,
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: '4px 0'
    }
  }, /*#__PURE__*/React.createElement(Typography, {
    variant: "body2"
  }, l), /*#__PURE__*/React.createElement(Badge, {
    content: n,
    color: c
  }))))), /*#__PURE__*/React.createElement(Card, null, /*#__PURE__*/React.createElement(CardHeader, {
    title: "Sync status",
    dense: true,
    action: /*#__PURE__*/React.createElement(Progress, {
      size: 20
    })
  }), /*#__PURE__*/React.createElement(CardContent, null, /*#__PURE__*/React.createElement(Typography, {
    variant: "body2",
    color: "var(--text-secondary)"
  }, "Custodian positions refresh nightly at 02:00 ET. Last successful sync 4 minutes ago.")))));
}
Object.assign(window, {
  HouseholdsScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/advisor-console/HouseholdsScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/advisor-console/Shell.jsx
try { (() => {
const {
  Icon,
  Avatar,
  IconButton,
  Divider,
  Typography,
  Badge,
  Chip
} = window.InspiraAdvisorMUILibrary_3f4835;
const NAV = [{
  id: 'accounts',
  label: 'Accounts',
  icon: 'SpaceDashboardOutlined'
}, {
  id: 'households',
  label: 'Households',
  icon: 'PeopleFilled'
}, {
  id: 'detail',
  label: 'Account detail',
  icon: 'ReceiptFilled'
}];
function SideNav({
  screen,
  onNav
}) {
  return /*#__PURE__*/React.createElement("nav", {
    style: {
      width: 232,
      flexShrink: 0,
      background: 'var(--indigo-900)',
      display: 'flex',
      flexDirection: 'column',
      gap: 4,
      padding: '20px 12px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '4px 12px 20px',
      fontFamily: 'var(--font-display)',
      fontWeight: 400,
      fontSize: 30,
      lineHeight: 1,
      color: '#FFFFFF'
    }
  }, "Inspira"), NAV.map(n => {
    const on = screen === n.id;
    return /*#__PURE__*/React.createElement("button", {
      key: n.id,
      type: "button",
      onClick: () => onNav(n.id),
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 12,
        border: 'none',
        textAlign: 'left',
        cursor: 'pointer',
        padding: '10px 12px',
        borderRadius: 'var(--radius-md)',
        background: on ? 'rgba(255,255,255,0.12)' : 'transparent',
        color: '#FFFFFF',
        fontFamily: 'var(--font-ui)',
        fontWeight: on ? 600 : 400,
        fontSize: 14,
        lineHeight: '20px'
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      name: n.icon,
      size: 20
    }), n.label);
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      padding: '10px 12px',
      color: '#FFFFFF'
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    size: "24px",
    initials: "MC",
    color: "var(--gold-400)",
    style: {
      color: 'var(--indigo-900)'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-ui)',
      fontSize: 13,
      lineHeight: '18px'
    }
  }, "M. Cortez")));
}
function TopBar({
  title,
  caption,
  actions
}) {
  return /*#__PURE__*/React.createElement("header", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 16,
      padding: '20px 32px',
      background: 'var(--surface-card)',
      borderBottom: '1px solid var(--border-divider)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 2,
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement(Typography, {
    variant: "h4"
  }, title), caption ? /*#__PURE__*/React.createElement(Typography, {
    variant: "body2",
    color: "var(--text-secondary)"
  }, caption) : null), /*#__PURE__*/React.createElement(IconButton, {
    "aria-label": "Search"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "SearchFilled",
    size: 24
  })), /*#__PURE__*/React.createElement(Badge, {
    content: 3,
    color: "error"
  }, /*#__PURE__*/React.createElement(IconButton, {
    "aria-label": "Notifications"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "NotificationsFilled",
    size: 24
  }))), actions);
}
Object.assign(window, {
  SideNav,
  TopBar,
  NAV
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/advisor-console/Shell.jsx", error: String((e && e.message) || e) }); }

// ui_kits/participant-forms/ConfirmStep.jsx
try { (() => {
const {
  Alert,
  Typography,
  InspiraButton,
  ActionButtonsOnWhite,
  StandaloneLink,
  Card,
  CardContent,
  Divider,
  List,
  ListItem,
  ListItemSubItem,
  Chip,
  Icon,
  Loading
} = window.InspiraAdvisorMUILibrary_3f4835;
function ConfirmStep({
  onRestart
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 24,
      maxWidth: 520
    }
  }, /*#__PURE__*/React.createElement(Alert, {
    severity: "success",
    title: "Contribution submitted"
  }, "We'll pull $1,200.00 from Checking \u2022\u20224821 tomorrow and post it to your 2026 tax year."), /*#__PURE__*/React.createElement(Card, null, /*#__PURE__*/React.createElement(CardContent, {
    style: {
      padding: 0
    }
  }, /*#__PURE__*/React.createElement(List, null, /*#__PURE__*/React.createElement(ListItem, {
    primary: "Confirmation",
    secondary: "INS-2026-004182",
    secondaryAction: /*#__PURE__*/React.createElement(Chip, {
      label: "Pending",
      size: "small",
      color: "warning"
    })
  }), /*#__PURE__*/React.createElement(ListItemSubItem, {
    statusColor: "neutral",
    primary: "Debit scheduled",
    secondary: "Mar 15, 2026"
  }), /*#__PURE__*/React.createElement(ListItemSubItem, {
    statusColor: "success",
    primary: "Posts to account",
    secondary: "Mar 16, 2026"
  })))), /*#__PURE__*/React.createElement(Divider, null), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 16,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(InspiraButton, {
    size: "lg",
    onClick: onRestart
  }, "Back to your accounts"), /*#__PURE__*/React.createElement(ActionButtonsOnWhite, {
    kind: "pdf download"
  }, "Download receipt")), /*#__PURE__*/React.createElement(StandaloneLink, {
    externalLinkIcon: true
  }, "Contribution rules for 2026"));
}
Object.assign(window, {
  ConfirmStep
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/participant-forms/ConfirmStep.jsx", error: String((e && e.message) || e) }); }

// ui_kits/participant-forms/ContributeStep.jsx
try { (() => {
const {
  InputBox,
  LabelAndTooltipTrigger,
  InspiraButton,
  IconButtons,
  FilterChips,
  ActionButtonsOnWhite,
  TextAction,
  Typography,
  Divider,
  Alert,
  Icon,
  Card,
  CardContent,
  HideTextOverflow,
  ErrorMessage
} = window.InspiraAdvisorMUILibrary_3f4835;
const YEARS = ['2025', '2026'];
const SOURCES = ['Checking ••4821', 'Savings ••7702', 'Payroll deduction'];
function ContributeStep({
  onNext,
  onBack
}) {
  const [year, setYear] = React.useState('2026');
  const [source, setSource] = React.useState(SOURCES[0]);
  const [amount, setAmount] = React.useState('1,200.00');
  const over = parseFloat(String(amount).replace(/,/g, '')) > 2800;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 24,
      maxWidth: 520
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement(Typography, {
    variant: "h4"
  }, "Make a contribution"), /*#__PURE__*/React.createElement(Typography, {
    variant: "body1",
    color: "var(--text-secondary)"
  }, "You've contributed $4,200 of the $7,000 limit for 2026. Contributions post the next business day.")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement(LabelAndTooltipTrigger, {
    label: "Tax year",
    showTooltip: false
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8
    }
  }, YEARS.map(y => /*#__PURE__*/React.createElement(FilterChips, {
    key: y,
    label: y,
    selected: y === year,
    onClick: () => setYear(y)
  })))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement(LabelAndTooltipTrigger, {
    label: "Funding source",
    showTooltip: false
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8,
      flexWrap: 'wrap'
    }
  }, SOURCES.map(s => /*#__PURE__*/React.createElement(FilterChips, {
    key: s,
    label: s,
    selected: s === source,
    onClick: () => setSource(s)
  })))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 4
    }
  }, over ? /*#__PURE__*/React.createElement(ErrorMessage, null, "That would exceed your remaining $2,800 for ", year, ".") : null, /*#__PURE__*/React.createElement(LabelAndTooltipTrigger, {
    label: "Amount (USD)"
  }), /*#__PURE__*/React.createElement(InputBox, {
    value: amount,
    onChange: setAmount,
    state: over ? 'error' : 'default',
    fullWidth: true
  })), /*#__PURE__*/React.createElement(Alert, {
    severity: "info",
    variant: "standard",
    title: "One-time or recurring?"
  }, "Set this up as a recurring contribution and we'll pull the same amount on the 1st of every month."), /*#__PURE__*/React.createElement(Card, {
    style: {
      boxShadow: 'none',
      background: 'var(--subtle-primary-bg)'
    }
  }, /*#__PURE__*/React.createElement(CardContent, {
    style: {
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(Typography, {
    variant: "caption",
    color: "var(--subtle-primary-fg)"
  }, "Summary"), /*#__PURE__*/React.createElement(Typography, {
    variant: "h5",
    color: "var(--subtle-primary-fg)"
  }, "$", amount), /*#__PURE__*/React.createElement(HideTextOverflow, null, source, " \\u00b7 ", year, " tax year"))), /*#__PURE__*/React.createElement(Divider, null), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 16,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(InspiraButton, {
    size: "lg",
    onClick: onNext,
    disabled: over
  }, "Submit contribution"), /*#__PURE__*/React.createElement(InspiraButton, {
    hierarchy: "secondary",
    size: "lg",
    onClick: onBack
  }, "Back"), /*#__PURE__*/React.createElement(TextAction, {
    onClick: () => setAmount('2,800.00')
  }, "Contribute the maximum")));
}
Object.assign(window, {
  ContributeStep
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/participant-forms/ContributeStep.jsx", error: String((e && e.message) || e) }); }

// ui_kits/participant-forms/VerifyStep.jsx
try { (() => {
const {
  PrimaryInputVert,
  InspiraButton,
  ActionButtonsOnWhite,
  StandaloneLink,
  LabelAndTooltipTrigger,
  TooltipBubble,
  ErrorMessage,
  Typography,
  Divider,
  Icon,
  FilterChips
} = window.InspiraAdvisorMUILibrary_3f4835;
function VerifyStep({
  onNext
}) {
  const [ssn, setSsn] = React.useState('');
  const [routing, setRouting] = React.useState('');
  const [tip, setTip] = React.useState(false);
  const routingError = routing.length > 0 && routing.length !== 9;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 24,
      maxWidth: 520
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement(Typography, {
    variant: "h4"
  }, "Verify your identity"), /*#__PURE__*/React.createElement(Typography, {
    variant: "body1",
    color: "var(--text-secondary)"
  }, "We need a few details to confirm it's you before we open your account. This takes about two minutes.")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 20
    }
  }, /*#__PURE__*/React.createElement(PrimaryInputVert, {
    label: "Legal first name",
    placeholder: "Jane",
    fullWidth: true
  }), /*#__PURE__*/React.createElement(PrimaryInputVert, {
    label: "Legal last name",
    placeholder: "Whitfield",
    fullWidth: true
  }), /*#__PURE__*/React.createElement(PrimaryInputVert, {
    label: "Social Security number",
    state: "masked",
    placeholder: "000-00-0000",
    value: ssn,
    onChange: setSsn,
    fullWidth: true,
    onTooltip: () => setTip(t => !t)
  }), tip ? /*#__PURE__*/React.createElement(TooltipBubble, {
    variant: "x",
    placement: "top",
    onClose: () => setTip(false)
  }, "We use your SSN only to verify your identity with the IRS. It is never shared with your employer.") : null, /*#__PURE__*/React.createElement(PrimaryInputVert, {
    label: "Bank routing number",
    placeholder: "000000000",
    value: routing,
    onChange: setRouting,
    state: routingError ? 'error' : 'default',
    errorText: "Enter a 9-digit routing number.",
    fullWidth: true
  })), /*#__PURE__*/React.createElement(Divider, null), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 16,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(InspiraButton, {
    size: "lg",
    onClick: onNext,
    disabled: routingError
  }, "Continue"), /*#__PURE__*/React.createElement(ActionButtonsOnWhite, {
    kind: "text only"
  }, "Save and finish later")), /*#__PURE__*/React.createElement(StandaloneLink, {
    externalLinkIcon: true
  }, "How we protect your information"));
}
Object.assign(window, {
  VerifyStep
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/participant-forms/VerifyStep.jsx", error: String((e && e.message) || e) }); }

if (__ds_scope.__ds_default_assets_icons_icon_data_imae2q$nab192 === undefined) __ds_scope.__ds_default_assets_icons_icon_data_imae2q$nab192 = __ds_scope.__ds_default_assets_icons_icon_data_imae2q;

__ds_ns.Icon = __ds_scope.Icon;

__ds_ns.Divider = __ds_scope.Divider;

__ds_ns.NativeBrowserScroll = __ds_scope.NativeBrowserScroll;

__ds_ns.Paper = __ds_scope.Paper;

__ds_ns.Spacing = __ds_scope.Spacing;

__ds_ns.Stack = __ds_scope.Stack;

__ds_ns.Typography = __ds_scope.Typography;

__ds_ns.Avatar = __ds_scope.Avatar;

__ds_ns.AvatarGroup = __ds_scope.AvatarGroup;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Chip = __ds_scope.Chip;

__ds_ns.Link = __ds_scope.Link;

__ds_ns.List = __ds_scope.List;

__ds_ns.ListItem = __ds_scope.ListItem;

__ds_ns.ListItemSubItem = __ds_scope.ListItemSubItem;

__ds_ns.ListSubheader = __ds_scope.ListSubheader;

__ds_ns.DataGridCell = __ds_scope.DataGridCell;

__ds_ns.DataGridCellRow = __ds_scope.DataGridCellRow;

__ds_ns.DataGridColumnGroupHeader = __ds_scope.DataGridColumnGroupHeader;

__ds_ns.DataGridColumnGroupRow = __ds_scope.DataGridColumnGroupRow;

__ds_ns.DataGridGroupingCell = __ds_scope.DataGridGroupingCell;

__ds_ns.DataGridHeader = __ds_scope.DataGridHeader;

__ds_ns.DataGridHeaderRow = __ds_scope.DataGridHeaderRow;

__ds_ns.DataGridTable = __ds_scope.DataGridTable;

__ds_ns.DetailPanelContent = __ds_scope.DetailPanelContent;

__ds_ns.GridToolbarMenu = __ds_scope.GridToolbarMenu;

__ds_ns.GridToolbarQuickFilter = __ds_scope.GridToolbarQuickFilter;

__ds_ns.Alert = __ds_scope.Alert;

__ds_ns.Loading = __ds_scope.Loading;

__ds_ns.Progress = __ds_scope.Progress;

__ds_ns.TooltipBubble = __ds_scope.TooltipBubble;

__ds_ns.Autocomplete = __ds_scope.Autocomplete;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.ButtonGroup = __ds_scope.ButtonGroup;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.EyeIconToggle = __ds_scope.EyeIconToggle;

__ds_ns.FormControlLabel = __ds_scope.FormControlLabel;

__ds_ns.FormGroup = __ds_scope.FormGroup;

__ds_ns.FormHelperText = __ds_scope.FormHelperText;

__ds_ns.FormLabel = __ds_scope.FormLabel;

__ds_ns.HelpersButtonIconContainer = __ds_scope.HelpersButtonIconContainer;

__ds_ns.HelpersField = __ds_scope.HelpersField;

__ds_ns.HelpersText = __ds_scope.HelpersText;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.LoadingButton = __ds_scope.LoadingButton;

__ds_ns.LockIconToggle = __ds_scope.LockIconToggle;

__ds_ns.Rating = __ds_scope.Rating;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.Star = __ds_scope.Star;

__ds_ns.Switch = __ds_scope.Switch;

__ds_ns.TextField = __ds_scope.TextField;

__ds_ns.TextFieldMultiline = __ds_scope.TextFieldMultiline;

__ds_ns.ActionButtonsOnWhite = __ds_scope.ActionButtonsOnWhite;

__ds_ns.ErrorMessage = __ds_scope.ErrorMessage;

__ds_ns.FilterChips = __ds_scope.FilterChips;

__ds_ns.HideTextOverflow = __ds_scope.HideTextOverflow;

__ds_ns.IconButtons = __ds_scope.IconButtons;

__ds_ns.InputBox = __ds_scope.InputBox;

__ds_ns.InspiraButton = __ds_scope.InspiraButton;

__ds_ns.LabelAndTooltipTrigger = __ds_scope.LabelAndTooltipTrigger;

__ds_ns.PrimaryInputVert = __ds_scope.PrimaryInputVert;

__ds_ns.StandaloneLink = __ds_scope.StandaloneLink;

__ds_ns.TextAction = __ds_scope.TextAction;

__ds_ns.VerticalTrigger = __ds_scope.VerticalTrigger;

__ds_ns.Hidden = __ds_scope.Hidden;

__ds_ns.LibraryComponentHeading = __ds_scope.LibraryComponentHeading;

__ds_ns.LibraryComponentInformation = __ds_scope.LibraryComponentInformation;

__ds_ns.LibraryComponentProperties = __ds_scope.LibraryComponentProperties;

__ds_ns.LibraryInstanceSlot = __ds_scope.LibraryInstanceSlot;

__ds_ns.LibraryPlaceholderImage = __ds_scope.LibraryPlaceholderImage;

__ds_ns.UsabilityIconContainer = __ds_scope.UsabilityIconContainer;

__ds_ns.Menu = __ds_scope.Menu;

__ds_ns.MenuItem = __ds_scope.MenuItem;

__ds_ns.MenuList = __ds_scope.MenuList;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.CardActions = __ds_scope.CardActions;

__ds_ns.CardContent = __ds_scope.CardContent;

__ds_ns.CardElements = __ds_scope.CardElements;

__ds_ns.CardHeader = __ds_scope.CardHeader;

__ds_ns.CardMedia = __ds_scope.CardMedia;

__ds_ns.CustomTableCustomCell = __ds_scope.CustomTableCustomCell;

__ds_ns.CustomTableToolbar = __ds_scope.CustomTableToolbar;

__ds_ns.HelpersTableActions = __ds_scope.HelpersTableActions;

__ds_ns.HelpersTableCellContent = __ds_scope.HelpersTableCellContent;

__ds_ns.HelpersTableCells = __ds_scope.HelpersTableCells;

__ds_ns.HelpersTableTitle = __ds_scope.HelpersTableTitle;

__ds_ns.Table = __ds_scope.Table;

__ds_ns.TableCell = __ds_scope.TableCell;

__ds_ns.TableCellRow = __ds_scope.TableCellRow;

__ds_ns.TableColumns = __ds_scope.TableColumns;

__ds_ns.TableFooter = __ds_scope.TableFooter;

__ds_ns.TableHead = __ds_scope.TableHead;

__ds_ns.TableHeadRow = __ds_scope.TableHeadRow;

})();
